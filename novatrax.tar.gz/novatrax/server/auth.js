// Authentification : mots de passe (scrypt), jetons de session signés (HMAC-SHA256),
// codes de vérification à usage unique, limitation de débit et journal d'audit.
import crypto from "node:crypto";
import { config } from "./config.js";
import { get, run, insert } from "./db.js";
import { unauthorized, forbidden, HttpError } from "./lib/http.js";
import { sendMail } from "./mail.js";

// ---------- Mots de passe ----------
export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

export function verifyPassword(password, stored) {
  const [algo, saltHex, hashHex] = String(stored || "").split("$");
  if (algo !== "scrypt" || !saltHex || !hashHex) return false;
  const hash = crypto.scryptSync(password, Buffer.from(saltHex, "hex"), 64, { N: 16384, r: 8, p: 1 });
  const expected = Buffer.from(hashHex, "hex");
  return expected.length === hash.length && crypto.timingSafeEqual(expected, hash);
}

export function passwordProblem(pw) {
  if (typeof pw !== "string" || pw.length < 8) return "Le mot de passe doit contenir au moins 8 caractères.";
  if (!/[a-zA-Z]/.test(pw) || !/\d/.test(pw)) return "Le mot de passe doit contenir des lettres et des chiffres.";
  if (pw.length > 128) return "Mot de passe trop long.";
  return null;
}

// ---------- Jetons signés ----------
const b64url = (buf) => Buffer.from(buf).toString("base64url");

export function sign(payload, ttlSeconds) {
  const body = { ...payload, exp: Math.floor(Date.now() / 1000) + ttlSeconds };
  const head = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const data = head + "." + b64url(JSON.stringify(body));
  const sig = crypto.createHmac("sha256", config.jwtSecret).update(data).digest("base64url");
  return data + "." + sig;
}

export function verify(token) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) return null;
  const data = parts[0] + "." + parts[1];
  const sig = crypto.createHmac("sha256", config.jwtSecret).update(data).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(parts[2]);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const body = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    if (!body.exp || body.exp < Date.now() / 1000) return null;
    return body;
  } catch {
    return null;
  }
}

export const issueSession = (user) =>
  sign({ sub: user.id, v: user.token_version || 0, t: "session" }, config.sessionDays * 86400);

// ---------- Utilisateur courant ----------
export function currentUser(req) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return null;
  const p = verify(token);
  if (!p || p.t !== "session") return null;
  const u = get("SELECT * FROM users WHERE id = ?", p.sub);
  if (!u || (u.token_version || 0) !== p.v) return null;
  return u;
}

// Membre connecté, e-mail vérifié, compte non bloqué.
export function requireUser(req) {
  const u = currentUser(req);
  if (!u) throw unauthorized();
  if (!u.email_verified) throw new HttpError(403, "Adresse e-mail non vérifiée.");
  if (u.account_status === "suspended") throw forbidden("Votre compte est bloqué. Contactez le support NOVATRAX.");
  return u;
}

export function requireAdmin(req) {
  const u = requireUser(req);
  if (u.role !== "admin") throw forbidden("Accès réservé aux administrateurs.");
  return u;
}

// Champs renvoyés au membre lui-même (jamais le hash du mot de passe).
export function selfView(u) {
  if (!u) return null;
  const { password_hash, token_version, ...rest } = u;
  return { ...rest, full_name: [u.first_name, u.last_name].filter(Boolean).join(" ") || u.username || "" };
}

export const displayName = (u) =>
  [u?.first_name, u?.last_name].filter(Boolean).join(" ").trim() || u?.username || u?.email || "Membre";

// ---------- Codes de vérification (OTP) ----------
const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_MAX_ATTEMPTS = 5;
const OTP_RESEND_MS = 45 * 1000;
const hashCode = (code) => crypto.createHmac("sha256", config.jwtSecret).update(code).digest("hex");

export async function sendOtp(email, purpose) {
  const existing = get("SELECT * FROM otps WHERE email = ? AND purpose = ?", email, purpose);
  if (existing && Date.now() - existing.created_at < OTP_RESEND_MS) {
    throw new HttpError(429, "Patientez quelques secondes avant de demander un nouveau code.");
  }
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, "0");
  run(
    `INSERT INTO otps (email, purpose, code_hash, expires_at, attempts, created_at) VALUES (?,?,?,?,0,?)
     ON CONFLICT(email, purpose) DO UPDATE SET code_hash=excluded.code_hash, expires_at=excluded.expires_at, attempts=0, created_at=excluded.created_at`,
    email, purpose, hashCode(code), Date.now() + OTP_TTL_MS, Date.now()
  );
  const subject = purpose === "reset" ? "Réinitialisation de votre mot de passe NOVATRAX" : "Votre code de vérification NOVATRAX";
  const text =
    (purpose === "reset"
      ? "Vous avez demandé la réinitialisation de votre mot de passe."
      : "Bienvenue sur NOVATRAX ! Confirmez votre adresse e-mail.") +
    `\n\nVotre code : ${code}\n\nCe code expire dans 10 minutes. Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.`;
  const r = await sendMail(email, subject, text);
  // En développement sans fournisseur e-mail, le code est renvoyé pour faciliter les tests.
  return !config.isProd && r.console ? code : undefined;
}

export function checkOtp(email, purpose, code) {
  const row = get("SELECT * FROM otps WHERE email = ? AND purpose = ?", email, purpose);
  if (!row || row.expires_at < Date.now()) throw new HttpError(400, "Code invalide ou expiré. Demandez un nouveau code.");
  if (row.attempts >= OTP_MAX_ATTEMPTS) throw new HttpError(429, "Trop de tentatives. Demandez un nouveau code.");
  const ok = row.code_hash === hashCode(String(code || "").trim());
  if (!ok) {
    run("UPDATE otps SET attempts = attempts + 1 WHERE email = ? AND purpose = ?", email, purpose);
    throw new HttpError(400, "Code de vérification incorrect.");
  }
  run("DELETE FROM otps WHERE email = ? AND purpose = ?", email, purpose);
}

// ---------- Limitation de débit (mémoire) ----------
const buckets = new Map();
export function rateLimit(key, max, windowMs) {
  const t = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset < t) {
    buckets.set(key, { count: 1, reset: t + windowMs });
    return;
  }
  b.count++;
  if (b.count > max) throw new HttpError(429, "Trop de tentatives. Réessayez dans quelques minutes.");
}
setInterval(() => {
  const t = Date.now();
  for (const [k, b] of buckets) if (b.reset < t) buckets.delete(k);
}, 60_000).unref();

export const clientIp = (req) =>
  String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress || "?";

// ---------- Journal d'audit & notifications ----------
export function audit(entry) {
  try {
    insert("audit_logs", {
      action: entry.action,
      admin_email: entry.admin_email || "system",
      admin_id: entry.admin_id || null,
      target_user_id: entry.target_user_id || null,
      target_id: entry.target_id || null,
      result: entry.result || "success",
      reason: entry.reason || null,
      details: entry.details || null,
    });
  } catch (e) {
    console.error("[audit]", e.message);
  }
}

export function auditBy(admin, action, extra = {}) {
  audit({ action, admin_email: admin.email, admin_id: admin.id, ...extra });
}

// Message dans la boîte de réception (+ e-mail facultatif).
export async function notify(user, title, text, { email = true, type = "system" } = {}) {
  if (!user?.id) return;
  insert("inbox_messages", { user_id: user.id, title, body_text: text, type, read: false });
  if (email && user.email && !user.unsubscribed) await sendMail(user.email, title, text);
}
