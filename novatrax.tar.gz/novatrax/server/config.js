// Configuration : lit le fichier .env (sans dépendance) puis les variables d'environnement.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function loadEnvFile(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m || line.trim().startsWith("#")) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
loadEnvFile(path.join(ROOT, ".env"));

const env = process.env;
const DATA_DIR = path.resolve(ROOT, env.DATA_DIR || "data");
fs.mkdirSync(path.join(DATA_DIR, "uploads", "public"), { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, "uploads", "private"), { recursive: true });

// Secret de signature des sessions : fourni par JWT_SECRET ou généré une fois et conservé.
function resolveSecret() {
  if (env.JWT_SECRET && env.JWT_SECRET.length >= 32) return env.JWT_SECRET;
  const file = path.join(DATA_DIR, ".secret");
  if (fs.existsSync(file)) return fs.readFileSync(file, "utf8").trim();
  const s = crypto.randomBytes(48).toString("hex");
  fs.writeFileSync(file, s, { mode: 0o600 });
  return s;
}

export const config = {
  root: ROOT,
  dataDir: DATA_DIR,
  dbFile: path.join(DATA_DIR, "novatrax.db"),
  publicUploads: path.join(DATA_DIR, "uploads", "public"),
  privateUploads: path.join(DATA_DIR, "uploads", "private"),
  distDir: path.join(ROOT, "dist"),
  port: Number(env.PORT || 3000),
  isProd: env.NODE_ENV === "production",
  appName: env.APP_NAME || "NOVATRAX",
  appUrl: (env.APP_URL || "http://localhost:" + (env.PORT || 3000)).replace(/\/$/, ""),
  supportEmail: env.SUPPORT_EMAIL || "novatraxagencies@gmail.com",
  adminEmails: (env.ADMIN_EMAILS || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean),
  jwtSecret: resolveSecret(),
  sessionDays: Number(env.SESSION_DAYS || 30),
  mail: {
    provider: (env.MAIL_PROVIDER || "console").toLowerCase(), // console | brevo | resend
    apiKey: env.MAIL_API_KEY || "",
    from: env.MAIL_FROM || "NOVATRAX <no-reply@novatrax.local>",
  },
  marketplaceCommissionRate: Math.min(0.9, Math.max(0, Number(env.MARKETPLACE_COMMISSION_RATE ?? 0))),
  maxImageBytes: 5 * 1024 * 1024,
  maxApkBytes: Number(env.MAX_APK_MB || 300) * 1024 * 1024,
};
