// Envoi d'e-mails : Brevo, Resend, ou affichage console (développement).
import { config } from "./config.js";

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// Gabarit HTML aux couleurs NOVATRAX (le texte brut reste toujours fourni).
export function brandedHtml(title, text) {
  const body = escapeHtml(text).replace(/\n/g, "<br>");
  return `<!doctype html><html><body style="margin:0;background:#f4f6fb;font-family:Arial,Helvetica,sans-serif;color:#111827">
<table width="100%" cellpadding="0" cellspacing="0" style="padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:16px;overflow:hidden">
<tr><td style="background:linear-gradient(135deg,#2563eb,#7c3aed);padding:22px 28px;color:#fff;font-size:22px;font-weight:800;letter-spacing:-.3px">${escapeHtml(config.appName)}</td></tr>
<tr><td style="padding:28px">
<h1 style="margin:0 0 14px;font-size:19px">${escapeHtml(title)}</h1>
<p style="margin:0;font-size:14px;line-height:1.6;color:#374151">${body}</p>
</td></tr>
<tr><td style="padding:16px 28px;border-top:1px solid #e5e7eb;font-size:12px;color:#6b7280">
Support : <a href="mailto:${escapeHtml(config.supportEmail)}" style="color:#2563eb">${escapeHtml(config.supportEmail)}</a>
</td></tr></table></td></tr></table></body></html>`;
}

function parseFrom(from) {
  const m = String(from).match(/^\s*(.*?)\s*<([^>]+)>\s*$/);
  return m ? { name: m[1] || config.appName, email: m[2] } : { name: config.appName, email: from };
}

export async function sendMail(to, subject, text, html) {
  if (!to) return { ok: false, error: "Destinataire manquant" };
  const htmlBody = html || brandedHtml(subject, text);
  const { provider, apiKey, from } = config.mail;
  try {
    if (provider === "brevo" && apiKey) {
      const f = parseFrom(from);
      const r = await fetch("https://api.brevo.com/v3/smtp/email", {
        method: "POST",
        headers: { "api-key": apiKey, "Content-Type": "application/json", accept: "application/json" },
        body: JSON.stringify({ sender: f, to: [{ email: to }], subject, htmlContent: htmlBody, textContent: text }),
      });
      if (!r.ok) throw new Error("Brevo " + r.status + " " + (await r.text()).slice(0, 200));
      return { ok: true };
    }
    if (provider === "resend" && apiKey) {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: "Bearer " + apiKey, "Content-Type": "application/json" },
        body: JSON.stringify({ from, to: [to], subject, html: htmlBody, text }),
      });
      if (!r.ok) throw new Error("Resend " + r.status + " " + (await r.text()).slice(0, 200));
      return { ok: true };
    }
    // Mode console : aucun fournisseur configuré.
    console.log(`\n[mail] À: ${to}\n[mail] Objet: ${subject}\n[mail] ${text.replace(/\n/g, "\n[mail] ")}\n`);
    return { ok: true, console: true };
  } catch (e) {
    console.error("[mail] échec d'envoi:", e.message);
    return { ok: false, error: e.message };
  }
}

export const mailConfigured = () => config.mail.provider !== "console" && !!config.mail.apiKey;
