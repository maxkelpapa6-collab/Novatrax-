// Administration : statistiques, utilisateurs, modération, messages et journal d'audit.
import { all, get, run, insert, update } from "../db.js";
import { bad, forbidden, notFound, readJson, sendJson } from "../lib/http.js";
import { requireAdmin, auditBy, selfView, notify } from "../auth.js";
import { sendMail, mailConfigured } from "../mail.js";
import { rangeBounds } from "./contacts.js";
import { getCountry } from "../../shared/countries.js";

const PUBLIC_USER_COLS = `id, email, role, username, first_name, last_name, country, phone, email_verified, account_status,
  referral_code, referred_by, blocked_reason, blocked_at, blocked_by, share_contacts, marketplace_banned,
  marketplace_banned_reason, unsubscribed, last_login_at, created_date, updated_date`;

// Sélection des destinataires d'un message.
function audience(a = {}) {
  const where = ["email_verified = 1"];
  const params = [];
  switch (a.type) {
    case "active": where.push("account_status = 'active'"); break;
    case "country":
      if (!getCountry(a.country)) throw bad("Choisissez un pays.");
      where.push("account_status = 'active'", "country = ?"); params.push(a.country); break;
    case "period": {
      const [f, t] = rangeBounds("custom", a.date_from, a.date_to);
      if (!f && !t) throw bad("Indiquez une période d'inscription.");
      where.push("account_status = 'active'");
      if (f) { where.push("created_date >= ?"); params.push(f); }
      if (t) { where.push("created_date < ?"); params.push(t); }
      break;
    }
    case "user":
      if (!a.user_id) throw bad("Choisissez un membre.");
      where.push("id = ?"); params.push(a.user_id); break;
    case "all":
    default:
      where.push("account_status = 'active'");
  }
  return all(`SELECT id, email, first_name, unsubscribed FROM users WHERE ${where.join(" AND ")}`, ...params);
}

const describeAudience = (a = {}) => ({
  all: "Tous les membres", active: "Membres actifs uniquement",
  country: "Pays : " + (getCountry(a.country)?.name || a.country),
  period: `Inscrits du ${a.date_from || "…"} au ${a.date_to || "…"}`,
  user: "Membre individuel",
}[a.type] || "Tous les membres");

export default function adminRoutes(r) {
  r.get("/api/admin/stats", async (req, res) => {
    requireAdmin(req);
    const [today] = rangeBounds("today");
    const n = (sql, ...p) => get(sql, ...p).n;
    sendJson(res, 200, {
      members: n("SELECT COUNT(*) AS n FROM users WHERE email_verified = 1"),
      today: n("SELECT COUNT(*) AS n FROM users WHERE email_verified = 1 AND created_date >= ?", today),
      suspended: n("SELECT COUNT(*) AS n FROM users WHERE account_status = 'suspended'"),
      formations: n("SELECT COUNT(*) AS n FROM formations"),
      apps: n("SELECT COUNT(*) AS n FROM applications"),
      products_pending: n("SELECT COUNT(*) AS n FROM marketplace_products WHERE status = 'pending'"),
      products_published: n("SELECT COUNT(*) AS n FROM marketplace_products WHERE status = 'published'"),
      disputes: n("SELECT COUNT(*) AS n FROM marketplace_orders WHERE status = 'disputed'"),
      audits: n("SELECT COUNT(*) AS n FROM audit_logs"),
      mail_configured: mailConfigured(),
    });
  });

  r.get("/api/admin/users", async (req, res, { query }) => {
    requireAdmin(req);
    const where = [];
    const params = [];
    const s = String(query.get("search") || "").trim().slice(0, 80);
    if (s) {
      where.push("(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR username LIKE ? OR phone LIKE ? OR referral_code LIKE ?)");
      for (let i = 0; i < 6; i++) params.push("%" + s + "%");
    }
    const st = query.get("status");
    if (st === "active" || st === "suspended") { where.push("account_status = ?"); params.push(st); }
    if (query.get("verified") === "no") where.push("email_verified = 0");
    else where.push("email_verified = 1");
    if (query.get("role") === "admin") where.push("role = 'admin'");
    const limit = 50;
    const offset = Math.max(0, Number(query.get("offset")) || 0);
    const w = where.length ? "WHERE " + where.join(" AND ") : "";
    const items = all(`SELECT ${PUBLIC_USER_COLS} FROM users ${w} ORDER BY created_date DESC LIMIT ? OFFSET ?`, ...params, limit + 1, offset);
    sendJson(res, 200, { items: items.slice(0, limit), has_more: items.length > limit, total: get(`SELECT COUNT(*) AS n FROM users ${w}`, ...params).n });
  });

  r.get("/api/admin/users/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const u = get(`SELECT ${PUBLIC_USER_COLS} FROM users WHERE id = ?`, params.id);
    if (!u) throw notFound("Utilisateur introuvable.");
    const sponsor = u.referred_by ? get("SELECT id, email, username, first_name, last_name FROM users WHERE id = ?", u.referred_by) : null;
    const referrals = all("SELECT id, email, username, first_name, last_name, country, account_status, created_date FROM users WHERE referred_by = ? AND email_verified = 1 ORDER BY created_date DESC LIMIT 100", u.id);
    const history = all("SELECT * FROM audit_logs WHERE target_user_id = ? ORDER BY created_date DESC LIMIT 50", u.id);
    const products = all("SELECT id, name, status, price_fcfa, created_date FROM marketplace_products WHERE seller_id = ? ORDER BY created_date DESC LIMIT 50", u.id);
    const orders = all("SELECT id, order_ref, product_name, product_price_fcfa, status, buyer_id, seller_id, created_date FROM marketplace_orders WHERE buyer_id = ? OR seller_id = ? ORDER BY created_date DESC LIMIT 50", u.id, u.id);
    auditBy(admin, "admin_user_sheet_view", { target_user_id: u.id, details: u.email });
    sendJson(res, 200, {
      user: u, sponsor, referrals,
      referrals_total: get("SELECT COUNT(*) AS n FROM users WHERE referred_by = ? AND email_verified = 1", u.id).n,
      history, products, orders,
    });
  });

  r.post("/api/admin/users/:id/moderate", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const u = get("SELECT * FROM users WHERE id = ?", params.id);
    if (!u) throw notFound("Utilisateur introuvable.");
    const reason = String(b.reason || "").trim().slice(0, 500) || null;
    const t = new Date().toISOString();
    let next;
    switch (b.action) {
      case "block":
        if (u.id === admin.id) throw forbidden("Vous ne pouvez pas bloquer votre propre compte.");
        if (!reason) throw bad("Indiquez le motif du blocage.");
        next = update("users", u.id, { account_status: "suspended", blocked_reason: reason, blocked_at: t, blocked_by: admin.email, token_version: (u.token_version || 0) + 1 });
        if (u.email) await sendMail(u.email, "Votre compte NOVATRAX a été bloqué", `Votre compte a été suspendu par l'administration.\nMotif : ${reason}\n\nVos données sont conservées. Contactez le support pour toute question.`);
        auditBy(admin, "user_block", { target_user_id: u.id, reason, details: u.email });
        break;
      case "unblock":
        next = update("users", u.id, { account_status: "active", blocked_reason: null, blocked_at: null, blocked_by: null });
        await notify(next, "Compte réactivé", "Votre compte NOVATRAX a été réactivé par l'administration. Bon retour parmi nous !");
        auditBy(admin, "user_unblock", { target_user_id: u.id, reason, details: u.email });
        break;
      case "verify_email":
        next = update("users", u.id, { email_verified: true });
        auditBy(admin, "user_email_manual_verify", { target_user_id: u.id, reason, details: u.email });
        break;
      case "make_admin":
        next = update("users", u.id, { role: "admin" });
        auditBy(admin, "user_role_admin", { target_user_id: u.id, details: u.email });
        break;
      case "remove_admin":
        if (u.id === admin.id) throw forbidden("Vous ne pouvez pas retirer vos propres droits.");
        if (get("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND account_status = 'active'").n <= 1) throw bad("Il doit rester au moins un administrateur.");
        next = update("users", u.id, { role: "user" });
        auditBy(admin, "user_role_user", { target_user_id: u.id, details: u.email });
        break;
      case "logout":
        next = update("users", u.id, { token_version: (u.token_version || 0) + 1 });
        auditBy(admin, "user_force_logout", { target_user_id: u.id, details: u.email });
        break;
      default:
        throw bad("Action inconnue.");
    }
    sendJson(res, 200, { user: selfView(next) });
  });

  // ---------- Messages aux membres ----------
  r.get("/api/admin/messages", async (req, res) => {
    requireAdmin(req);
    sendJson(res, 200, { items: all("SELECT * FROM email_campaigns ORDER BY created_date DESC LIMIT 50"), mail_configured: mailConfigured() });
  });

  r.post("/api/admin/messages/count", async (req, res) => {
    requireAdmin(req);
    const b = await readJson(req);
    sendJson(res, 200, { count: audience(b.audience).length });
  });

  r.post("/api/admin/messages/test", async (req, res) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const subject = String(b.subject || "").trim();
    const body = String(b.body || "").trim();
    if (!subject || !body) throw bad("Renseignez l'objet et le contenu du message.");
    const r2 = await sendMail(admin.email, "[TEST] " + subject, body);
    auditBy(admin, "email_test_send", { details: subject });
    sendJson(res, 200, { ok: r2.ok, console: !!r2.console, error: r2.error });
  });

  r.post("/api/admin/messages", async (req, res) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const subject = String(b.subject || "").trim().slice(0, 150);
    const body = String(b.body || "").trim().slice(0, 10000);
    if (subject.length < 3) throw bad("L'objet du message est obligatoire.");
    if (body.length < 3) throw bad("Le contenu du message est obligatoire.");
    const channels = { inbox: b.channels?.inbox !== false, email: b.channels?.email === true };
    if (!channels.inbox && !channels.email) throw bad("Choisissez au moins un canal d'envoi.");
    const recipients = audience(b.audience);
    if (!recipients.length) throw bad("Aucun destinataire ne correspond à cette sélection.");
    const c = insert("email_campaigns", {
      subject, body_text: body, audience_type: b.audience?.type || "all", audience_details: describeAudience(b.audience),
      channels: [channels.inbox && "inbox", channels.email && "email"].filter(Boolean).join(","),
      recipients_count: recipients.length, sent_count: 0, failed_count: 0, status: "sending",
      sent_by: admin.id, sent_by_email: admin.email,
    });
    if (channels.inbox) {
      for (const u of recipients) insert("inbox_messages", { user_id: u.id, title: subject, body_text: body, type: "admin_message", campaign_id: c.id, read: false });
    }
    auditBy(admin, "email_campaign_send", { target_id: c.id, details: `${subject} — ${recipients.length} destinataire(s), ${describeAudience(b.audience)}` });
    sendJson(res, 200, { ok: true, campaign: c });

    // Envoi des e-mails en arrière-plan, un par un.
    (async () => {
      let sent = 0, failed = 0;
      if (channels.email) {
        for (const u of recipients) {
          if (u.unsubscribed) continue;
          const r2 = await sendMail(u.email, subject, body);
          insert("email_delivery_logs", { campaign_id: c.id, recipient_email: u.email, recipient_user_id: u.id, status: r2.ok ? "sent" : "failed", error: r2.error || null });
          r2.ok ? sent++ : failed++;
        }
      } else sent = recipients.length;
      update("email_campaigns", c.id, { sent_count: sent, failed_count: failed, status: failed === 0 ? "sent" : sent === 0 ? "failed" : "partial" });
    })().catch((e) => console.error("[campagne]", e));
  });

  // ---------- Journal d'audit ----------
  r.get("/api/admin/audit", async (req, res, { query }) => {
    requireAdmin(req);
    const limit = 50;
    const offset = Math.max(0, Number(query.get("offset")) || 0);
    const action = query.get("action");
    const items = action
      ? all("SELECT * FROM audit_logs WHERE action LIKE ? ORDER BY created_date DESC LIMIT ? OFFSET ?", action + "%", limit + 1, offset)
      : all("SELECT * FROM audit_logs ORDER BY created_date DESC LIMIT ? OFFSET ?", limit + 1, offset);
    sendJson(res, 200, { items: items.slice(0, limit), has_more: items.length > limit });
  });
}
