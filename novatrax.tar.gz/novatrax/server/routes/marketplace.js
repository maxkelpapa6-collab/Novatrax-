// Marketplace : annonces modérées, commandes avec suivi de statut.
// Aucun moyen de paiement n'est intégré : le paiement est convenu entre acheteur
// et vendeur, puis confirmé manuellement par le vendeur dans l'application.
import crypto from "node:crypto";
import { all, get, run, insert, update, tx } from "../db.js";
import { bad, forbidden, notFound, readJson, sendJson } from "../lib/http.js";
import { requireUser, requireAdmin, auditBy, audit, notify, displayName, rateLimit } from "../auth.js";
import { config } from "../config.js";

export const MIN_PRICE = 100;
export const MAX_PRICE = 5_000_000;
export const MAX_DESC = 500;
const BLOCKED_THRESHOLD = 3;

const LINK_RE = /(https?:\/\/|www\.|wa\.me|chat\.whatsapp\.com|whatsapp\.com|t\.me|telegram\.|bit\.ly|tinyurl\.com|cutt\.ly|is\.gd|goo\.gl|rebrand\.ly|drive\.google|mega\.nz)/i;
const hasLink = (t) => !!t && LINK_RE.test(String(t));

export function amounts(price) {
  const p = Math.round(Number(price));
  const commission = Math.round(p * config.marketplaceCommissionRate);
  return { product_price_fcfa: p, commission_fcfa: commission, net_fcfa: p - commission };
}

const forbiddenValues = () => all("SELECT value FROM marketplace_rules WHERE active = 1").map((r) => r.value.toLowerCase().trim());

export function validateProduct(f) {
  const name = String(f.name || "").trim();
  const description = String(f.description || "").trim();
  const price = Math.round(Number(f.price_fcfa));
  const phone = String(f.seller_phone || "").trim();
  const category = String(f.category || "").trim();
  const image = String(f.image_url || "").trim();
  if (name.length < 3 || name.length > 100) return { ok: false, reason: "Le nom du produit doit contenir entre 3 et 100 caractères." };
  if (description.length > MAX_DESC) return { ok: false, reason: `La description ne peut pas dépasser ${MAX_DESC} caractères.` };
  if (hasLink(name) || hasLink(description)) {
    return { ok: false, blocking: true, reason: "Les liens externes sont strictement interdits dans les annonces (sites, WhatsApp, Telegram, raccourcisseurs…). Le numéro de téléphone est le seul canal de contact autorisé." };
  }
  const lower = (name + " " + description).toLowerCase();
  const hit = forbiddenValues().find((v) => v.length >= 3 && lower.includes(v));
  if (hit) return { ok: false, blocking: true, reason: `Produit ou service non autorisé sur la Marketplace (« ${hit} »).` };
  if (!Number.isFinite(price) || price < MIN_PRICE || price > MAX_PRICE) return { ok: false, reason: `Le prix doit être compris entre ${MIN_PRICE} et ${MAX_PRICE.toLocaleString("fr-FR")} FCFA.` };
  const digits = phone.replace(/\D/g, "");
  if (!/^[+0-9][0-9\s.\-+]{6,19}$/.test(phone) || digits.length < 6 || digits.length > 15) return { ok: false, reason: "Numéro de téléphone du vendeur invalide : indiquez un numéro que les acheteurs pourront appeler." };
  if (!category || !get("SELECT id FROM marketplace_categories WHERE name = ? AND active = 1", category)) return { ok: false, reason: "Choisissez une catégorie autorisée." };
  if (!image || !/^(https?:\/\/|\/uploads\/)/i.test(image)) return { ok: false, reason: "La photo du produit est obligatoire." };
  return { ok: true, fields: { name, description, price_fcfa: price, seller_phone: phone, category, image_url: image } };
}

const orderRef = () => "CMD-" + crypto.randomBytes(5).toString("hex").toUpperCase();
const ACTIVE = ["awaiting_payment", "processing", "disputed"];
const fcfa = (n) => Number(n || 0).toLocaleString("fr-FR") + " FCFA";

// Vue d'une commande selon le rôle : les coordonnées de l'autre partie restent visibles
// pour organiser le paiement et la livraison.
const orderView = (o) => o;

export default function marketplaceRoutes(r) {
  r.get("/api/marketplace/config", async (req, res) => {
    requireUser(req);
    sendJson(res, 200, { commission_rate: config.marketplaceCommissionRate, min_price: MIN_PRICE, max_price: MAX_PRICE, max_description: MAX_DESC });
  });

  r.get("/api/marketplace/categories", async (req, res) => {
    requireUser(req);
    sendJson(res, 200, { items: all("SELECT * FROM marketplace_categories WHERE active = 1 ORDER BY sort_order, name") });
  });

  r.get("/api/marketplace/products", async (req, res, { query }) => {
    requireUser(req);
    const where = ["status = 'published'"];
    const params = [];
    const s = String(query.get("search") || "").trim().slice(0, 80);
    if (s) { where.push("name LIKE ?"); params.push("%" + s + "%"); }
    const cat = query.get("category");
    if (cat) { where.push("category = ?"); params.push(cat); }
    const min = Math.round(Number(query.get("min")));
    const max = Math.round(Number(query.get("max")));
    if (min > 0) { where.push("price_fcfa >= ?"); params.push(min); }
    if (max > 0) { where.push("price_fcfa <= ?"); params.push(max); }
    const sort = { price_asc: "price_fcfa ASC", price_desc: "price_fcfa DESC" }[query.get("sort")] || "created_date DESC";
    const limit = 30;
    const offset = Math.max(0, Number(query.get("offset")) || 0);
    const rows = all(
      `SELECT id, name, description, image_url, price_fcfa, category, seller_name, created_date FROM marketplace_products
       WHERE ${where.join(" AND ")} ORDER BY ${sort} LIMIT ? OFFSET ?`, ...params, limit + 1, offset
    );
    sendJson(res, 200, { items: rows.slice(0, limit), has_more: rows.length > limit });
  });

  r.get("/api/marketplace/products/:id", async (req, res, { params }) => {
    const u = requireUser(req);
    const p = get("SELECT * FROM marketplace_products WHERE id = ?", params.id);
    if (!p || (p.status !== "published" && p.seller_id !== u.id && u.role !== "admin")) throw notFound("Produit introuvable.");
    const { seller_email, ...pub } = p;
    sendJson(res, 200, { ...pub, is_mine: p.seller_id === u.id, ...amounts(p.price_fcfa) });
  });

  // ---------- Espace vendeur ----------
  r.get("/api/marketplace/my-products", async (req, res) => {
    const u = requireUser(req);
    sendJson(res, 200, { items: all("SELECT * FROM marketplace_products WHERE seller_id = ? ORDER BY created_date DESC", u.id) });
  });

  r.get("/api/marketplace/seller-summary", async (req, res) => {
    const u = requireUser(req);
    const s = get(
      `SELECT COUNT(*) AS completed, COALESCE(SUM(product_price_fcfa),0) AS gross, COALESCE(SUM(commission_fcfa),0) AS commission, COALESCE(SUM(net_fcfa),0) AS net
       FROM marketplace_orders WHERE seller_id = ? AND status = 'completed'`, u.id
    );
    const pending = get(
      "SELECT COUNT(*) AS n, COALESCE(SUM(net_fcfa),0) AS net FROM marketplace_orders WHERE seller_id = ? AND status IN ('awaiting_payment','processing','disputed')", u.id
    );
    sendJson(res, 200, { ...s, pending_orders: pending.n, pending_net: pending.net, banned: u.marketplace_banned, banned_reason: u.marketplace_banned_reason, commission_rate: config.marketplaceCommissionRate });
  });

  async function saveProduct(u, body, existing) {
    if (u.marketplace_banned) throw forbidden("Votre accès vendeur à la Marketplace est suspendu." + (u.marketplace_banned_reason ? " Motif : " + u.marketplace_banned_reason : ""));
    rateLimit("mkp:" + u.id, 30, 60 * 60_000);
    const check = validateProduct(body);
    if (!check.ok && check.blocking) {
      // Annonce bloquée automatiquement et conservée pour la modération.
      const fields = {
        name: String(body.name || "").slice(0, 100), description: String(body.description || "").slice(0, MAX_DESC),
        image_url: body.image_url || null, price_fcfa: Math.round(Number(body.price_fcfa)) || 0,
        category: body.category || null, seller_phone: body.seller_phone || null, status: "blocked", blocked_reason: check.reason,
      };
      const p = existing ? update("marketplace_products", existing.id, fields)
        : insert("marketplace_products", { ...fields, seller_id: u.id, seller_email: u.email, seller_name: displayName(u) });
      audit({ action: "marketplace_product_blocked", admin_email: "system", target_user_id: u.id, target_id: p.id, details: check.reason });
      const since = new Date(Date.now() - 30 * 86400000).toISOString();
      const n = get("SELECT COUNT(*) AS n FROM marketplace_products WHERE seller_id = ? AND status = 'blocked' AND updated_date >= ?", u.id, since).n;
      let suspended = false;
      if (n >= BLOCKED_THRESHOLD) {
        update("users", u.id, {
          marketplace_banned: true, marketplace_banned_at: new Date().toISOString(), marketplace_banned_by: "system",
          marketplace_banned_reason: `${n} annonces bloquées en 30 jours (infractions répétées).`,
        });
        audit({ action: "marketplace_seller_auto_suspended", admin_email: "system", target_user_id: u.id, details: `${n} annonces bloquées en 30 jours` });
        await notify(u, "Accès vendeur suspendu", "Suite à plusieurs annonces non conformes, votre accès vendeur à la Marketplace est suspendu. Contactez le support pour un réexamen.");
        suspended = true;
      }
      return { blocked: true, reason: check.reason, suspended, product_id: p.id };
    }
    if (!check.ok) throw bad(check.reason);
    const fields = { ...check.fields, status: "pending", blocked_reason: null, rejection_reason: null, seller_name: displayName(u) };
    const p = existing ? update("marketplace_products", existing.id, fields)
      : insert("marketplace_products", { ...fields, seller_id: u.id, seller_email: u.email });
    audit({ action: existing ? "marketplace_product_update" : "marketplace_product_submit", admin_email: u.email, target_user_id: u.id, target_id: p.id, details: p.name });
    return { ok: true, product_id: p.id, status: "pending" };
  }

  r.post("/api/marketplace/my-products", async (req, res) => {
    const u = requireUser(req);
    sendJson(res, 200, await saveProduct(u, await readJson(req), null));
  });

  r.patch("/api/marketplace/my-products/:id", async (req, res, { params }) => {
    const u = requireUser(req);
    const p = get("SELECT * FROM marketplace_products WHERE id = ? AND seller_id = ?", params.id, u.id);
    if (!p) throw notFound("Annonce introuvable.");
    const body = await readJson(req);
    // Masquer / réafficher une annonce publiée sans nouvelle validation
    if (Object.keys(body).length === 1 && body.visibility) {
      if (body.visibility === "hidden" && p.status === "published") return sendJson(res, 200, update("marketplace_products", p.id, { status: "hidden" }));
      if (body.visibility === "visible" && p.status === "hidden") return sendJson(res, 200, update("marketplace_products", p.id, { status: "published" }));
      throw bad("Changement de visibilité impossible pour cette annonce.");
    }
    if (get(`SELECT 1 AS x FROM marketplace_orders WHERE product_id = ? AND status IN ('awaiting_payment','processing','disputed')`, p.id)) {
      throw bad("Impossible de modifier cette annonce : une commande est en cours.");
    }
    sendJson(res, 200, await saveProduct(u, body, p));
  });

  r.delete("/api/marketplace/my-products/:id", async (req, res, { params }) => {
    const u = requireUser(req);
    const p = get("SELECT * FROM marketplace_products WHERE id = ? AND seller_id = ?", params.id, u.id);
    if (!p) throw notFound("Annonce introuvable.");
    if (get(`SELECT 1 AS x FROM marketplace_orders WHERE product_id = ? AND status IN ('awaiting_payment','processing','disputed')`, p.id)) {
      throw bad("Impossible de supprimer cette annonce : une commande est en cours.");
    }
    run("DELETE FROM marketplace_products WHERE id = ?", p.id);
    audit({ action: "marketplace_product_delete", admin_email: u.email, target_user_id: u.id, target_id: p.id, details: p.name });
    sendJson(res, 200, { ok: true });
  });

  // ---------- Commandes ----------
  r.post("/api/marketplace/orders", async (req, res) => {
    const u = requireUser(req);
    rateLimit("order:" + u.id, 20, 60 * 60_000);
    const b = await readJson(req);
    const p = get("SELECT * FROM marketplace_products WHERE id = ? AND status = 'published'", b.product_id);
    if (!p) throw notFound("Ce produit n'est plus disponible sur la Marketplace.");
    if (p.seller_id === u.id) throw bad("Vous ne pouvez pas commander votre propre produit.");
    if (get("SELECT 1 AS x FROM marketplace_orders WHERE buyer_id = ? AND product_id = ? AND status = 'awaiting_payment'", u.id, p.id)) {
      throw bad("Vous avez déjà une commande en attente pour ce produit. Consultez « Mes achats ».");
    }
    const seller = get("SELECT * FROM users WHERE id = ?", p.seller_id);
    const o = insert("marketplace_orders", {
      order_ref: orderRef(), product_id: p.id, product_name: p.name, product_image: p.image_url,
      ...amounts(p.price_fcfa),
      buyer_id: u.id, buyer_email: u.email, buyer_name: displayName(u), buyer_phone: u.phone,
      seller_id: p.seller_id, seller_email: seller?.email, seller_name: p.seller_name, seller_phone: p.seller_phone,
      buyer_note: String(b.note || "").trim().slice(0, 300) || null,
      status: "awaiting_payment",
    });
    audit({ action: "marketplace_order_created", admin_email: u.email, target_user_id: u.id, target_id: o.id, details: `${o.order_ref} — ${p.name} (${fcfa(p.price_fcfa)})` });
    if (seller) await notify(seller, "Nouvelle commande — " + p.name,
      `${o.buyer_name} a commandé « ${p.name} » (${fcfa(o.product_price_fcfa)}), réf. ${o.order_ref}.\nContactez l'acheteur au ${o.buyer_phone || "numéro indiqué"} pour convenir du paiement et de la livraison, puis confirmez la réception du paiement dans « Ma boutique ».`);
    sendJson(res, 201, o);
  });

  r.get("/api/marketplace/orders", async (req, res, { query }) => {
    const u = requireUser(req);
    const role = query.get("role") === "seller" ? "seller_id" : "buyer_id";
    sendJson(res, 200, { items: all(`SELECT * FROM marketplace_orders WHERE ${role} = ? ORDER BY created_date DESC LIMIT 200`, u.id).map(orderView) });
  });

  r.post("/api/marketplace/orders/:id/action", async (req, res, { params }) => {
    const u = requireUser(req);
    const b = await readJson(req);
    const o = get("SELECT * FROM marketplace_orders WHERE id = ?", params.id);
    if (!o || (o.buyer_id !== u.id && o.seller_id !== u.id)) throw notFound("Commande introuvable.");
    const isBuyer = o.buyer_id === u.id;
    const buyer = { id: o.buyer_id, email: o.buyer_email };
    const seller = { id: o.seller_id, email: o.seller_email };
    const t = new Date().toISOString();
    let next;

    switch (b.action) {
      case "confirm_payment": // le vendeur confirme avoir reçu le paiement
        if (isBuyer || o.status !== "awaiting_payment") throw bad("Action impossible pour cette commande.");
        next = update("marketplace_orders", o.id, { status: "processing", paid_at: t });
        await notify(buyer, "Paiement confirmé — " + o.product_name, `Le vendeur a confirmé la réception de votre paiement pour la commande ${o.order_ref}. Confirmez la réception du produit dans « Mes achats » une fois livré.`);
        break;
      case "cancel":
        if (o.status !== "awaiting_payment") throw bad("Seule une commande en attente de paiement peut être annulée.");
        next = update("marketplace_orders", o.id, { status: "cancelled", cancelled_at: t, resolution_note: (isBuyer ? "Annulée par l'acheteur" : "Annulée par le vendeur") + (b.reason ? " : " + String(b.reason).slice(0, 300) : "") });
        await notify(isBuyer ? seller : buyer, "Commande annulée — " + o.product_name, `La commande ${o.order_ref} a été annulée par ${isBuyer ? "l'acheteur" : "le vendeur"}.`);
        break;
      case "confirm_receipt":
        if (!isBuyer || o.status !== "processing") throw bad("Action impossible pour cette commande.");
        next = update("marketplace_orders", o.id, { status: "completed", completed_at: t });
        audit({ action: "marketplace_order_completed", admin_email: u.email, target_id: o.id, details: o.order_ref });
        await notify(seller, "Vente terminée — " + o.product_name, `L'acheteur a confirmé la réception de la commande ${o.order_ref}. Vente terminée.`);
        break;
      case "dispute": {
        if (!isBuyer || !["processing", "awaiting_payment"].includes(o.status)) throw bad("Action impossible pour cette commande.");
        const reason = String(b.reason || "").trim();
        if (reason.length < 10) throw bad("Décrivez le problème rencontré (10 caractères minimum).");
        next = update("marketplace_orders", o.id, { status: "disputed", dispute_reason: reason.slice(0, 1000) });
        audit({ action: "marketplace_order_disputed", admin_email: u.email, target_id: o.id, details: `${o.order_ref} : ${reason.slice(0, 200)}` });
        await notify(seller, "Litige ouvert — " + o.product_name, `L'acheteur a ouvert un litige sur la commande ${o.order_ref}. L'administration NOVATRAX examine la demande.`);
        for (const a of all("SELECT id, email, unsubscribed FROM users WHERE role = 'admin' AND account_status = 'active'")) {
          await notify(a, "Litige Marketplace à examiner", `Commande ${o.order_ref} (${o.product_name}) : ${reason.slice(0, 300)}`, { email: true });
        }
        break;
      }
      default:
        throw bad("Action inconnue.");
    }
    sendJson(res, 200, next);
  });

  // ---------- Administration ----------
  r.get("/api/admin/marketplace/products", async (req, res, { query }) => {
    requireAdmin(req);
    const where = [];
    const params = [];
    const st = query.get("status");
    if (st) { where.push("status = ?"); params.push(st); }
    const s = String(query.get("search") || "").trim();
    if (s) { where.push("(name LIKE ? OR seller_name LIKE ? OR seller_email LIKE ?)"); params.push(`%${s}%`, `%${s}%`, `%${s}%`); }
    const items = all(`SELECT * FROM marketplace_products ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY updated_date DESC LIMIT 200`, ...params);
    const counts = Object.fromEntries(all("SELECT status, COUNT(*) AS n FROM marketplace_products GROUP BY status").map((r) => [r.status, r.n]));
    sendJson(res, 200, { items, counts });
  });

  r.post("/api/admin/marketplace/products/:id/moderate", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const p = get("SELECT * FROM marketplace_products WHERE id = ?", params.id);
    if (!p) throw notFound("Annonce introuvable.");
    const reason = String(b.reason || "").trim().slice(0, 500) || null;
    const seller = get("SELECT * FROM users WHERE id = ?", p.seller_id);
    let next;
    switch (b.action) {
      case "publish":
        next = update("marketplace_products", p.id, { status: "published", rejection_reason: null, blocked_reason: null });
        await notify(seller, "Annonce publiée — " + p.name, "Votre annonce a été validée et est désormais visible sur la Marketplace.");
        break;
      case "reject":
        if (!reason) throw bad("Indiquez le motif du refus.");
        next = update("marketplace_products", p.id, { status: "rejected", rejection_reason: reason });
        await notify(seller, "Annonce refusée — " + p.name, "Votre annonce n'a pas été validée. Motif : " + reason);
        break;
      case "block":
        if (!reason) throw bad("Indiquez le motif du blocage.");
        next = update("marketplace_products", p.id, { status: "blocked", blocked_reason: reason });
        await notify(seller, "Annonce bloquée — " + p.name, "Votre annonce a été bloquée par l'administration. Motif : " + reason);
        break;
      case "hide":
        next = update("marketplace_products", p.id, { status: "hidden" });
        break;
      case "pending":
        next = update("marketplace_products", p.id, { status: "pending" });
        break;
      case "delete":
        if (get(`SELECT 1 AS x FROM marketplace_orders WHERE product_id = ? AND status IN ('awaiting_payment','processing','disputed')`, p.id)) throw bad("Une commande est en cours sur cette annonce.");
        run("DELETE FROM marketplace_products WHERE id = ?", p.id);
        next = { deleted: true };
        break;
      default:
        throw bad("Action inconnue.");
    }
    auditBy(admin, "marketplace_admin_product", { target_user_id: p.seller_id, target_id: p.id, reason, details: `${b.action} — ${p.name}` });
    sendJson(res, 200, next);
  });

  r.get("/api/admin/marketplace/categories", async (req, res) => {
    requireAdmin(req);
    sendJson(res, 200, { items: all("SELECT c.*, (SELECT COUNT(*) FROM marketplace_products p WHERE p.category = c.name) AS products FROM marketplace_categories c ORDER BY sort_order, name") });
  });
  r.post("/api/admin/marketplace/categories", async (req, res) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const name = String(b.name || "").trim().slice(0, 60);
    if (name.length < 2) throw bad("Nom de catégorie trop court.");
    if (get("SELECT id FROM marketplace_categories WHERE name = ?", name)) throw bad("Cette catégorie existe déjà.");
    const max = get("SELECT COALESCE(MAX(sort_order), 0) AS m FROM marketplace_categories").m;
    const c = insert("marketplace_categories", { name, active: true, sort_order: max + 1 });
    auditBy(admin, "marketplace_admin_category", { target_id: c.id, details: "Création : " + name });
    sendJson(res, 201, c);
  });
  r.patch("/api/admin/marketplace/categories/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const c = get("SELECT * FROM marketplace_categories WHERE id = ?", params.id);
    if (!c) throw notFound();
    const b = await readJson(req);
    const patch = {};
    if (b.active !== undefined) patch.active = b.active === true;
    if (b.sort_order !== undefined) patch.sort_order = Math.round(Number(b.sort_order)) || 0;
    if (b.name !== undefined) {
      const name = String(b.name).trim().slice(0, 60);
      if (name.length < 2) throw bad("Nom de catégorie trop court.");
      tx(() => {
        run("UPDATE marketplace_products SET category = ? WHERE category = ?", name, c.name);
        patch.name = name;
      });
    }
    const next = update("marketplace_categories", c.id, patch);
    auditBy(admin, "marketplace_admin_category", { target_id: c.id, details: "Modification : " + next.name });
    sendJson(res, 200, next);
  });
  r.delete("/api/admin/marketplace/categories/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const c = get("SELECT * FROM marketplace_categories WHERE id = ?", params.id);
    if (!c) throw notFound();
    if (get("SELECT 1 AS x FROM marketplace_products WHERE category = ?", c.name)) throw bad("Des annonces utilisent cette catégorie : désactivez-la plutôt.");
    run("DELETE FROM marketplace_categories WHERE id = ?", c.id);
    auditBy(admin, "marketplace_admin_category", { target_id: c.id, details: "Suppression : " + c.name });
    sendJson(res, 200, { ok: true });
  });

  r.get("/api/admin/marketplace/rules", async (req, res) => {
    requireAdmin(req);
    sendJson(res, 200, { items: all("SELECT * FROM marketplace_rules ORDER BY created_date DESC") });
  });
  r.post("/api/admin/marketplace/rules", async (req, res) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const value = String(b.value || "").trim().toLowerCase().slice(0, 80);
    if (value.length < 3) throw bad("Le terme interdit doit contenir au moins 3 caractères.");
    const rule = insert("marketplace_rules", { value, note: String(b.note || "").trim().slice(0, 200) || null, active: true });
    auditBy(admin, "marketplace_admin_rule", { target_id: rule.id, details: "Ajout : " + value });
    sendJson(res, 201, rule);
  });
  r.delete("/api/admin/marketplace/rules/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const rule = get("SELECT * FROM marketplace_rules WHERE id = ?", params.id);
    if (!rule) throw notFound();
    run("DELETE FROM marketplace_rules WHERE id = ?", rule.id);
    auditBy(admin, "marketplace_admin_rule", { target_id: rule.id, details: "Suppression : " + rule.value });
    sendJson(res, 200, { ok: true });
  });

  r.get("/api/admin/marketplace/orders", async (req, res, { query }) => {
    requireAdmin(req);
    const st = query.get("status");
    const items = st
      ? all("SELECT * FROM marketplace_orders WHERE status = ? ORDER BY updated_date DESC LIMIT 200", st)
      : all("SELECT * FROM marketplace_orders ORDER BY updated_date DESC LIMIT 200");
    const counts = Object.fromEntries(all("SELECT status, COUNT(*) AS n FROM marketplace_orders GROUP BY status").map((r) => [r.status, r.n]));
    const totals = get("SELECT COUNT(*) AS n, COALESCE(SUM(product_price_fcfa),0) AS gross, COALESCE(SUM(commission_fcfa),0) AS commission FROM marketplace_orders WHERE status = 'completed'");
    sendJson(res, 200, { items, counts, totals });
  });

  r.post("/api/admin/marketplace/orders/:id/resolve", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const o = get("SELECT * FROM marketplace_orders WHERE id = ?", params.id);
    if (!o) throw notFound("Commande introuvable.");
    if (!ACTIVE.includes(o.status)) throw bad("Cette commande est déjà clôturée.");
    const note = String(b.note || "").trim().slice(0, 500) || null;
    const t = new Date().toISOString();
    const map = {
      complete: { status: "completed", completed_at: t, label: "terminée" },
      cancel: { status: "cancelled", cancelled_at: t, label: "annulée" },
      refund: { status: "refunded", refunded_at: t, label: "marquée comme remboursée" },
    };
    const m = map[b.action];
    if (!m) throw bad("Action inconnue.");
    if (b.action === "refund" && !note) throw bad("Indiquez une note de remboursement (moyen et référence du remboursement effectué).");
    const { label, ...patch } = m;
    const next = update("marketplace_orders", o.id, { ...patch, resolution_note: note, reviewed_by: admin.email, reviewed_at: t });
    auditBy(admin, "marketplace_admin_order", { target_id: o.id, reason: note, details: `${o.order_ref} ${label}` });
    const text = `La commande ${o.order_ref} (${o.product_name}) a été ${label} par l'administration.` + (note ? "\nNote : " + note : "");
    await notify({ id: o.buyer_id, email: o.buyer_email }, "Décision sur votre commande", text);
    await notify({ id: o.seller_id, email: o.seller_email }, "Décision sur une vente", text);
    sendJson(res, 200, next);
  });

  r.post("/api/admin/users/:id/marketplace-ban", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const b = await readJson(req);
    const u = get("SELECT * FROM users WHERE id = ?", params.id);
    if (!u) throw notFound("Utilisateur introuvable.");
    if (b.banned === true) {
      const reason = String(b.reason || "").trim().slice(0, 300);
      if (!reason) throw bad("Indiquez le motif du bannissement.");
      update("users", u.id, { marketplace_banned: true, marketplace_banned_reason: reason, marketplace_banned_at: new Date().toISOString(), marketplace_banned_by: admin.email });
      run("UPDATE marketplace_products SET status = 'hidden', updated_date = ? WHERE seller_id = ? AND status = 'published'", new Date().toISOString(), u.id);
      auditBy(admin, "marketplace_admin_seller_ban", { target_user_id: u.id, reason });
      await notify(u, "Accès vendeur suspendu", "Votre accès vendeur à la Marketplace a été suspendu par l'administration. Motif : " + reason);
    } else {
      update("users", u.id, { marketplace_banned: false, marketplace_banned_reason: null, marketplace_banned_at: null, marketplace_banned_by: null });
      auditBy(admin, "marketplace_admin_seller_unban", { target_user_id: u.id });
      await notify(u, "Accès vendeur rétabli", "Votre accès vendeur à la Marketplace a été rétabli. Vos annonces masquées peuvent être réaffichées depuis « Ma boutique ».");
    }
    sendJson(res, 200, { ok: true });
  });
}
