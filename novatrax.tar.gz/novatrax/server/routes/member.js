// Espace membre : tableau de bord, réseau d'invitation, boîte de réception,
// formations, applications Pro et téléversement d'images.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { all, get, run, insert, update } from "../db.js";
import { bad, notFound, readJson, sendJson, pipeToFile, unauthorized } from "../lib/http.js";
import { requireUser, requireAdmin, rateLimit, sign, verify, auditBy } from "../auth.js";
import { config } from "../config.js";

const str = (v, max = 5000) => (v === undefined || v === null ? null : String(v).trim().slice(0, max) || null);
const url = (v) => {
  const s = str(v, 2000);
  if (!s) return null;
  if (!/^(https?:\/\/|\/uploads\/)/i.test(s)) throw bad("Lien invalide : utilisez une adresse commençant par http(s)://");
  return s;
};

// ---------- Formations ----------
function formationFields(b) {
  const title = str(b.title, 150);
  if (!title) throw bad("Le titre est obligatoire.");
  return {
    title,
    description: str(b.description, 2000),
    profile_image: url(b.profile_image),
    cover_image: url(b.cover_image),
    content: str(b.content, 50000),
    video_url: url(b.video_url),
    document_url: url(b.document_url),
    published: b.published === true,
  };
}

// ---------- Applications ----------
function appFields(b) {
  const name = str(b.name, 120);
  if (!name) throw bad("Le nom de l'application est obligatoire.");
  const download_type = b.download_type === "apk_file" ? "apk_file" : "external_link";
  return {
    name,
    description: str(b.description, 2000),
    logo_image: url(b.logo_image),
    presentation_image: url(b.presentation_image),
    version: str(b.version, 30),
    features: str(b.features, 4000),
    price: str(b.price, 60),
    download_type,
    download_url: url(b.download_url),
    purchase_url: url(b.purchase_url),
  };
}

// Vue membre : jamais le chemin interne du fichier APK.
function appForMember(a) {
  const base = { id: a.id, name: a.name, description: a.description, logo_image: a.logo_image, price: a.price, created_date: a.created_date };
  if (!a.published) return { ...base, published: false };
  return {
    ...base,
    presentation_image: a.presentation_image,
    features: a.features,
    version: a.version,
    purchase_url: a.purchase_url,
    published: true,
    download_type: a.download_type,
    download_url: a.download_type === "external_link" ? a.download_url : null,
    has_apk_file: a.download_type === "apk_file" && !!a.apk_file_path,
    apk_file_name: a.download_type === "apk_file" ? a.apk_file_name : null,
    apk_file_size: a.download_type === "apk_file" ? a.apk_file_size : null,
  };
}
const appForAdmin = (a) => {
  const { apk_file_path, ...rest } = a;
  return { ...rest, has_apk_file: !!apk_file_path };
};

const IMAGE_TYPES = { "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif" };
function looksLikeImage(buf, type) {
  if (type === "image/png") return buf[0] === 0x89 && buf[1] === 0x50;
  if (type === "image/jpeg") return buf[0] === 0xff && buf[1] === 0xd8;
  if (type === "image/gif") return buf.slice(0, 3).toString() === "GIF";
  if (type === "image/webp") return buf.slice(0, 4).toString() === "RIFF" && buf.slice(8, 12).toString() === "WEBP";
  return false;
}

export default function memberRoutes(r) {
  // ---------- Tableau de bord ----------
  r.get("/api/member/home", async (req, res) => {
    const u = requireUser(req);
    const referrals = get("SELECT COUNT(*) AS n FROM users WHERE referred_by = ? AND email_verified = 1", u.id).n;
    const unread = get("SELECT COUNT(*) AS n FROM inbox_messages WHERE user_id = ? AND read = 0", u.id).n;
    const purchases = get("SELECT COUNT(*) AS n FROM marketplace_orders WHERE buyer_id = ? AND status IN ('awaiting_payment','processing','disputed')", u.id).n;
    const listings = get("SELECT COUNT(*) AS n FROM marketplace_products WHERE seller_id = ? AND status = 'published'", u.id).n;
    const recent = all(
      "SELECT id, first_name, username, country, created_date FROM users WHERE referred_by = ? AND email_verified = 1 ORDER BY created_date DESC LIMIT 5",
      u.id
    );
    const showcase = [
      ...all("SELECT id, name, logo_image FROM applications WHERE published = 1 ORDER BY created_date DESC LIMIT 4")
        .map((a) => ({ id: a.id, kind: "app", name: a.name, image: a.logo_image })),
      ...all("SELECT id, title, profile_image, cover_image FROM formations WHERE published = 1 ORDER BY created_date DESC LIMIT 2")
        .map((f) => ({ id: f.id, kind: "formation", name: f.title, image: f.profile_image || f.cover_image })),
    ];
    sendJson(res, 200, {
      referral_code: u.referral_code,
      stats: { referrals, unread, purchases, listings },
      network: { direct: referrals, recent },
      showcase,
    });
  });

  r.get("/api/member/network", async (req, res) => {
    const u = requireUser(req);
    const members = all(
      "SELECT id, first_name, username, country, created_date FROM users WHERE referred_by = ? AND email_verified = 1 ORDER BY created_date DESC LIMIT 200",
      u.id
    );
    const total = get("SELECT COUNT(*) AS n FROM users WHERE referred_by = ? AND email_verified = 1", u.id).n;
    const sponsor = u.referred_by ? get("SELECT first_name, username FROM users WHERE id = ?", u.referred_by) : null;
    sendJson(res, 200, { referral_code: u.referral_code, total, members, sponsor });
  });

  // ---------- Boîte de réception ----------
  r.get("/api/inbox", async (req, res, { query }) => {
    const u = requireUser(req);
    const limit = Math.min(50, Number(query.get("limit")) || 20);
    const offset = Math.max(0, Number(query.get("offset")) || 0);
    const items = all("SELECT * FROM inbox_messages WHERE user_id = ? ORDER BY created_date DESC LIMIT ? OFFSET ?", u.id, limit + 1, offset);
    sendJson(res, 200, { items: items.slice(0, limit), has_more: items.length > limit });
  });
  r.get("/api/inbox/unread", async (req, res) => {
    const u = requireUser(req);
    sendJson(res, 200, { count: get("SELECT COUNT(*) AS n FROM inbox_messages WHERE user_id = ? AND read = 0", u.id).n });
  });
  r.post("/api/inbox/:id/read", async (req, res, { params }) => {
    const u = requireUser(req);
    run("UPDATE inbox_messages SET read = 1, read_at = ? WHERE id = ? AND user_id = ?", new Date().toISOString(), params.id, u.id);
    sendJson(res, 200, { ok: true });
  });
  r.post("/api/inbox/read-all", async (req, res) => {
    const u = requireUser(req);
    run("UPDATE inbox_messages SET read = 1, read_at = ? WHERE user_id = ? AND read = 0", new Date().toISOString(), u.id);
    sendJson(res, 200, { ok: true });
  });

  // ---------- Formations ----------
  r.get("/api/formations", async (req, res) => {
    const u = requireUser(req);
    const rows = all("SELECT * FROM formations ORDER BY created_date DESC LIMIT 200");
    const items = u.role === "admin"
      ? rows
      : rows.filter((f) => f.published);
    sendJson(res, 200, { items });
  });
  r.post("/api/formations", async (req, res) => {
    const admin = requireAdmin(req);
    const f = insert("formations", formationFields(await readJson(req)));
    auditBy(admin, "formation_create", { target_id: f.id, details: f.title });
    sendJson(res, 201, f);
  });
  r.patch("/api/formations/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    if (!get("SELECT id FROM formations WHERE id = ?", params.id)) throw notFound("Formation introuvable.");
    const f = update("formations", params.id, formationFields(await readJson(req)));
    auditBy(admin, "formation_update", { target_id: f.id, details: f.title });
    sendJson(res, 200, f);
  });
  r.delete("/api/formations/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const f = get("SELECT * FROM formations WHERE id = ?", params.id);
    if (!f) throw notFound("Formation introuvable.");
    run("DELETE FROM formations WHERE id = ?", f.id);
    auditBy(admin, "formation_delete", { target_id: f.id, details: f.title });
    sendJson(res, 200, { ok: true });
  });

  // ---------- Applications Pro ----------
  r.get("/api/applications", async (req, res) => {
    const u = requireUser(req);
    const rows = all("SELECT * FROM applications ORDER BY created_date DESC LIMIT 200");
    const items = u.role === "admin" ? rows.map(appForAdmin) : rows.filter((a) => a.published).map(appForMember);
    sendJson(res, 200, { items });
  });
  r.post("/api/applications", async (req, res) => {
    const admin = requireAdmin(req);
    const a = insert("applications", { ...appFields(await readJson(req)), published: false });
    auditBy(admin, "application_create", { target_id: a.id, details: a.name });
    sendJson(res, 201, appForAdmin(a));
  });
  r.patch("/api/applications/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const cur = get("SELECT * FROM applications WHERE id = ?", params.id);
    if (!cur) throw notFound("Application introuvable.");
    const b = await readJson(req);
    // Bascule de publication seule
    if (Object.keys(b).length === 1 && "published" in b) {
      if (b.published === true) {
        if (cur.download_type === "apk_file" && !cur.apk_file_path) throw bad("Ajoutez d'abord un fichier APK à cette application.");
        if (cur.download_type === "external_link" && !cur.download_url) throw bad("Renseignez d'abord le lien de téléchargement.");
      }
      const a = update("applications", cur.id, { published: b.published === true });
      auditBy(admin, b.published ? "application_publish" : "application_unpublish", { target_id: a.id, details: a.name });
      return sendJson(res, 200, appForAdmin(a));
    }
    const fields = appFields(b);
    if (fields.download_type === "external_link" && !fields.download_url && cur.published) fields.published = false;
    if (fields.download_type === "apk_file" && !cur.apk_file_path && cur.published) fields.published = false;
    const a = update("applications", cur.id, fields);
    auditBy(admin, "application_update", { target_id: a.id, details: a.name });
    sendJson(res, 200, appForAdmin(a));
  });
  r.delete("/api/applications/:id", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const a = get("SELECT * FROM applications WHERE id = ?", params.id);
    if (!a) throw notFound("Application introuvable.");
    if (a.apk_file_path) fs.rm(path.join(config.privateUploads, a.apk_file_path), { force: true }, () => {});
    run("DELETE FROM applications WHERE id = ?", a.id);
    auditBy(admin, "application_delete", { target_id: a.id, details: a.name });
    sendJson(res, 200, { ok: true });
  });

  // Fichier APK : téléversement (admin), stocké hors du dossier public.
  r.post("/api/applications/:id/apk", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const a = get("SELECT * FROM applications WHERE id = ?", params.id);
    if (!a) throw notFound("Application introuvable.");
    const original = decodeURIComponent(String(req.headers["x-filename"] || "application.apk")).replace(/[^\w.\- ]/g, "_").slice(0, 120);
    if (!/\.(apk|xapk|apks)$/i.test(original)) throw bad("Le fichier doit être un APK (.apk, .xapk ou .apks).");
    const stored = a.id + "-" + crypto.randomBytes(6).toString("hex") + path.extname(original).toLowerCase();
    const dest = path.join(config.privateUploads, stored);
    const size = await pipeToFile(req, dest, config.maxApkBytes);
    if (size < 1024) { fs.rmSync(dest, { force: true }); throw bad("Fichier vide ou invalide."); }
    if (a.apk_file_path) fs.rm(path.join(config.privateUploads, a.apk_file_path), { force: true }, () => {});
    const upd = update("applications", a.id, {
      apk_file_path: stored, apk_file_name: original, apk_file_size: size,
      apk_file_date: new Date().toISOString(), download_type: "apk_file",
    });
    auditBy(admin, "application_apk_upload", { target_id: a.id, details: `${original} (${size} octets)` });
    sendJson(res, 200, appForAdmin(upd));
  });
  r.delete("/api/applications/:id/apk", async (req, res, { params }) => {
    const admin = requireAdmin(req);
    const a = get("SELECT * FROM applications WHERE id = ?", params.id);
    if (!a) throw notFound("Application introuvable.");
    if (a.apk_file_path) fs.rm(path.join(config.privateUploads, a.apk_file_path), { force: true }, () => {});
    const upd = update("applications", a.id, {
      apk_file_path: null, apk_file_name: null, apk_file_size: null, apk_file_date: null, published: false,
    });
    auditBy(admin, "application_apk_delete", { target_id: a.id, details: a.name });
    sendJson(res, 200, appForAdmin(upd));
  });

  // Lien de téléchargement signé, valable 5 minutes.
  r.post("/api/applications/:id/download", async (req, res, { params }) => {
    const u = requireUser(req);
    rateLimit("apk:" + u.id, 30, 60 * 60_000);
    const a = get("SELECT * FROM applications WHERE id = ?", params.id);
    if (!a || (!a.published && u.role !== "admin")) throw notFound("Application indisponible.");
    if (!a.apk_file_path) throw bad("Aucun fichier APK disponible pour cette application.");
    const t = sign({ t: "apk", app: a.id, sub: u.id }, 300);
    sendJson(res, 200, { url: `/api/files/apk/${a.id}?t=${encodeURIComponent(t)}` });
  });
  r.get("/api/files/apk/:id", async (req, res, { params, query }) => {
    const p = verify(query.get("t"));
    if (!p || p.t !== "apk" || p.app !== params.id) throw unauthorized("Lien de téléchargement expiré.");
    const a = get("SELECT * FROM applications WHERE id = ?", params.id);
    if (!a?.apk_file_path) throw notFound("Fichier introuvable.");
    const file = path.join(config.privateUploads, a.apk_file_path);
    if (!fs.existsSync(file)) throw notFound("Fichier introuvable.");
    const stat = fs.statSync(file);
    res.writeHead(200, {
      "Content-Type": "application/vnd.android.package-archive",
      "Content-Length": stat.size,
      "Content-Disposition": `attachment; filename="${(a.apk_file_name || a.name + ".apk").replace(/"/g, "")}"`,
      "Cache-Control": "no-store",
    });
    fs.createReadStream(file).pipe(res);
  });

  // ---------- Images ----------
  r.post("/api/uploads/image", async (req, res) => {
    const u = requireUser(req);
    rateLimit("img:" + u.id, 60, 60 * 60_000);
    const type = String(req.headers["content-type"] || "").split(";")[0].trim().toLowerCase();
    const ext = IMAGE_TYPES[type];
    if (!ext) throw bad("Format d'image non pris en charge (PNG, JPEG, WEBP ou GIF).");
    const name = crypto.randomBytes(12).toString("hex") + ext;
    const dest = path.join(config.publicUploads, name);
    await pipeToFile(req, dest, config.maxImageBytes);
    const head = Buffer.alloc(12);
    const fd = fs.openSync(dest, "r");
    fs.readSync(fd, head, 0, 12, 0);
    fs.closeSync(fd);
    if (!looksLikeImage(head, type)) {
      fs.rmSync(dest, { force: true });
      throw bad("Le fichier envoyé n'est pas une image valide.");
    }
    sendJson(res, 200, { url: "/uploads/" + name });
  });
}
