// Répertoire de contacts : uniquement les membres ayant donné leur consentement.
import { all, get } from "../db.js";
import { forbidden, sendJson, sendFile } from "../lib/http.js";
import { requireUser, requireAdmin, auditBy, rateLimit } from "../auth.js";

const TZ = "Africa/Lome";
const DAY = 86400000;

function tzParts(date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: TZ, hour12: false, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  }).formatToParts(date);
  const m = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  return { y: +m.year, m: +m.month, d: +m.day, h: m.hour === "24" ? 0 : +m.hour, min: +m.minute, sec: +m.second };
}
const tzOffset = (date) => {
  const p = tzParts(date);
  return Date.UTC(p.y, p.m - 1, p.d, p.h, p.min, p.sec) - date.getTime();
};
const dayStart = (date) => {
  const p = tzParts(date);
  const g = Date.UTC(p.y, p.m - 1, p.d);
  return g - tzOffset(new Date(g));
};
const isoDay = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s);

// Bornes [from, to) de la période demandée, en fuseau local de la plateforme.
export function rangeBounds(range, from, to) {
  const now = new Date();
  const today = dayStart(now);
  const p = tzParts(now);
  const dow = new Date(Date.UTC(p.y, p.m - 1, p.d)).getUTCDay();
  const iso = (t) => new Date(t).toISOString();
  switch (String(range || "all")) {
    case "today": return [iso(today), iso(today + DAY)];
    case "yesterday": return [iso(today - DAY), iso(today)];
    case "week": return [iso(today - ((dow + 6) % 7) * DAY), null];
    case "month": {
      const g = Date.UTC(p.y, p.m - 1, 1);
      return [iso(g - tzOffset(new Date(g))), null];
    }
    case "custom": {
      const conv = (s) => {
        const [y, m, d] = s.split("-").map(Number);
        const g = Date.UTC(y, m - 1, d);
        return g - tzOffset(new Date(g));
      };
      return [isoDay(from) ? iso(conv(from)) : null, isoDay(to) ? iso(conv(to) + DAY) : null];
    }
    default: return [null, null];
  }
}

export function countByRanges(rows) {
  const counts = { total: 0, today: 0, yesterday: 0, week: 0, month: 0 };
  const b = {
    today: rangeBounds("today"), yesterday: rangeBounds("yesterday"),
    week: rangeBounds("week"), month: rangeBounds("month"),
  };
  for (const r of rows) {
    counts.total++;
    for (const k of Object.keys(b)) {
      const [f, t] = b[k];
      if ((!f || r.created_date >= f) && (!t || r.created_date < t)) counts[k]++;
    }
  }
  return counts;
}

const baseName = (u) => [u.first_name, u.last_name].filter(Boolean).join(" ").trim() || u.username || "Membre";
export const contactName = (u) => baseName(u) + " Novatrax";
const e164 = (p) => {
  const c = String(p || "").replace(/[^\d+]/g, "");
  return !c ? "" : c.startsWith("+") ? c : "+" + c;
};
const vEsc = (v) => String(v ?? "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");

export function buildVcf(rows) {
  return rows
    .map((m) => ["BEGIN:VCARD", "VERSION:3.0", `N:${vEsc(baseName(m))};Novatrax;;;`, `FN:${vEsc(contactName(m))}`, `TEL;TYPE=CELL:${e164(m.phone)}`, "END:VCARD"].join("\r\n"))
    .join("\r\n");
}
export function buildCsv(rows) {
  const esc = (v) => '"' + String(v ?? "").replace(/"/g, '""') + '"';
  const lines = rows.map((m) => [contactName(m), e164(m.phone), m.created_date, m.country].map(esc).join(";"));
  return "\uFEFF" + ["Nom du contact;Telephone;Date d'inscription;Pays", ...lines].join("\r\n");
}

// Membres éligibles : consentement explicite, numéro présent, compte actif et vérifié.
function eligible({ range, from, to, search, excludeId } = {}) {
  const where = ["share_contacts = 1", "phone IS NOT NULL", "phone <> ''", "account_status = 'active'", "email_verified = 1"];
  const params = [];
  const [f, t] = rangeBounds(range, from, to);
  if (f) { where.push("created_date >= ?"); params.push(f); }
  if (t) { where.push("created_date < ?"); params.push(t); }
  if (excludeId) { where.push("id <> ?"); params.push(excludeId); }
  if (search) {
    where.push("(first_name LIKE ? OR last_name LIKE ? OR username LIKE ? OR phone LIKE ?)");
    const s = "%" + search + "%";
    params.push(s, s, s, s);
  }
  return all(
    `SELECT id, first_name, last_name, username, phone, country, created_date FROM users WHERE ${where.join(" AND ")} ORDER BY created_date DESC`,
    ...params
  );
}

const q = (query) => ({
  range: query.get("range") || "all",
  from: query.get("date_from") || "",
  to: query.get("date_to") || "",
  search: String(query.get("search") || "").trim().slice(0, 60),
});

export default function contactRoutes(r) {
  r.get("/api/contacts/summary", async (req, res) => {
    const u = requireUser(req);
    sendJson(res, 200, { consent: u.share_contacts, counts: countByRanges(eligible({ excludeId: u.id })) });
  });

  r.get("/api/contacts/directory", async (req, res, { query }) => {
    const u = requireUser(req);
    if (!u.share_contacts && u.role !== "admin") throw forbidden("Activez le partage de vos coordonnées pour accéder à l'annuaire.");
    const rows = eligible({ ...q(query), excludeId: u.id });
    const limit = 50;
    sendJson(res, 200, {
      count: rows.length,
      truncated: rows.length > limit,
      items: rows.slice(0, limit).map((m) => ({ id: m.id, name: contactName(m), phone: e164(m.phone), country: m.country, created_date: m.created_date })),
    });
  });

  r.get("/api/contacts/download", async (req, res, { query }) => {
    const u = requireUser(req);
    if (!u.share_contacts && u.role !== "admin") throw forbidden("Activez le partage de vos coordonnées pour télécharger l'annuaire.");
    rateLimit("vcf:" + u.id, 20, 60 * 60_000);
    const rows = eligible({ ...q(query), excludeId: u.id });
    sendFile(res, 200, buildVcf(rows), "text/vcard; charset=utf-8", "NOVATRAX_CONTACTS.vcf");
  });

  // ---------- Administration ----------
  r.get("/api/admin/contacts", async (req, res, { query }) => {
    requireAdmin(req);
    const where = ["email_verified = 1"];
    const params = [];
    const { range, from, to, search } = q(query);
    const [f, t] = rangeBounds(range, from, to);
    if (f) { where.push("created_date >= ?"); params.push(f); }
    if (t) { where.push("created_date < ?"); params.push(t); }
    const country = query.get("country");
    if (country) { where.push("country = ?"); params.push(country); }
    const status = query.get("status");
    if (status === "active" || status === "suspended") { where.push("account_status = ?"); params.push(status); }
    const share = query.get("share");
    if (share === "yes") where.push("share_contacts = 1");
    if (share === "no") where.push("share_contacts = 0");
    if (search) {
      where.push("(first_name LIKE ? OR last_name LIKE ? OR username LIKE ? OR phone LIKE ? OR email LIKE ?)");
      const s = "%" + search + "%";
      params.push(s, s, s, s, s);
    }
    const rows = all(
      `SELECT id, email, first_name, last_name, username, phone, country, role, account_status, share_contacts, created_date
       FROM users WHERE ${where.join(" AND ")} ORDER BY created_date DESC LIMIT 300`, ...params
    );
    const allVerified = all("SELECT created_date FROM users WHERE email_verified = 1");
    sendJson(res, 200, {
      items: rows,
      counts: countByRanges(allVerified),
      shareable: get("SELECT COUNT(*) AS n FROM users WHERE email_verified = 1 AND share_contacts = 1 AND account_status = 'active' AND phone IS NOT NULL").n,
    });
  });

  r.get("/api/admin/contacts/export", async (req, res, { query }) => {
    const admin = requireAdmin(req);
    const format = query.get("format") === "csv" ? "csv" : "vcf";
    const rows = eligible(q(query));
    auditBy(admin, "contact_export_" + format, { details: `${rows.length} contacts (période : ${q(query).range})` });
    if (format === "csv") return sendFile(res, 200, buildCsv(rows), "text/csv; charset=utf-8", "NOVATRAX_CONTACTS.csv");
    sendFile(res, 200, buildVcf(rows), "text/vcard; charset=utf-8", "NOVATRAX_CONTACTS.vcf");
  });
}
