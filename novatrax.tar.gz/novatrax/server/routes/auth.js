import crypto from "node:crypto";
import { get, insert, update, run } from "../db.js";
import { bad, forbidden, readJson, sendJson, HttpError } from "../lib/http.js";
import {
  hashPassword, verifyPassword, passwordProblem, issueSession, currentUser, requireUser,
  selfView, sendOtp, checkOtp, rateLimit, clientIp, audit, notify,
} from "../auth.js";
import { config } from "../config.js";
import { getCountry } from "../../shared/countries.js";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME_RE = /^[a-zA-Z0-9_.]{3,20}$/;
const NAME_RE = /^[A-Za-zÀ-ÿ' -]{2,40}$/;

const cleanEmail = (e) => String(e || "").trim().toLowerCase();

function newReferralCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  for (;;) {
    let c = "NX";
    for (let i = 0; i < 6; i++) c += alphabet[crypto.randomInt(alphabet.length)];
    if (!get("SELECT 1 AS x FROM users WHERE referral_code = ?", c)) return c;
  }
}

// Parrain : code de parrainage ou nom d'utilisateur d'un compte vérifié et actif.
export function resolveSponsor(ref) {
  const v = String(ref || "").trim().replace(/^@/, "");
  if (!v) return null;
  return get(
    "SELECT * FROM users WHERE (referral_code = ? COLLATE NOCASE OR username = ?) AND email_verified = 1 AND account_status = 'active'",
    v, v
  );
}

export function buildPhone(country, local) {
  const c = getCountry(country);
  const digits = String(local || "").replace(/[^\d]/g, "");
  if (!c || !/^\d{6,12}$/.test(digits)) return null;
  return c.dialCode + digits;
}

export default function authRoutes(r) {
  r.post("/api/auth/check", async (req, res) => {
    rateLimit("check:" + clientIp(req), 60, 60_000);
    const body = await readJson(req);
    const username = String(body.username || "").trim();
    const sponsor = resolveSponsor(body.ref_code);
    const taken = username ? !!get("SELECT 1 AS x FROM users WHERE username = ? AND email_verified = 1", username) : false;
    sendJson(res, 200, {
      username_available: username ? !taken : null,
      sponsor: sponsor ? { username: sponsor.username, first_name: sponsor.first_name } : null,
    });
  });

  r.post("/api/auth/register", async (req, res) => {
    rateLimit("register:" + clientIp(req), 10, 15 * 60_000);
    const b = await readJson(req);
    const email = cleanEmail(b.email);
    const username = String(b.username || "").trim();
    const first_name = String(b.first_name || "").trim();
    const last_name = String(b.last_name || "").trim();
    if (!EMAIL_RE.test(email)) throw bad("Veuillez saisir une adresse e-mail valide.");
    if (!USERNAME_RE.test(username)) throw bad("Nom d'utilisateur : 3 à 20 caractères (lettres, chiffres, _ ou .).");
    if (!NAME_RE.test(first_name)) throw bad("Veuillez saisir votre prénom.");
    if (last_name && !NAME_RE.test(last_name)) throw bad("Le nom saisi n'est pas valide.");
    const phone = buildPhone(b.country, b.phone);
    if (!getCountry(b.country)) throw bad("Veuillez sélectionner votre pays.");
    if (!phone) throw bad("Le numéro de téléphone n'est pas valide (chiffres uniquement, sans l'indicatif).");
    const pwErr = passwordProblem(b.password);
    if (pwErr) throw bad(pwErr);
    if (b.accept_terms !== true) throw bad("Vous devez accepter les conditions générales et la politique de confidentialité.");

    let sponsorId = null;
    if (String(b.ref_code || "").trim()) {
      const s = resolveSponsor(b.ref_code);
      if (!s) throw bad("Le code de parrainage saisi est invalide. Corrigez-le ou laissez le champ vide.");
      sponsorId = s.id;
    }

    const existing = get("SELECT * FROM users WHERE email = ?", email);
    if (existing && existing.email_verified) throw new HttpError(409, "Cette adresse e-mail est déjà utilisée.");
    const nameOwner = get("SELECT id, email_verified FROM users WHERE username = ?", username);
    if (nameOwner && nameOwner.id !== existing?.id) {
      if (nameOwner.email_verified) throw new HttpError(409, "Ce nom d'utilisateur est déjà pris. Choisissez-en un autre.");
      run("DELETE FROM users WHERE id = ? AND email_verified = 0", nameOwner.id); // inscription abandonnée
    }

    const fields = {
      email, username, first_name, last_name, country: b.country, phone,
      password_hash: hashPassword(b.password),
      share_contacts: b.share_contacts === true,
      referred_by: sponsorId,
    };
    if (existing) update("users", existing.id, fields);
    else insert("users", { ...fields, role: "user", email_verified: false, account_status: "active", referral_code: newReferralCode() });

    const dev_code = await sendOtp(email, "verify");
    sendJson(res, 200, { ok: true, email, dev_code });
  });

  r.post("/api/auth/verify", async (req, res) => {
    rateLimit("verify:" + clientIp(req), 20, 15 * 60_000);
    const b = await readJson(req);
    const email = cleanEmail(b.email);
    const u = get("SELECT * FROM users WHERE email = ?", email);
    if (!u) throw bad("Code invalide ou expiré.");
    checkOtp(email, "verify", b.code);
    const firstVerify = !u.email_verified;
    const patch = { email_verified: true, last_login_at: new Date().toISOString() };
    if (config.adminEmails.includes(email)) patch.role = "admin";
    const user = update("users", u.id, patch);
    if (firstVerify) {
      await notify(user, "Bienvenue sur NOVATRAX !",
        "Votre compte est activé. Découvrez les formations, les applications Pro et la Marketplace depuis votre tableau de bord.",
        { email: false });
      if (user.referred_by) {
        const sponsor = get("SELECT * FROM users WHERE id = ?", user.referred_by);
        if (sponsor) await notify(sponsor, "Nouveau filleul",
          `${user.first_name || user.username} vient de rejoindre NOVATRAX grâce à votre lien d'invitation.`, { email: false });
      }
      if (patch.role === "admin") audit({ action: "admin_init", admin_email: email, admin_id: user.id, details: "Administrateur défini par ADMIN_EMAILS" });
    }
    sendJson(res, 200, { token: issueSession(user), user: selfView(user) });
  });

  r.post("/api/auth/resend", async (req, res) => {
    rateLimit("resend:" + clientIp(req), 8, 15 * 60_000);
    const b = await readJson(req);
    const email = cleanEmail(b.email);
    const purpose = b.purpose === "reset" ? "reset" : "verify";
    const u = get("SELECT * FROM users WHERE email = ?", email);
    let dev_code;
    if (u && (purpose === "reset" || !u.email_verified)) dev_code = await sendOtp(email, purpose);
    sendJson(res, 200, { ok: true, dev_code });
  });

  r.post("/api/auth/login", async (req, res) => {
    rateLimit("login:" + clientIp(req), 20, 15 * 60_000);
    const b = await readJson(req);
    const ident = String(b.identifier || "").trim();
    if (!ident || !b.password) throw bad("Veuillez saisir vos identifiants.");
    const u = ident.includes("@")
      ? get("SELECT * FROM users WHERE email = ?", ident.toLowerCase())
      : get("SELECT * FROM users WHERE username = ?", ident.replace(/^@/, ""));
    if (!u || !verifyPassword(String(b.password), u.password_hash)) {
      throw new HttpError(401, "Identifiants incorrects. Vérifiez votre nom d'utilisateur / adresse e-mail et votre mot de passe.");
    }
    if (!u.email_verified) {
      throw new HttpError(403, "Votre adresse e-mail n'est pas encore vérifiée. Terminez la vérification avec le code reçu par e-mail.", {
        needs_verification: true, email: u.email,
      });
    }
    if (u.account_status === "suspended") {
      throw forbidden("Votre compte a été bloqué par l'administration NOVATRAX. Contactez le support pour plus d'informations.");
    }
    const user = update("users", u.id, { last_login_at: new Date().toISOString() });
    sendJson(res, 200, { token: issueSession(user), user: selfView(user) });
  });

  r.post("/api/auth/forgot", async (req, res) => {
    rateLimit("forgot:" + clientIp(req), 6, 15 * 60_000);
    const b = await readJson(req);
    const email = cleanEmail(b.email);
    const u = get("SELECT * FROM users WHERE email = ? AND email_verified = 1", email);
    let dev_code;
    if (u) {
      try { dev_code = await sendOtp(email, "reset"); } catch (e) { if (e.status !== 429) throw e; }
    }
    // Réponse identique que le compte existe ou non (pas de divulgation).
    sendJson(res, 200, { ok: true, dev_code });
  });

  r.post("/api/auth/reset", async (req, res) => {
    rateLimit("reset:" + clientIp(req), 15, 15 * 60_000);
    const b = await readJson(req);
    const email = cleanEmail(b.email);
    const pwErr = passwordProblem(b.password);
    if (pwErr) throw bad(pwErr);
    const u = get("SELECT * FROM users WHERE email = ?", email);
    if (!u) throw bad("Code invalide ou expiré.");
    checkOtp(email, "reset", b.code);
    update("users", u.id, { password_hash: hashPassword(b.password), token_version: (u.token_version || 0) + 1 });
    sendJson(res, 200, { ok: true });
  });

  r.get("/api/auth/me", async (req, res) => {
    const u = currentUser(req);
    if (!u) throw new HttpError(401, "Non authentifié.");
    // Un compte bloqué reçoit son profil (pour afficher l'écran « Compte bloqué »).
    sendJson(res, 200, { user: selfView(u) });
  });

  r.patch("/api/auth/me", async (req, res) => {
    const u = requireUser(req);
    const b = await readJson(req);
    const patch = {};
    if (b.first_name !== undefined) {
      const v = String(b.first_name).trim();
      if (!NAME_RE.test(v)) throw bad("Veuillez saisir un prénom valide.");
      patch.first_name = v;
    }
    if (b.last_name !== undefined) {
      const v = String(b.last_name).trim();
      if (v && !NAME_RE.test(v)) throw bad("Le nom saisi n'est pas valide.");
      patch.last_name = v;
    }
    if (b.country !== undefined || b.phone !== undefined) {
      const country = b.country ?? u.country;
      if (!getCountry(country)) throw bad("Veuillez sélectionner votre pays.");
      let local = String(b.phone ?? "").trim();
      const c = getCountry(country);
      if (local.startsWith("+")) local = local.startsWith(c.dialCode) ? local.slice(c.dialCode.length) : "";
      const phone = buildPhone(country, local);
      if (!phone) throw bad("Le numéro de téléphone n'est pas valide (chiffres uniquement, sans l'indicatif).");
      patch.country = country;
      patch.phone = phone;
    }
    if (b.share_contacts !== undefined) patch.share_contacts = b.share_contacts === true;
    if (b.unsubscribed !== undefined) patch.unsubscribed = b.unsubscribed === true;
    const user = Object.keys(patch).length ? update("users", u.id, patch) : u;
    sendJson(res, 200, { user: selfView(user) });
  });

  r.post("/api/auth/change-password", async (req, res) => {
    const u = requireUser(req);
    rateLimit("chpw:" + u.id, 10, 15 * 60_000);
    const b = await readJson(req);
    if (!verifyPassword(String(b.current_password || ""), u.password_hash)) throw bad("Mot de passe actuel incorrect.");
    const pwErr = passwordProblem(b.password);
    if (pwErr) throw bad(pwErr);
    const user = update("users", u.id, { password_hash: hashPassword(b.password), token_version: (u.token_version || 0) + 1 });
    sendJson(res, 200, { ok: true, token: issueSession(user) });
  });

  r.post("/api/auth/logout-all", async (req, res) => {
    const u = requireUser(req);
    update("users", u.id, { token_version: (u.token_version || 0) + 1 });
    sendJson(res, 200, { ok: true });
  });
}
