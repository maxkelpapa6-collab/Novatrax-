// Base de données SQLite intégrée à Node (node:sqlite) — aucun service externe requis.
import { DatabaseSync } from "node:sqlite";
import crypto from "node:crypto";
import { config } from "./config.js";

export const db = new DatabaseSync(config.dbFile);
db.exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  username TEXT UNIQUE COLLATE NOCASE,
  first_name TEXT, last_name TEXT, country TEXT, phone TEXT,
  email_verified INTEGER NOT NULL DEFAULT 0,
  unsubscribed INTEGER NOT NULL DEFAULT 0,
  account_status TEXT NOT NULL DEFAULT 'active',
  referral_code TEXT UNIQUE,
  referred_by TEXT,
  blocked_reason TEXT, blocked_at TEXT, blocked_by TEXT,
  share_contacts INTEGER NOT NULL DEFAULT 0,
  marketplace_banned INTEGER NOT NULL DEFAULT 0,
  marketplace_banned_reason TEXT, marketplace_banned_at TEXT, marketplace_banned_by TEXT,
  token_version INTEGER NOT NULL DEFAULT 0,
  last_login_at TEXT,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_ref ON users(referred_by);

CREATE TABLE IF NOT EXISTS otps (
  email TEXT NOT NULL COLLATE NOCASE,
  purpose TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (email, purpose)
);

CREATE TABLE IF NOT EXISTS formations (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL, description TEXT,
  profile_image TEXT, cover_image TEXT,
  content TEXT, video_url TEXT, document_url TEXT,
  published INTEGER NOT NULL DEFAULT 0,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS applications (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL, description TEXT,
  logo_image TEXT, presentation_image TEXT,
  version TEXT, features TEXT, price TEXT,
  download_type TEXT NOT NULL DEFAULT 'external_link',
  download_url TEXT, purchase_url TEXT,
  apk_file_path TEXT, apk_file_name TEXT, apk_file_size INTEGER, apk_file_date TEXT,
  published INTEGER NOT NULL DEFAULT 0,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS inbox_messages (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, body_text TEXT,
  type TEXT NOT NULL DEFAULT 'system',
  campaign_id TEXT,
  read INTEGER NOT NULL DEFAULT 0, read_at TEXT,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_inbox_user ON inbox_messages(user_id, read);

CREATE TABLE IF NOT EXISTS email_campaigns (
  id TEXT PRIMARY KEY,
  subject TEXT NOT NULL, body_text TEXT,
  audience_type TEXT NOT NULL, audience_details TEXT,
  channels TEXT,
  recipients_count INTEGER DEFAULT 0, sent_count INTEGER DEFAULT 0, failed_count INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'sending',
  sent_by TEXT, sent_by_email TEXT,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS email_delivery_logs (
  id TEXT PRIMARY KEY,
  campaign_id TEXT, recipient_email TEXT, recipient_user_id TEXT,
  status TEXT NOT NULL, error TEXT,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  action TEXT NOT NULL, admin_email TEXT NOT NULL, admin_id TEXT,
  target_user_id TEXT, target_id TEXT,
  result TEXT NOT NULL DEFAULT 'success',
  reason TEXT, details TEXT,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_logs(created_date);

CREATE TABLE IF NOT EXISTS marketplace_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS marketplace_rules (
  id TEXT PRIMARY KEY,
  value TEXT NOT NULL, note TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS marketplace_products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL, description TEXT, image_url TEXT,
  price_fcfa INTEGER NOT NULL, category TEXT,
  seller_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  seller_email TEXT, seller_name TEXT, seller_phone TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  blocked_reason TEXT, rejection_reason TEXT,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_status ON marketplace_products(status, created_date);

CREATE TABLE IF NOT EXISTS marketplace_orders (
  id TEXT PRIMARY KEY,
  order_ref TEXT NOT NULL UNIQUE,
  product_id TEXT, product_name TEXT, product_image TEXT,
  product_price_fcfa INTEGER NOT NULL, commission_fcfa INTEGER NOT NULL, net_fcfa INTEGER NOT NULL,
  buyer_id TEXT NOT NULL, buyer_email TEXT, buyer_name TEXT, buyer_phone TEXT,
  seller_id TEXT NOT NULL, seller_email TEXT, seller_name TEXT, seller_phone TEXT,
  buyer_note TEXT,
  status TEXT NOT NULL DEFAULT 'awaiting_payment',
  paid_at TEXT, completed_at TEXT, cancelled_at TEXT, refunded_at TEXT,
  dispute_reason TEXT, resolution_note TEXT, reviewed_by TEXT, reviewed_at TEXT,
  created_date TEXT NOT NULL, updated_date TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON marketplace_orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_seller ON marketplace_orders(seller_id);
`);

const BOOL_COLS = new Set([
  "email_verified", "unsubscribed", "share_contacts", "marketplace_banned",
  "published", "read", "active",
]);

export const now = () => new Date().toISOString();
export const newId = () => crypto.randomUUID().replace(/-/g, "").slice(0, 24);

export function out(row) {
  if (!row) return null;
  const o = { ...row };
  for (const k of Object.keys(o)) if (BOOL_COLS.has(k)) o[k] = o[k] === 1;
  return o;
}

const norm = (v) => (typeof v === "boolean" ? (v ? 1 : 0) : v === undefined ? null : v);

export function all(sql, ...params) {
  return db.prepare(sql).all(...params.map(norm)).map(out);
}
export function get(sql, ...params) {
  return out(db.prepare(sql).get(...params.map(norm)));
}
export function run(sql, ...params) {
  return db.prepare(sql).run(...params.map(norm));
}

export function insert(table, data) {
  const t = now();
  const row = { id: newId(), created_date: t, updated_date: t, ...data };
  const keys = Object.keys(row);
  db.prepare(`INSERT INTO ${table} (${keys.join(",")}) VALUES (${keys.map(() => "?").join(",")})`)
    .run(...keys.map((k) => norm(row[k])));
  return get(`SELECT * FROM ${table} WHERE id = ?`, row.id);
}

export function update(table, id, data) {
  const row = { ...data, updated_date: now() };
  const keys = Object.keys(row);
  db.prepare(`UPDATE ${table} SET ${keys.map((k) => k + " = ?").join(", ")} WHERE id = ?`)
    .run(...keys.map((k) => norm(row[k])), id);
  return get(`SELECT * FROM ${table} WHERE id = ?`, id);
}

export function tx(fn) {
  db.exec("BEGIN IMMEDIATE");
  try {
    const r = fn();
    db.exec("COMMIT");
    return r;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
