// Valeurs par défaut au premier démarrage : catégories et règles de la Marketplace.
// Aucune donnée de membre, de formation ou d'application n'est créée.
import { get, insert } from "./db.js";

const CATEGORIES = ["Électronique", "Mode & beauté", "Maison", "Alimentation", "Services", "Formations & e-books", "Autres"];
const RULES = [
  ["arme", "Armes et munitions"],
  ["drogue", "Stupéfiants"],
  ["contrefaçon", "Produits contrefaits"],
  ["faux billets", "Fausse monnaie"],
  ["piratage", "Logiciels piratés / comptes volés"],
];

export function seedDefaults() {
  if (!get("SELECT id FROM marketplace_categories LIMIT 1")) {
    CATEGORIES.forEach((name, i) => insert("marketplace_categories", { name, active: true, sort_order: i + 1 }));
  }
  if (!get("SELECT id FROM marketplace_rules LIMIT 1")) {
    for (const [value, note] of RULES) insert("marketplace_rules", { value, note, active: true });
  }
}
