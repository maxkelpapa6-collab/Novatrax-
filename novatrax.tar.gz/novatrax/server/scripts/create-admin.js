// Crée (ou promeut) un compte administrateur depuis la ligne de commande.
// Usage : npm run create-admin -- email@exemple.com MotDePasse123 [nom_utilisateur]
import crypto from "node:crypto";
import { get, insert, update } from "../db.js";
import { hashPassword, passwordProblem } from "../auth.js";

const [email, password, usernameArg] = process.argv.slice(2);
if (!email || !password) {
  console.error("Usage : npm run create-admin -- email@exemple.com MotDePasse123 [nom_utilisateur]");
  process.exit(1);
}
const pwErr = passwordProblem(password);
if (pwErr) {
  console.error(pwErr);
  process.exit(1);
}
const mail = email.trim().toLowerCase();
const existing = get("SELECT * FROM users WHERE email = ?", mail);
if (existing) {
  update("users", existing.id, { role: "admin", email_verified: true, account_status: "active", password_hash: hashPassword(password) });
  console.log(`Compte ${mail} promu administrateur (mot de passe mis à jour).`);
} else {
  const username = (usernameArg || mail.split("@")[0]).replace(/[^a-zA-Z0-9_.]/g, "").slice(0, 20) || "admin";
  insert("users", {
    email: mail, username, first_name: "Admin", password_hash: hashPassword(password), role: "admin",
    email_verified: true, account_status: "active",
    referral_code: "NX" + crypto.randomBytes(3).toString("hex").toUpperCase(),
  });
  console.log(`Administrateur ${mail} créé (nom d'utilisateur : ${username}).`);
}
