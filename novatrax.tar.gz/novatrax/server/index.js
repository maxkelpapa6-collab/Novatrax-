// Serveur NOVATRAX : API JSON + fichiers téléversés + application web compilée.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";
import "./db.js";
import { Router, HttpError, sendJson, serveStatic } from "./lib/http.js";
import authRoutes from "./routes/auth.js";
import memberRoutes from "./routes/member.js";
import contactRoutes from "./routes/contacts.js";
import marketplaceRoutes from "./routes/marketplace.js";
import adminRoutes from "./routes/admin.js";
import { seedDefaults } from "./seed.js";

const router = new Router();
authRoutes(router);
memberRoutes(router);
contactRoutes(router);
marketplaceRoutes(router);
adminRoutes(router);
seedDefaults();

router.get("/api/health", async (req, res) => sendJson(res, 200, { ok: true, app: config.appName }));
router.get("/api/public/settings", async (req, res) =>
  sendJson(res, 200, { app_name: config.appName, support_email: config.supportEmail, whatsapp_channel: process.env.WHATSAPP_CHANNEL_URL || "" })
);

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "X-Frame-Options": "DENY",
};

async function handle(req, res) {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
  const u = new URL(req.url, "http://localhost");
  const pathname = u.pathname;

  if (pathname.startsWith("/api/")) {
    const m = router.match(req.method, pathname);
    if (!m) return sendJson(res, 404, { error: "Route introuvable." });
    try {
      for (const h of m.handlers) await h(req, res, { params: m.params, query: u.searchParams });
    } catch (e) {
      if (e instanceof HttpError) return !res.headersSent && sendJson(res, e.status, { error: e.message, ...(e.extra || {}) });
      console.error("[api]", req.method, pathname, e);
      if (!res.headersSent) sendJson(res, 500, { error: "Erreur interne du serveur." });
    }
    return;
  }

  if (pathname.startsWith("/uploads/")) {
    if (serveStatic(req, res, config.publicUploads, pathname.slice("/uploads".length))) return;
    res.writeHead(404).end();
    return;
  }

  // Application web (SPA) : fichiers compilés, sinon index.html.
  if (req.method === "GET" || req.method === "HEAD") {
    if (pathname !== "/" && serveStatic(req, res, config.distDir, pathname, { cache: pathname.startsWith("/assets/") })) return;
    const index = path.join(config.distDir, "index.html");
    if (fs.existsSync(index)) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache" });
      return res.end(fs.readFileSync(index));
    }
    res.writeHead(503, { "Content-Type": "text/plain; charset=utf-8" });
    return res.end("Interface non compilée : lancez « npm run build ».");
  }
  res.writeHead(405).end();
}

http.createServer(handle).listen(config.port, () => {
  console.log(`${config.appName} en ligne sur ${config.appUrl} (port ${config.port})`);
  if (config.mail.provider === "console") console.log("E-mails : mode console (codes affichés ici). Configurez MAIL_PROVIDER pour un envoi réel.");
});
