// Test de bout en bout de l'API : démarre un serveur sur une base temporaire.
// Usage : npm test
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import assert from "node:assert/strict";

const PORT = 3900 + Math.floor(Math.random() * 90);
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), "novatrax-test-"));
const BASE = `http://127.0.0.1:${PORT}`;
const srv = spawn(process.execPath, ["--no-warnings=ExperimentalWarning", "server/index.js"], {
  env: { ...process.env, PORT: String(PORT), DATA_DIR: DATA, ADMIN_EMAILS: "admin@test.local", MAIL_PROVIDER: "console", NODE_ENV: "test" },
  stdio: ["ignore", "pipe", "pipe"],
});
let log = "";
srv.stdout.on("data", (d) => (log += d));
srv.stderr.on("data", (d) => (log += d));

async function call(method, url, body, token, headers = {}) {
  const h = { ...headers };
  if (token) h.Authorization = "Bearer " + token;
  let payload;
  if (body instanceof Buffer) payload = body;
  else if (body !== undefined) { h["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  const r = await fetch(BASE + url, { method, headers: h, body: payload });
  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("json") ? await r.json() : await r.text();
  return { status: r.status, data, headers: r.headers };
}

let passed = 0;
async function step(name, fn) {
  try {
    await fn();
    passed++;
    console.log("  ✓ " + name);
  } catch (e) {
    console.error("  ✗ " + name + "\n    " + e.message);
    console.error(log.slice(-2000));
    srv.kill();
    process.exit(1);
  }
}

async function signup(email, username, extra = {}) {
  const r = await call("POST", "/api/auth/register", {
    email, username, first_name: "Test", last_name: "Membre", country: "TG", phone: "90" + Math.floor(100000 + Math.random() * 899999),
    password: "motdepasse1", accept_terms: true, ...extra,
  });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.match(r.data.dev_code, /^\d{6}$/);
  const v = await call("POST", "/api/auth/verify", { email, code: r.data.dev_code });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  return v.data;
}

for (let i = 0; i < 50; i++) {
  try { if ((await fetch(BASE + "/api/health")).ok) break; } catch { /* attente */ }
  await new Promise((r) => setTimeout(r, 100));
}

console.log("Tests API NOVATRAX");
let admin, alice, bob, appId, productId, orderId;

await step("inscription + vérification de l'administrateur (ADMIN_EMAILS)", async () => {
  admin = await signup("admin@test.local", "admin_nx");
  assert.equal(admin.user.role, "admin");
});

await step("inscription avec code de parrainage", async () => {
  alice = await signup("alice@test.local", "alice", { share_contacts: true });
  const chk = await call("POST", "/api/auth/check", { ref_code: alice.user.referral_code });
  assert.equal(chk.data.sponsor.username, "alice");
  bob = await signup("bob@test.local", "bob", { ref_code: alice.user.referral_code, share_contacts: true });
  assert.equal(bob.user.referred_by, alice.user.id);
  const net = await call("GET", "/api/member/network", undefined, alice.token);
  assert.equal(net.data.total, 1);
});

await step("refus : e-mail déjà utilisé, code de parrainage invalide, mot de passe faible", async () => {
  const dup = await call("POST", "/api/auth/register", { email: "alice@test.local", username: "alice2", first_name: "A", country: "TG", phone: "90000000", password: "motdepasse1", accept_terms: true });
  assert.equal(dup.status, 400); // prénom trop court d'abord
  const dup2 = await call("POST", "/api/auth/register", { email: "alice@test.local", username: "alice2", first_name: "Alice", country: "TG", phone: "90000000", password: "motdepasse1", accept_terms: true });
  assert.equal(dup2.status, 409);
  const badRef = await call("POST", "/api/auth/register", { email: "x@test.local", username: "xx_x", first_name: "Xavier", country: "TG", phone: "90000000", password: "motdepasse1", accept_terms: true, ref_code: "NOPE99" });
  assert.equal(badRef.status, 400);
  const weak = await call("POST", "/api/auth/register", { email: "y@test.local", username: "yyy", first_name: "Yves", country: "TG", phone: "90000000", password: "court", accept_terms: true });
  assert.equal(weak.status, 400);
});

await step("connexion par nom d'utilisateur et par e-mail ; mauvais mot de passe refusé", async () => {
  assert.equal((await call("POST", "/api/auth/login", { identifier: "bob", password: "motdepasse1" })).status, 200);
  assert.equal((await call("POST", "/api/auth/login", { identifier: "BOB@test.local", password: "motdepasse1" })).status, 200);
  assert.equal((await call("POST", "/api/auth/login", { identifier: "bob", password: "mauvais123" })).status, 401);
});

await step("compte non vérifié : connexion bloquée avec indication", async () => {
  await call("POST", "/api/auth/register", { email: "carl@test.local", username: "carl", first_name: "Carl", country: "CI", phone: "0700000000", password: "motdepasse1", accept_terms: true });
  const r = await call("POST", "/api/auth/login", { identifier: "carl", password: "motdepasse1" });
  assert.equal(r.status, 403);
  assert.equal(r.data.needs_verification, true);
});

await step("mot de passe oublié → réinitialisation → anciennes sessions invalidées", async () => {
  const f = await call("POST", "/api/auth/forgot", { email: "bob@test.local" });
  assert.match(f.data.dev_code, /^\d{6}$/);
  const r = await call("POST", "/api/auth/reset", { email: "bob@test.local", code: f.data.dev_code, password: "nouveau123" });
  assert.equal(r.status, 200);
  assert.equal((await call("GET", "/api/auth/me", undefined, bob.token)).status, 401);
  const l = await call("POST", "/api/auth/login", { identifier: "bob", password: "nouveau123" });
  assert.equal(l.status, 200);
  bob = l.data;
});

await step("profil : mise à jour du téléphone et du pays", async () => {
  const r = await call("PATCH", "/api/auth/me", { country: "BJ", phone: "97112233", first_name: "Bobby" }, bob.token);
  assert.equal(r.data.user.phone, "+22997112233");
  assert.equal(r.data.user.first_name, "Bobby");
  assert.equal(r.data.user.password_hash, undefined);
});

await step("formations : création admin, invisibles tant que non publiées, refus pour un membre", async () => {
  const f = await call("POST", "/api/formations", { title: "Marketing digital", description: "Bases", published: false }, admin.token);
  assert.equal(f.status, 201);
  assert.equal((await call("GET", "/api/formations", undefined, alice.token)).data.items.length, 0);
  await call("PATCH", "/api/formations/" + f.data.id, { ...f.data, published: true }, admin.token);
  assert.equal((await call("GET", "/api/formations", undefined, alice.token)).data.items.length, 1);
  assert.equal((await call("POST", "/api/formations", { title: "X" }, alice.token)).status, 403);
});

await step("image : téléversement PNG valide, faux PNG refusé", async () => {
  const png = Buffer.from("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8ffff3f0005fe02fea7d6a4c10000000049454e44ae426082", "hex");
  const r = await call("POST", "/api/uploads/image", png, alice.token, { "Content-Type": "image/png" });
  assert.equal(r.status, 200);
  assert.match(r.data.url, /^\/uploads\/[a-f0-9]+\.png$/);
  assert.equal((await fetch(BASE + r.data.url)).status, 200);
  const fake = await call("POST", "/api/uploads/image", Buffer.from("<script>alert(1)</script>"), alice.token, { "Content-Type": "image/png" });
  assert.equal(fake.status, 400);
});

await step("applications : APK privé, lien signé, chemin interne jamais exposé", async () => {
  const a = await call("POST", "/api/applications", { name: "Outil Pro", download_type: "apk_file", price: "Gratuit" }, admin.token);
  appId = a.data.id;
  assert.equal((await call("PATCH", "/api/applications/" + appId, { published: true }, admin.token)).status, 400);
  const apk = Buffer.alloc(4096, 7);
  const up = await call("POST", `/api/applications/${appId}/apk`, apk, admin.token, { "Content-Type": "application/octet-stream", "X-Filename": "outil.apk" });
  assert.equal(up.status, 200, JSON.stringify(up.data));
  assert.equal((await call("PATCH", "/api/applications/" + appId, { published: true }, admin.token)).status, 200);
  const list = await call("GET", "/api/applications", undefined, alice.token);
  assert.equal(list.data.items[0].has_apk_file, true);
  assert.ok(!JSON.stringify(list.data).includes("apk_file_path"));
  const d = await call("POST", `/api/applications/${appId}/download`, {}, alice.token);
  const file = await fetch(BASE + d.data.url);
  assert.equal(file.status, 200);
  assert.equal((await file.arrayBuffer()).byteLength, 4096);
  assert.equal((await fetch(BASE + `/api/files/apk/${appId}?t=faux`)).status, 401);
});

await step("marketplace : annonce en validation, lien externe bloqué, publication admin", async () => {
  const cats = await call("GET", "/api/marketplace/categories", undefined, alice.token);
  const category = cats.data.items[0].name;
  const base = { name: "Sac en cuir", description: "Sac neuf", image_url: "/uploads/x.png", price_fcfa: 15000, category, seller_phone: "+22890112233" };
  const p = await call("POST", "/api/marketplace/my-products", base, alice.token);
  assert.equal(p.data.status, "pending");
  productId = p.data.product_id;
  const blocked = await call("POST", "/api/marketplace/my-products", { ...base, description: "Contactez-moi sur wa.me/22890" }, alice.token);
  assert.equal(blocked.data.blocked, true);
  const forbidden = await call("POST", "/api/marketplace/my-products", { ...base, name: "Vente de drogue" }, alice.token);
  assert.equal(forbidden.data.blocked, true);
  assert.equal((await call("GET", "/api/marketplace/products", undefined, bob.token)).data.items.length, 0);
  await call("POST", `/api/admin/marketplace/products/${productId}/moderate`, { action: "publish" }, admin.token);
  const list = await call("GET", "/api/marketplace/products?search=cuir", undefined, bob.token);
  assert.equal(list.data.items.length, 1);
  assert.equal(list.data.items[0].seller_email, undefined);
});

await step("marketplace : 3e annonce bloquée → accès vendeur suspendu automatiquement", async () => {
  const cats = await call("GET", "/api/marketplace/categories", undefined, alice.token);
  const r = await call("POST", "/api/marketplace/my-products", { name: "Lien", description: "https://exemple.com", image_url: "/uploads/x.png", price_fcfa: 1000, category: cats.data.items[0].name, seller_phone: "+22890112233" }, alice.token);
  assert.equal(r.data.suspended, true);
  const s = await call("GET", "/api/marketplace/seller-summary", undefined, alice.token);
  assert.equal(s.data.banned, true);
  await call("POST", `/api/admin/users/${alice.user.id}/marketplace-ban`, { banned: false }, admin.token);
  await call("POST", `/api/admin/marketplace/products/${productId}/moderate`, { action: "publish" }, admin.token);
});

await step("commande : création, paiement confirmé par le vendeur, réception par l'acheteur", async () => {
  assert.equal((await call("POST", "/api/marketplace/orders", { product_id: productId }, alice.token)).status, 400); // propre produit
  const o = await call("POST", "/api/marketplace/orders", { product_id: productId, note: "Livraison à Lomé" }, bob.token);
  assert.equal(o.status, 201);
  orderId = o.data.id;
  assert.equal(o.data.status, "awaiting_payment");
  assert.equal((await call("POST", `/api/marketplace/orders/${orderId}/action`, { action: "confirm_payment" }, bob.token)).status, 400);
  assert.equal((await call("POST", `/api/marketplace/orders/${orderId}/action`, { action: "confirm_payment" }, alice.token)).data.status, "processing");
  assert.equal((await call("POST", `/api/marketplace/orders/${orderId}/action`, { action: "confirm_receipt" }, bob.token)).data.status, "completed");
  const s = await call("GET", "/api/marketplace/seller-summary", undefined, alice.token);
  assert.equal(s.data.completed, 1);
  assert.equal(s.data.gross, 15000);
});

await step("litige : ouverture par l'acheteur puis décision de l'administration", async () => {
  const o = await call("POST", "/api/marketplace/orders", { product_id: productId }, bob.token);
  await call("POST", `/api/marketplace/orders/${o.data.id}/action`, { action: "confirm_payment" }, alice.token);
  assert.equal((await call("POST", `/api/marketplace/orders/${o.data.id}/action`, { action: "dispute", reason: "court" }, bob.token)).status, 400);
  const d = await call("POST", `/api/marketplace/orders/${o.data.id}/action`, { action: "dispute", reason: "Produit jamais livré malgré le paiement" }, bob.token);
  assert.equal(d.data.status, "disputed");
  const list = await call("GET", "/api/admin/marketplace/orders?status=disputed", undefined, admin.token);
  assert.equal(list.data.items.length, 1);
  assert.equal((await call("POST", `/api/admin/marketplace/orders/${o.data.id}/resolve`, { action: "refund" }, admin.token)).status, 400);
  const r = await call("POST", `/api/admin/marketplace/orders/${o.data.id}/resolve`, { action: "refund", note: "Remboursé par Mobile Money réf. 123" }, admin.token);
  assert.equal(r.data.status, "refunded");
});

await step("annuaire : consentement requis, VCF généré, exclusion des non-consentants", async () => {
  const carlTok = (await signup("dora@test.local", "dora")).token; // sans partage
  assert.equal((await call("GET", "/api/contacts/directory", undefined, carlTok)).status, 403);
  const dir = await call("GET", "/api/contacts/directory", undefined, alice.token);
  assert.ok(dir.data.items.every((m) => m.name.endsWith(" Novatrax")));
  assert.ok(!dir.data.items.some((m) => m.name.includes("dora")));
  const vcf = await call("GET", "/api/contacts/download", undefined, alice.token);
  assert.match(vcf.data, /BEGIN:VCARD/);
  const csv = await call("GET", "/api/admin/contacts/export?format=csv", undefined, admin.token);
  assert.match(csv.data, /Nom du contact;Telephone/);
});

await step("messages : envoi à tous → boîte de réception et compteur non lus", async () => {
  const before = (await call("GET", "/api/inbox/unread", undefined, bob.token)).data.count;
  const m = await call("POST", "/api/admin/messages", { subject: "Bienvenue", body: "Nouvelle formation disponible", audience: { type: "all" }, channels: { inbox: true } }, admin.token);
  assert.equal(m.status, 200);
  assert.equal((await call("GET", "/api/inbox/unread", undefined, bob.token)).data.count, before + 1);
  await call("POST", "/api/inbox/read-all", {}, bob.token);
  assert.equal((await call("GET", "/api/inbox/unread", undefined, bob.token)).data.count, 0);
});

await step("blocage : session coupée, connexion refusée ; déblocage", async () => {
  assert.equal((await call("POST", `/api/admin/users/${bob.user.id}/moderate`, { action: "block" }, admin.token)).status, 400); // motif requis
  await call("POST", `/api/admin/users/${bob.user.id}/moderate`, { action: "block", reason: "Test" }, admin.token);
  assert.equal((await call("GET", "/api/member/home", undefined, bob.token)).status, 401);
  assert.equal((await call("POST", "/api/auth/login", { identifier: "bob", password: "nouveau123" })).status, 403);
  await call("POST", `/api/admin/users/${bob.user.id}/moderate`, { action: "unblock" }, admin.token);
  assert.equal((await call("POST", "/api/auth/login", { identifier: "bob", password: "nouveau123" })).status, 200);
});

await step("administration : statistiques, fiche membre, journal d'audit, accès refusé aux membres", async () => {
  const s = await call("GET", "/api/admin/stats", undefined, admin.token);
  assert.ok(s.data.members >= 4);
  const sheet = await call("GET", `/api/admin/users/${alice.user.id}`, undefined, admin.token);
  assert.equal(sheet.data.referrals_total, 1);
  const audit = await call("GET", "/api/admin/audit", undefined, admin.token);
  assert.ok(audit.data.items.some((a) => a.action === "user_block"));
  assert.equal((await call("GET", "/api/admin/stats", undefined, alice.token)).status, 403);
  assert.equal((await call("GET", "/api/admin/stats")).status, 401);
});

await step("interface : index.html servi pour les routes de l'application", async () => {
  const r = await fetch(BASE + "/marketplace/produit/abc");
  assert.ok([200, 503].includes(r.status));
});

srv.kill();
fs.rmSync(DATA, { recursive: true, force: true });
console.log(`\n${passed} tests réussis.`);
