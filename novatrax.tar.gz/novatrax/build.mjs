// Compilation de l'interface : esbuild (JS/JSX) + Tailwind CSS v4 (API compile).
// Usage : node build.mjs [--watch]
import * as esbuild from "esbuild";
import { compile } from "tailwindcss";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const ROOT = path.dirname(new URL(import.meta.url).pathname);
const SRC = path.join(ROOT, "client", "src");
const DIST = path.join(ROOT, "dist");
const ASSETS = path.join(DIST, "assets");
const watch = process.argv.includes("--watch");

const twDir = path.dirname(require.resolve("tailwindcss/package.json"));

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (/\.(jsx?|tsx?|html)$/.test(e.name)) out.push(p);
  }
  return out;
}

// Candidats Tailwind : tous les mots plausibles des fichiers sources.
function candidates() {
  const set = new Set();
  for (const f of [...walk(SRC), path.join(ROOT, "client", "index.html")]) {
    for (const tok of fs.readFileSync(f, "utf8").split(/[\s"'`{}()<>;,]+/)) {
      if (tok && tok.length < 120 && /^[!-~]+$/.test(tok)) set.add(tok);
    }
  }
  return [...set];
}

async function buildCss() {
  const input = fs.readFileSync(path.join(SRC, "styles.css"), "utf8");
  const compiler = await compile(input, {
    base: SRC,
    loadStylesheet: async (id, base) => {
      const file = id === "tailwindcss" ? path.join(twDir, "index.css")
        : id.startsWith("tailwindcss/") ? path.join(twDir, id.slice(12))
        : path.resolve(base, id);
      return { path: file, base: path.dirname(file), content: fs.readFileSync(file, "utf8") };
    },
  });
  return compiler.build(candidates());
}

const hash = (s) => crypto.createHash("sha256").update(s).digest("hex").slice(0, 10);

async function writeOutputs(jsCode) {
  const css = await buildCss();
  fs.rmSync(ASSETS, { recursive: true, force: true });
  fs.mkdirSync(ASSETS, { recursive: true });
  const jsName = `app.${hash(jsCode)}.js`;
  const cssName = `app.${hash(css)}.css`;
  fs.writeFileSync(path.join(ASSETS, jsName), jsCode);
  fs.writeFileSync(path.join(ASSETS, cssName), css);
  const html = fs.readFileSync(path.join(ROOT, "client", "index.html"), "utf8")
    .replace("<!--CSS-->", `<link rel="stylesheet" href="/assets/${cssName}">`)
    .replace("<!--JS-->", `<script type="module" src="/assets/${jsName}"></script>`);
  fs.writeFileSync(path.join(DIST, "index.html"), html);
  const pub = path.join(ROOT, "client", "public");
  if (fs.existsSync(pub)) fs.cpSync(pub, DIST, { recursive: true });
  console.log(`[build] ${new Date().toLocaleTimeString("fr-FR")} — ${jsName} (${(jsCode.length / 1024).toFixed(0)} Ko), ${cssName} (${(css.length / 1024).toFixed(0)} Ko)`);
}

const options = {
  entryPoints: [path.join(SRC, "main.jsx")],
  bundle: true,
  format: "esm",
  minify: !watch,
  sourcemap: false,
  write: false,
  jsx: "automatic",
  target: ["es2020"],
  define: { "process.env.NODE_ENV": JSON.stringify(watch ? "development" : "production") },
  loader: { ".js": "jsx" },
  alias: { "@shared": path.join(ROOT, "shared") },
  logLevel: "warning",
};

fs.mkdirSync(DIST, { recursive: true });
if (watch) {
  const ctx = await esbuild.context({
    ...options,
    plugins: [{
      name: "out",
      setup(b) {
        b.onEnd(async (r) => {
          if (r.errors.length) return;
          await writeOutputs(r.outputFiles[0].text);
        });
      },
    }],
  });
  await ctx.watch();
  console.log("[build] surveillance des fichiers… (Ctrl+C pour arrêter)");
} else {
  const r = await esbuild.build(options);
  await writeOutputs(r.outputFiles[0].text);
}
