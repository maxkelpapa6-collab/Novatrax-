import { Link } from "../lib/router";

export const LOGO_URL = "/logo.svg";

const SIZES = { sm: [28, "text-lg"], md: [36, "text-xl"], lg: [44, "text-2xl"] };

export default function Logo({ to = "/", size = "md", violet = false, onClick }) {
  const [px, text] = SIZES[size] || SIZES.md;
  return (
    <Link to={to} onClick={onClick} className="inline-flex items-center gap-2.5" aria-label="NOVATRAX — accueil">
      <img src={LOGO_URL} alt="" width={px} height={px} className="shrink-0 rounded-xl shadow-sm" />
      <span className={`font-heading font-extrabold tracking-tight ${text} text-foreground`}>
        NOVA<span className={violet ? "text-violet" : "text-gradient-novatrax"}>TRAX</span>
      </span>
    </Link>
  );
}
