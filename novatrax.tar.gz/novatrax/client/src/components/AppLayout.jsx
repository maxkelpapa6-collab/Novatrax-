import { useCallback, useEffect, useState } from "react";
import {
  LuHouse, LuMail, LuGraduationCap, LuSmartphone, LuUser, LuUsers, LuGift, LuLogOut, LuLayoutDashboard,
  LuInbox, LuShoppingBag, LuStore, LuPackage, LuShieldCheck, LuMenu, LuX, LuBell, LuChevronDown, LuBan,
} from "react-icons/lu";
import { NavLink, useLocation, useNavigate } from "../lib/router";
import { useAuth } from "../lib/auth";
import { api } from "../lib/api";
import { initials } from "../lib/format";
import Logo from "./Logo";

// Barre de navigation basse (mobile) : quatre entrées.
const NAV_ITEMS = [
  { to: "/", label: "Accueil", icon: LuHouse, end: true },
  { to: "/contact", label: "Contact", icon: LuMail },
  { to: "/formation", label: "Formation", icon: LuGraduationCap },
  { to: "/apk-pro", label: "Les APK Pro", icon: LuSmartphone },
];

const MENU_ITEMS = [
  { to: "/", label: "Tableau de bord", icon: LuLayoutDashboard, end: true },
  { to: "/boite-reception", label: "Boîte de réception", icon: LuInbox, inbox: true },
  { to: "/profile", label: "Mon profil", icon: LuUser },
  { to: "/#parrainage", label: "Mon lien d'invitation", icon: LuGift, hash: true },
  { to: "/reseau", label: "Mon réseau", icon: LuUsers },
  { to: "/formation", label: "Formation", icon: LuGraduationCap },
  { to: "/apk-pro", label: "Les APK Pro", icon: LuSmartphone },
  { to: "/marketplace", label: "Marketplace", icon: LuShoppingBag },
  { to: "/ma-boutique", label: "Ma boutique", icon: LuStore },
  { to: "/mes-achats", label: "Mes achats", icon: LuPackage },
  { to: "/contact", label: "Contact", icon: LuMail },
];

// Compteur de messages non lus, rafraîchi périodiquement et à la demande.
export function useUnread(userId) {
  const [count, setCount] = useState(0);
  const refresh = useCallback(async () => {
    if (!userId) return;
    try {
      setCount((await api.get("/api/inbox/unread")).count);
    } catch {
      /* silencieux */
    }
  }, [userId]);
  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 60_000);
    window.addEventListener("novatrax:inbox", refresh);
    return () => {
      clearInterval(t);
      window.removeEventListener("novatrax:inbox", refresh);
    };
  }, [refresh]);
  return count;
}

const itemCls = ({ isActive }) =>
  `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
    isActive ? "gradient-novatrax text-white shadow-sm" : "text-foreground hover:bg-muted"
  }`;

function MenuList({ onNavigate, isAdmin, onLogout, unread }) {
  const { pathname, hash } = useLocation();
  return (
    <>
      {MENU_ITEMS.map((item) => {
        const Icon = item.icon;
        const onReferral = pathname === "/" && hash === "#parrainage";
        return (
          <NavLink
            key={item.label}
            to={item.to}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) =>
              itemCls({ isActive: item.hash ? onReferral : item.to === "/" ? isActive && !onReferral : isActive })
            }
          >
            <Icon className="h-5 w-5" />
            <span className="flex-1">{item.label}</span>
            {item.inbox && unread > 0 && (
              <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1.5 text-[10px] font-bold text-destructive-foreground">
                {unread > 99 ? "99+" : unread}
              </span>
            )}
          </NavLink>
        );
      })}
      {isAdmin && (
        <NavLink to="/admin" onClick={onNavigate} className={itemCls}>
          <LuShieldCheck className="h-5 w-5" /> Espace administrateur
        </NavLink>
      )}
      <button onClick={onLogout} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-destructive hover:bg-destructive/5">
        <LuLogOut className="h-5 w-5" /> Déconnexion
      </button>
    </>
  );
}

function BottomNav() {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 lg:hidden bg-background/95 backdrop-blur-md border-t border-border">
      <div className="mx-auto max-w-2xl grid grid-cols-4 px-2">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `flex flex-col items-center justify-center gap-1 py-2.5 ${isActive ? "text-violet" : "text-muted-foreground"}`}
            >
              {({ isActive }) => (
                <>
                  <span className={`flex h-9 w-9 items-center justify-center rounded-xl transition-all ${isActive ? "gradient-novatrax text-white shadow-md" : ""}`}>
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="text-[10px] font-semibold tracking-tight">{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </div>
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  );
}

export default function AppLayout({ children }) {
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const unread = useUnread(user?.id);
  const firstName = user?.first_name || user?.username || "Utilisateur";

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  if (user?.account_status === "suspended") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 text-center shadow-card">
          <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
            <LuBan className="h-7 w-7" />
          </span>
          <h1 className="mt-4 font-heading text-2xl font-bold">Compte bloqué</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Votre compte a été suspendu par l'administration NOVATRAX.
            {user?.blocked_reason ? ` Motif : ${user.blocked_reason}.` : ""} Vos données et votre historique sont conservés. Contactez le support pour toute question.
          </p>
          <button onClick={handleLogout} className="mt-6 inline-flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-semibold hover:bg-muted">
            <LuLogOut className="h-4 w-4" /> Se déconnecter
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur-md">
        <div className="flex h-16 items-center justify-between px-4 lg:px-6">
          <div className="flex items-center gap-2">
            <button className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-xl hover:bg-muted" onClick={() => setMobileOpen((v) => !v)} aria-label="Menu">
              {mobileOpen ? <LuX className="h-5 w-5" /> : <LuMenu className="h-5 w-5" />}
            </button>
            <Logo onClick={() => setMobileOpen(false)} />
          </div>
          <div className="flex items-center gap-2">
            <NavLink to="/boite-reception" aria-label="Boîte de réception" className="relative inline-flex h-10 w-10 items-center justify-center rounded-xl hover:bg-muted">
              <LuBell className="h-5 w-5" />
              {unread > 0 && (
                <span className="absolute right-0.5 top-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
                  {unread > 9 ? "9+" : unread}
                </span>
              )}
            </NavLink>
            <div className="relative">
              <button onClick={() => setProfileOpen((v) => !v)} className="flex items-center gap-2 rounded-xl border border-border px-2 py-1.5 hover:bg-muted">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg gradient-novatrax text-sm font-bold text-white">{initials(user)}</span>
                <span className="hidden sm:block text-sm font-semibold max-w-[120px] truncate">{firstName}</span>
                <LuChevronDown className="h-4 w-4 text-muted-foreground" />
              </button>
              {profileOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} />
                  <div className="absolute right-0 mt-2 w-60 rounded-2xl border border-border bg-popover shadow-card-hover z-50 overflow-hidden animate-fade">
                    <div className="px-4 py-3 border-b border-border">
                      <p className="text-sm font-semibold truncate">{user?.email}</p>
                      <p className="text-xs text-muted-foreground">{isAdmin ? "Administrateur" : "Membre"}</p>
                    </div>
                    {[["Mes informations personnelles", "/profile"], ["Paramètres & sécurité", "/profile#securite"], ...(isAdmin ? [["Espace administrateur", "/admin"]] : [])].map(([l, to]) => (
                      <button key={l} onClick={() => { setProfileOpen(false); navigate(to); }} className="flex w-full items-center px-4 py-2.5 text-sm hover:bg-muted">
                        {l}
                      </button>
                    ))}
                    <button onClick={handleLogout} className="flex w-full items-center gap-2.5 px-4 py-2.5 text-sm text-destructive hover:bg-destructive/5">
                      <LuLogOut className="h-4 w-4" /> Déconnexion
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
        {mobileOpen && (
          <div className="lg:hidden border-t border-border bg-background">
            <nav className="px-3 py-3 space-y-1 max-h-[calc(100vh-4rem)] overflow-y-auto">
              <MenuList onNavigate={() => setMobileOpen(false)} isAdmin={isAdmin} onLogout={handleLogout} unread={unread} />
            </nav>
          </div>
        )}
      </header>
      <div className="flex">
        <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-border bg-sidebar/50 sticky top-16 h-[calc(100vh-4rem)]">
          <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
            <MenuList isAdmin={isAdmin} onLogout={handleLogout} unread={unread} />
          </nav>
        </aside>
        <main className="flex-1 min-w-0 pb-24 lg:pb-10">{children}</main>
      </div>
      <BottomNav />
    </div>
  );
}
