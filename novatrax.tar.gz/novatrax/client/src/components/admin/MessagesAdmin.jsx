import { useEffect, useState } from "react";
import { LuSend, LuMail, LuInbox, LuFlaskConical } from "react-icons/lu";
import { api } from "../../lib/api";
import { COUNTRIES, formatDateTime, errMsg } from "../../lib/format";
import { useToast } from "../../lib/toast";
import { Card, Button, Field, Alert, Badge, Skeleton, ConfirmModal, useLoad } from "../ui";

const AUDIENCES = [
  ["all", "Tous les membres"],
  ["country", "Par pays"],
  ["period", "Par période d'inscription"],
];
const STATUS = { sending: ["En cours", "bg-amber-500/10 text-amber-700"], sent: ["Envoyé", "bg-emerald-500/10 text-emerald-700"], partial: ["Partielle", "bg-amber-500/10 text-amber-700"], failed: ["Échec", "bg-destructive/10 text-destructive"] };

export default function MessagesAdmin() {
  const toast = useToast();
  const history = useLoad(() => api.get("/api/admin/messages"));
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [aud, setAud] = useState({ type: "all", country: "", date_from: "", date_to: "" });
  const [channels, setChannels] = useState({ inbox: true, email: false });
  const [count, setCount] = useState(null);
  const [confirm, setConfirm] = useState(false);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => {
      api.post("/api/admin/messages/count", { audience: aud }).then((r) => setCount(r.count)).catch(() => setCount(null));
    }, 300);
    return () => clearTimeout(t);
  }, [aud]);

  const test = async () => {
    setTesting(true);
    try {
      const r = await api.post("/api/admin/messages/test", { subject, body });
      toast(r.ok ? { title: "E-mail de test envoyé", description: r.console ? "Mode console : voir la sortie du serveur." : "Vérifiez votre boîte e-mail." } : { title: "Échec de l'envoi", description: r.error, variant: "destructive" });
    } catch (e) {
      toast({ title: "Envoi impossible", description: errMsg(e), variant: "destructive" });
    } finally {
      setTesting(false);
    }
  };

  const send = async () => {
    await api.post("/api/admin/messages", { subject, body, audience: aud, channels });
    toast({ title: "Message envoyé", description: "Le message a été envoyé aux membres concernés." });
    setSubject("");
    setBody("");
    setTimeout(() => history.reload(true), 800);
  };

  const ready = subject.trim().length >= 3 && body.trim().length >= 3 && (channels.inbox || channels.email) && count > 0;

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
      <Card className="p-5 lg:col-span-3">
        <h2 className="font-heading text-lg font-bold">Message aux membres</h2>
        {history.data && !history.data.mail_configured && channels.email && (
          <Alert variant="warning" className="mt-3">Aucun service e-mail n'est configuré : les e-mails seront seulement affichés dans la console du serveur.</Alert>
        )}
        <div className="mt-4 space-y-4">
          <Field label="Destinataires">
            <div className="flex flex-wrap gap-2">
              {AUDIENCES.map(([v, l]) => (
                <button key={v} type="button" onClick={() => setAud({ ...aud, type: v })} className={`rounded-full px-3.5 py-1.5 text-sm font-semibold ${aud.type === v ? "gradient-novatrax text-white" : "border border-border hover:bg-muted"}`}>{l}</button>
              ))}
            </div>
          </Field>
          {aud.type === "country" && (
            <select className="field" value={aud.country} onChange={(e) => setAud({ ...aud, country: e.target.value })}>
              <option value="">Choisir un pays…</option>
              {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.flag} {c.name}</option>)}
            </select>
          )}
          {aud.type === "period" && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Inscrits depuis"><input type="date" className="field" value={aud.date_from} onChange={(e) => setAud({ ...aud, date_from: e.target.value })} /></Field>
              <Field label="Jusqu'au"><input type="date" className="field" value={aud.date_to} onChange={(e) => setAud({ ...aud, date_to: e.target.value })} /></Field>
            </div>
          )}
          <p className="text-sm text-muted-foreground">Destinataires actifs : <span className="font-semibold text-foreground">{count ?? "—"}</span></p>
          <Field label="Objet du message"><input className="field" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Ex. Nouvelle formation disponible" maxLength={150} /></Field>
          <Field label="Contenu du message"><textarea className="field min-h-40" value={body} onChange={(e) => setBody(e.target.value)} placeholder="Rédigez votre message… (les sauts de ligne sont conservés)" /></Field>
          <div className="flex flex-wrap gap-4">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-violet" checked={channels.inbox} onChange={(e) => setChannels({ ...channels, inbox: e.target.checked })} /> <LuInbox className="h-4 w-4" /> Boîte de réception</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-violet" checked={channels.email} onChange={(e) => setChannels({ ...channels, email: e.target.checked })} /> <LuMail className="h-4 w-4" /> E-mail</label>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" icon={LuFlaskConical} loading={testing} disabled={!subject.trim() || !body.trim()} onClick={test}>M'envoyer un test</Button>
            <Button icon={LuSend} disabled={!ready} onClick={() => setConfirm(true)}>Envoyer à {count ?? 0} membre(s)</Button>
          </div>
        </div>
      </Card>
      <Card className="p-5 lg:col-span-2">
        <h2 className="font-heading text-lg font-bold">Derniers envois</h2>
        {history.loading ? <Skeleton className="mt-4 h-32" /> : !history.data?.items?.length ? (
          <p className="mt-4 text-sm text-muted-foreground">Aucun message envoyé pour le moment.</p>
        ) : (
          <ul className="mt-3 divide-y divide-border">
            {history.data.items.map((c) => (
              <li key={c.id} className="py-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-semibold">{c.subject}</p>
                  <Badge className={STATUS[c.status]?.[1]}>{STATUS[c.status]?.[0]}</Badge>
                </div>
                <p className="text-xs text-muted-foreground">{c.audience_details} · {c.recipients_count} destinataire(s) · {c.channels}</p>
                <p className="text-xs text-muted-foreground">{formatDateTime(c.created_date)} · {c.sent_by_email}{c.failed_count ? ` · ${c.failed_count} échec(s)` : ""}</p>
              </li>
            ))}
          </ul>
        )}
      </Card>
      {confirm && (
        <ConfirmModal title="Confirmer l'envoi" text={`Envoyer « ${subject} » à ${count} membre(s) ?`} confirmLabel="Envoyer" onConfirm={send} onClose={() => setConfirm(false)} />
      )}
    </div>
  );
}
