import { useState } from "react";
import { LuSearch, LuCheck, LuX, LuBan, LuEyeOff, LuTrash2, LuPlus, LuRotateCcw, LuPower } from "react-icons/lu";
import { api, qs } from "../../lib/api";
import { formatFcfa, formatDateTime, errMsg } from "../../lib/format";
import { useToast } from "../../lib/toast";
import { Card, Button, Skeleton, ConfirmModal, Field, useLoad } from "../ui";
import { PRODUCT_STATUS, ORDER_STATUS, ProductBadge, OrderBadge } from "../marketplace";
import UserSheet from "../UserSheet";

const pill = (on) => `whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-semibold ${on ? "gradient-novatrax text-white" : "border border-border hover:bg-muted"}`;

function Products() {
  const [status, setStatus] = useState("pending");
  const [search, setSearch] = useState("");
  const [q, setQ] = useState("");
  const [confirm, setConfirm] = useState(null);
  const [sheet, setSheet] = useState(null);
  const { data, loading, reload } = useLoad(() => api.get("/api/admin/marketplace/products" + qs({ status, search: q })), [status, q]);
  const mod = (p, action, opts = {}) =>
    setConfirm({ ...opts, run: (reason) => api.post(`/api/admin/marketplace/products/${p.id}/moderate`, { action, reason }) });

  return (
    <div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        <button className={pill(!status)} onClick={() => setStatus("")}>Toutes</button>
        {Object.entries(PRODUCT_STATUS).map(([k, [l]]) => (
          <button key={k} className={pill(status === k)} onClick={() => setStatus(k)}>{l} {data?.counts?.[k] ? `(${data.counts[k]})` : ""}</button>
        ))}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); setQ(search.trim()); }} className="mt-3 relative max-w-md">
        <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher une annonce ou un vendeur…" className="field pl-9" />
      </form>
      {loading ? <Skeleton className="mt-4 h-40" /> : (
        <Card className="mt-4 overflow-hidden">
          <ul className="divide-y divide-border">
            {data?.items?.map((p) => (
              <li key={p.id} className="flex flex-col md:flex-row gap-3 p-4">
                <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-muted">{p.image_url && <img src={p.image_url} alt="" className="h-full w-full object-cover" />}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2"><p className="font-semibold">{p.name}</p><ProductBadge status={p.status} /></div>
                  <p className="text-sm text-muted-foreground">{formatFcfa(p.price_fcfa)} · {p.category} · {formatDateTime(p.updated_date)}</p>
                  <p className="text-sm">Vendeur : <button onClick={() => setSheet(p.seller_id)} className="font-medium text-primary hover:underline">{p.seller_name}</button> · {p.seller_phone}</p>
                  {p.description && <p className="mt-1 text-sm text-muted-foreground line-clamp-3 whitespace-pre-line">{p.description}</p>}
                  {(p.blocked_reason || p.rejection_reason) && <p className="mt-1 text-xs text-destructive">{p.blocked_reason || p.rejection_reason}</p>}
                </div>
                <div className="flex flex-wrap md:flex-col gap-2 md:w-40">
                  {p.status !== "published" && <Button size="sm" variant="success" icon={LuCheck} onClick={() => mod(p, "publish", { title: "Publier l'annonce", label: "Publier" })}>Publier</Button>}
                  {p.status === "pending" && <Button size="sm" variant="outline" icon={LuX} onClick={() => mod(p, "reject", { title: "Refuser l'annonce", label: "Refuser", variant: "danger", reason: true, reasonLabel: "Motif du refus (visible par le vendeur)" })}>Refuser</Button>}
                  {p.status !== "blocked" && <Button size="sm" variant="danger" icon={LuBan} onClick={() => mod(p, "block", { title: "Bloquer l'annonce", label: "Bloquer", variant: "danger", reason: true, reasonLabel: "Motif du blocage" })}>Bloquer</Button>}
                  {p.status === "published" && <Button size="sm" variant="outline" icon={LuEyeOff} onClick={() => mod(p, "hide", { title: "Masquer l'annonce", label: "Masquer" })}>Masquer</Button>}
                  {["blocked", "rejected"].includes(p.status) && <Button size="sm" variant="outline" icon={LuRotateCcw} onClick={() => mod(p, "pending", { title: "Réexaminer (recours)", text: "L'annonce repasse en validation.", label: "Réexaminer" })}>Réexaminer</Button>}
                  <Button size="sm" variant="danger" icon={LuTrash2} onClick={() => mod(p, "delete", { title: "Supprimer l'annonce", text: "Suppression définitive.", label: "Supprimer", variant: "danger" })}>Supprimer</Button>
                </div>
              </li>
            ))}
            {!data?.items?.length && <li className="p-8 text-center text-muted-foreground">Aucune annonce dans cette catégorie.</li>}
          </ul>
        </Card>
      )}
      {confirm && (
        <ConfirmModal title={confirm.title} text={confirm.text} confirmLabel={confirm.label} variant={confirm.variant} reason={confirm.reason} reasonRequired reasonLabel={confirm.reasonLabel}
          onConfirm={async (r) => { await confirm.run(r); reload(true); }} onClose={() => setConfirm(null)} />
      )}
      {sheet && <UserSheet userId={sheet} onClose={() => setSheet(null)} />}
    </div>
  );
}

function Orders() {
  const [status, setStatus] = useState("disputed");
  const [confirm, setConfirm] = useState(null);
  const { data, loading, reload } = useLoad(() => api.get("/api/admin/marketplace/orders" + qs({ status })), [status]);
  const resolve = (o, action, opts) => setConfirm({ ...opts, run: (note) => api.post(`/api/admin/marketplace/orders/${o.id}/resolve`, { action, note }) });
  return (
    <div>
      {data?.totals && (
        <p className="mb-3 text-sm text-muted-foreground">
          Ventes terminées : <span className="font-semibold text-foreground">{data.totals.n}</span> · Volume : <span className="font-semibold text-foreground">{formatFcfa(data.totals.gross)}</span>
          {data.totals.commission > 0 && <> · Commissions : <span className="font-semibold text-foreground">{formatFcfa(data.totals.commission)}</span></>}
        </p>
      )}
      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        <button className={pill(!status)} onClick={() => setStatus("")}>Toutes les commandes</button>
        {Object.entries(ORDER_STATUS).map(([k, [l]]) => (
          <button key={k} className={pill(status === k)} onClick={() => setStatus(k)}>{l} {data?.counts?.[k] ? `(${data.counts[k]})` : ""}</button>
        ))}
      </div>
      {loading ? <Skeleton className="mt-4 h-40" /> : (
        <Card className="mt-4 overflow-hidden">
          <ul className="divide-y divide-border">
            {data?.items?.map((o) => (
              <li key={o.id} className="p-4">
                <div className="flex flex-wrap items-center gap-2"><p className="font-semibold">{o.order_ref} — {o.product_name}</p><OrderBadge status={o.status} /></div>
                <p className="text-sm text-muted-foreground">{formatFcfa(o.product_price_fcfa)} · créée le {formatDateTime(o.created_date)}</p>
                <p className="text-sm">Acheteur : {o.buyer_name} ({o.buyer_phone || o.buyer_email}) · Vendeur : {o.seller_name} ({o.seller_phone || o.seller_email})</p>
                {o.dispute_reason && <p className="mt-1 text-sm text-destructive">Litige : {o.dispute_reason}</p>}
                {o.resolution_note && <p className="mt-1 text-sm text-muted-foreground">Note : {o.resolution_note} {o.reviewed_by ? `— ${o.reviewed_by}` : ""}</p>}
                {["awaiting_payment", "processing", "disputed"].includes(o.status) && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" variant="success" onClick={() => resolve(o, "complete", { title: "Clôturer la vente", text: "La commande sera marquée comme terminée.", label: "Terminer", reason: true, reasonRequired: false, reasonLabel: "Note (facultative)" })}>Terminer la vente</Button>
                    <Button size="sm" variant="outline" onClick={() => resolve(o, "cancel", { title: "Annuler la commande", label: "Annuler la commande", variant: "danger", reason: true, reasonRequired: false, reasonLabel: "Note (facultative)" })}>Annuler</Button>
                    <Button size="sm" variant="danger" onClick={() => resolve(o, "refund", { title: "Marquer comme remboursée", text: "Le remboursement doit avoir été effectué en dehors de la plateforme (aucun paiement n'est géré par NOVATRAX).", label: "Marquer remboursée", variant: "danger", reason: true, reasonRequired: true, reasonLabel: "Note de remboursement (moyen, référence…)" })}>Remboursée</Button>
                  </div>
                )}
              </li>
            ))}
            {!data?.items?.length && <li className="p-8 text-center text-muted-foreground">Aucune commande dans cette catégorie.</li>}
          </ul>
        </Card>
      )}
      {confirm && (
        <ConfirmModal title={confirm.title} text={confirm.text} confirmLabel={confirm.label} variant={confirm.variant} reason={confirm.reason} reasonRequired={confirm.reasonRequired} reasonLabel={confirm.reasonLabel}
          onConfirm={async (r) => { await confirm.run(r); reload(true); }} onClose={() => setConfirm(null)} />
      )}
    </div>
  );
}

function Settings() {
  const toast = useToast();
  const cats = useLoad(() => api.get("/api/admin/marketplace/categories").then((r) => r.items));
  const rules = useLoad(() => api.get("/api/admin/marketplace/rules").then((r) => r.items));
  const [cat, setCat] = useState("");
  const [rule, setRule] = useState({ value: "", note: "" });
  const run = async (fn, after) => {
    try { await fn(); after(); } catch (e) { toast({ title: "Action impossible", description: errMsg(e), variant: "destructive" }); }
  };
  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card className="p-5">
        <h3 className="font-heading text-lg font-bold">Catégories autorisées</h3>
        <form onSubmit={(e) => { e.preventDefault(); run(() => api.post("/api/admin/marketplace/categories", { name: cat }), () => { setCat(""); cats.reload(true); }); }} className="mt-3 flex gap-2">
          <input className="field" value={cat} onChange={(e) => setCat(e.target.value)} placeholder="Nouvelle catégorie" />
          <Button type="submit" icon={LuPlus} disabled={cat.trim().length < 2}>Ajouter</Button>
        </form>
        <ul className="mt-3 divide-y divide-border">
          {cats.data?.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-2 py-2.5">
              <div className="min-w-0">
                <p className={`text-sm font-semibold ${c.active ? "" : "text-muted-foreground line-through"}`}>{c.name}</p>
                <p className="text-xs text-muted-foreground">{c.products} annonce(s) · {c.active ? "Ouverte aux annonces" : "Désactivée"}</p>
              </div>
              <div className="flex gap-1.5">
                <Button size="sm" variant="outline" icon={LuPower} onClick={() => run(() => api.patch(`/api/admin/marketplace/categories/${c.id}`, { active: !c.active }), () => cats.reload(true))}>{c.active ? "Désactiver" : "Activer"}</Button>
                <Button size="sm" variant="danger" icon={LuTrash2} onClick={() => run(() => api.del(`/api/admin/marketplace/categories/${c.id}`), () => cats.reload(true))} aria-label="Supprimer" />
              </div>
            </li>
          ))}
        </ul>
      </Card>
      <Card className="p-5">
        <h3 className="font-heading text-lg font-bold">Produits &amp; contenus interdits</h3>
        <p className="mt-1 text-sm text-muted-foreground">Toute annonce contenant l'un de ces termes est bloquée automatiquement. Trois blocages en 30 jours suspendent l'accès vendeur.</p>
        <form onSubmit={(e) => { e.preventDefault(); run(() => api.post("/api/admin/marketplace/rules", rule), () => { setRule({ value: "", note: "" }); rules.reload(true); }); }} className="mt-3 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <Field><input className="field" value={rule.value} onChange={(e) => setRule({ ...rule, value: e.target.value })} placeholder="Terme interdit" /></Field>
            <Field><input className="field" value={rule.note} onChange={(e) => setRule({ ...rule, note: e.target.value })} placeholder="Note (facultatif)" /></Field>
          </div>
          <Button type="submit" icon={LuPlus} disabled={rule.value.trim().length < 3}>Ajouter la règle</Button>
        </form>
        <ul className="mt-3 divide-y divide-border">
          {rules.data?.map((r) => (
            <li key={r.id} className="flex items-center justify-between gap-2 py-2.5">
              <div><p className="text-sm font-semibold">« {r.value} »</p>{r.note && <p className="text-xs text-muted-foreground">{r.note}</p>}</div>
              <Button size="sm" variant="danger" icon={LuTrash2} onClick={() => run(() => api.del(`/api/admin/marketplace/rules/${r.id}`), () => rules.reload(true))} aria-label="Supprimer" />
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

export default function MarketplaceAdmin() {
  const [tab, setTab] = useState("products");
  return (
    <div>
      <div className="mb-5 inline-flex gap-1 rounded-2xl border border-border bg-card p-1.5 shadow-card">
        {[["products", "Annonces"], ["orders", "Commandes & litiges"], ["settings", "Catégories & règles"]].map(([id, l]) => (
          <button key={id} onClick={() => setTab(id)} className={`rounded-xl px-4 py-2 text-sm font-semibold whitespace-nowrap ${tab === id ? "gradient-novatrax text-white" : "text-muted-foreground hover:bg-muted"}`}>{l}</button>
        ))}
      </div>
      {tab === "products" && <Products />}
      {tab === "orders" && <Orders />}
      {tab === "settings" && <Settings />}
    </div>
  );
}
