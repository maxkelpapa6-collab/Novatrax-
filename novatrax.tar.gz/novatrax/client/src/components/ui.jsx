// Composants d'interface communs.
import { useCallback, useEffect, useRef, useState } from "react";
import { LuLoaderCircle, LuX, LuImagePlus, LuTrash2 } from "react-icons/lu";
import { uploadImage } from "../lib/api";
import { errMsg } from "../lib/format";
import { useToast } from "../lib/toast";

export const Spinner = ({ className = "h-4 w-4" }) => <LuLoaderCircle className={`animate-spin ${className}`} />;

const VARIANTS = {
  primary: "gradient-novatrax text-white shadow-card hover:shadow-card-hover",
  violet: "bg-violet text-violet-foreground hover:bg-violet/90",
  outline: "border border-border bg-card hover:bg-muted",
  danger: "border border-destructive/30 text-destructive hover:bg-destructive/5",
  success: "border border-emerald-500/30 text-emerald-700 hover:bg-emerald-500/5",
  ghost: "hover:bg-muted",
};
const SIZES = { sm: "px-3 py-1.5 text-xs rounded-lg", md: "px-4 py-2.5 text-sm rounded-xl", lg: "h-12 px-5 text-sm rounded-xl" };

export function Button({ variant = "primary", size = "md", loading, icon: Icon, className = "", children, disabled, ...rest }) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 font-semibold transition-all disabled:opacity-55 ${VARIANTS[variant]} ${SIZES[size]} ${className}`}
      disabled={disabled || loading}
      {...rest}
    >
      {loading ? <Spinner /> : Icon ? <Icon className={size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"} /> : null}
      {children}
    </button>
  );
}

export function Field({ label, hint, error, children, className = "" }) {
  return (
    <label className={`block ${className}`}>
      {label && <span className="mb-1.5 block text-sm font-medium text-foreground">{label}</span>}
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-muted-foreground">{hint}</span>}
      {error && <span className="mt-1 block text-xs text-destructive">{error}</span>}
    </label>
  );
}

export function Alert({ variant = "error", children, className = "" }) {
  const cls = {
    error: "bg-destructive/10 text-destructive",
    success: "bg-emerald-500/10 text-emerald-700",
    info: "bg-primary/10 text-primary",
    warning: "bg-amber-500/10 text-amber-700",
  }[variant];
  return <div className={`rounded-xl px-4 py-3 text-sm ${cls} ${className}`}>{children}</div>;
}

export function Badge({ className = "", children }) {
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold ${className}`}>{children}</span>;
}

export function Chip({ icon: Icon, children, tone = "primary" }) {
  const cls = tone === "violet" ? "bg-violet/10 text-violet" : "bg-primary/10 text-primary";
  return (
    <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ${cls}`}>
      {Icon && <Icon className="h-3.5 w-3.5" />} {children}
    </span>
  );
}

export function PageHeader({ chip, chipIcon, chipTone, title, subtitle, actions }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
      <div>
        {chip && <Chip icon={chipIcon} tone={chipTone}>{chip}</Chip>}
        <h1 className="mt-3 font-heading text-3xl sm:text-4xl font-bold">{title}</h1>
        {subtitle && <p className="mt-2 text-muted-foreground max-w-xl">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Page({ children, narrow }) {
  return <div className={`mx-auto ${narrow ? "max-w-3xl" : "max-w-6xl"} px-4 sm:px-6 py-6 sm:py-8`}>{children}</div>;
}

export function Card({ className = "", children }) {
  return <div className={`rounded-2xl border border-border bg-card shadow-card ${className}`}>{children}</div>;
}

export function EmptyState({ icon: Icon, title, text, action }) {
  return (
    <div className="mt-8 rounded-3xl border border-dashed border-border bg-secondary/40 p-10 sm:p-14 text-center">
      {Icon && (
        <span className="inline-flex h-16 w-16 items-center justify-center rounded-2xl gradient-novatrax-soft">
          <Icon className="h-8 w-8 text-primary/60" />
        </span>
      )}
      <h3 className="mt-5 font-heading text-xl font-bold">{title}</h3>
      {text && <p className="mt-2 text-muted-foreground max-w-md mx-auto">{text}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Skeleton({ className = "" }) {
  return <div className={`rounded-2xl bg-muted/70 animate-pulse ${className}`} />;
}

export function Modal({ title, onClose, children, footer, wide }) {
  useEffect(() => {
    const on = (e) => e.key === "Escape" && onClose?.();
    window.addEventListener("keydown", on);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", on);
      document.body.style.overflow = prev;
    };
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-foreground/40 p-0 sm:p-4 animate-fade" onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}>
      <div className={`w-full ${wide ? "sm:max-w-3xl" : "sm:max-w-lg"} max-h-[92vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-card shadow-card-hover`}>
        <div className="flex items-center justify-between gap-4 border-b border-border px-5 py-4">
          <h2 className="font-heading text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="inline-flex h-9 w-9 items-center justify-center rounded-xl hover:bg-muted" aria-label="Fermer">
            <LuX className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-5">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-border px-5 py-4">{footer}</div>}
      </div>
    </div>
  );
}

// Boîte de dialogue de confirmation, avec motif facultatif ou obligatoire.
export function ConfirmModal({ title, text, confirmLabel = "Confirmer", variant = "primary", reason, reasonLabel = "Motif", reasonRequired, onConfirm, onClose }) {
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async () => {
    if (reason && reasonRequired && !value.trim()) return setError("Ce champ est obligatoire.");
    setBusy(true);
    setError("");
    try {
      await onConfirm(value.trim());
      onClose();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button variant={variant} loading={busy} onClick={submit}>{confirmLabel}</Button>
        </>
      }
    >
      {text && <p className="text-sm text-muted-foreground whitespace-pre-line">{text}</p>}
      {reason && (
        <Field label={reasonLabel} className="mt-4">
          <textarea className="field min-h-24" value={value} onChange={(e) => setValue(e.target.value)} autoFocus />
        </Field>
      )}
      {error && <Alert className="mt-4">{error}</Alert>}
    </Modal>
  );
}

// Sélecteur d'image : téléversement vers le serveur ou lien externe.
export function ImageInput({ label, value, onChange, hint }) {
  const ref = useRef(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const pick = async (file) => {
    if (!file) return;
    setBusy(true);
    try {
      onChange(await uploadImage(file));
    } catch (e) {
      toast({ title: "Téléversement impossible", description: errMsg(e), variant: "destructive" });
    } finally {
      setBusy(false);
      if (ref.current) ref.current.value = "";
    }
  };
  return (
    <Field label={label} hint={hint}>
      <div className="flex items-center gap-3">
        <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl border border-border bg-muted flex items-center justify-center">
          {value ? <img src={value} alt="" className="h-full w-full object-cover" /> : <LuImagePlus className="h-6 w-6 text-muted-foreground" />}
        </div>
        <div className="flex flex-1 flex-wrap gap-2">
          <Button type="button" variant="outline" size="sm" loading={busy} icon={LuImagePlus} onClick={() => ref.current?.click()}>
            {value ? "Remplacer" : "Choisir une image"}
          </Button>
          {value && (
            <Button type="button" variant="danger" size="sm" icon={LuTrash2} onClick={() => onChange("")}>Retirer</Button>
          )}
          <input ref={ref} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
        </div>
      </div>
    </Field>
  );
}

// Chargement de données avec état (chargement, erreur, rechargement).
export function useLoad(fn, deps = []) {
  const [state, setState] = useState({ loading: true, data: null, error: null });
  const reload = useCallback(async (silent) => {
    if (!silent) setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await fn();
      setState({ loading: false, data, error: null });
      return data;
    } catch (e) {
      setState((s) => ({ ...s, loading: false, error: errMsg(e) }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => {
    reload();
  }, [reload]);
  return { ...state, reload, setData: (d) => setState((s) => ({ ...s, data: typeof d === "function" ? d(s.data) : d })) };
}

export function ErrorBox({ message, onRetry }) {
  return (
    <div className="mt-6 rounded-2xl border border-destructive/30 bg-destructive/5 p-6 text-center">
      <p className="text-sm text-destructive">{message}</p>
      {onRetry && <Button className="mt-3" onClick={() => onRetry()}>Réessayer</Button>}
    </div>
  );
}
