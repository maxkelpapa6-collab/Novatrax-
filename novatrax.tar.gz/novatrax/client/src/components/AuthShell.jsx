import { useState } from "react";
import { LuEye, LuEyeOff } from "react-icons/lu";
import Logo from "./Logo";

export function safeReturnTo() {
  const v = new URLSearchParams(window.location.search).get("returnTo") || "/";
  return v.startsWith("/") && !v.startsWith("//") ? v : "/";
}

export default function AuthShell({ title, subtitle, children }) {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-5 py-10">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-6">
          <Logo size="lg" violet />
        </div>
        {title && <h1 className="text-center text-xl font-bold text-foreground mb-2">{title}</h1>}
        {subtitle && <p className="text-center text-sm text-muted-foreground mb-8">{subtitle}</p>}
        {children}
      </div>
    </div>
  );
}

export function PasswordInput({ value, onChange, autoComplete = "current-password", placeholder = "••••••••", id }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <input
        id={id}
        type={show ? "text" : "password"}
        autoComplete={autoComplete}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="field h-12 pr-11"
        required
      />
      <button
        type="button"
        onClick={() => setShow((v) => !v)}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
        aria-label={show ? "Masquer le mot de passe" : "Afficher le mot de passe"}
      >
        {show ? <LuEyeOff className="w-4 h-4" /> : <LuEye className="w-4 h-4" />}
      </button>
    </div>
  );
}

export function OtpInput({ value, onChange, autoFocus = true }) {
  return (
    <input
      inputMode="numeric"
      autoComplete="one-time-code"
      autoFocus={autoFocus}
      maxLength={6}
      value={value}
      onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, 6))}
      placeholder="••••••"
      aria-label="Code à 6 chiffres"
      className="field h-14 text-center font-heading text-2xl font-bold tracking-[0.6em]"
    />
  );
}
