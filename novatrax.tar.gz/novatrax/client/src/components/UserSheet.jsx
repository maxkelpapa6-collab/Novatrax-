// Fiche membre (administration) : informations, réseau, Marketplace, historique et actions.
import { useState } from "react";
import { LuBan, LuCircleCheck, LuMailCheck, LuShieldCheck, LuShieldOff, LuStore, LuLogOut, LuSend } from "react-icons/lu";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { getCountry, formatDate, formatDateTime, formatFcfa, fullName, errMsg } from "../lib/format";
import { useToast } from "../lib/toast";
import { Modal, Button, Badge, Skeleton, Alert, ConfirmModal, Field, useLoad } from "./ui";
import { ORDER_STATUS, PRODUCT_STATUS } from "./marketplace";

const TABS = [["info", "Informations"], ["team", "Réseau"], ["market", "Marketplace"], ["history", "Historique"]];

function Row({ label, children }) {
  return (
    <div className="flex justify-between gap-4 py-2 border-b border-border last:border-0 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-right break-all">{children || "—"}</span>
    </div>
  );
}

export default function UserSheet({ userId, onClose, onChanged }) {
  const { user: me } = useAuth();
  const toast = useToast();
  const { data, loading, error, reload } = useLoad(() => api.get(`/api/admin/users/${userId}`), [userId]);
  const [tab, setTab] = useState("info");
  const [confirm, setConfirm] = useState(null);
  const [msg, setMsg] = useState(null);

  const act = (action, reason) => api.post(`/api/admin/users/${userId}/moderate`, { action, reason }).then(() => { reload(true); onChanged?.(); });
  const ban = (banned, reason) => api.post(`/api/admin/users/${userId}/marketplace-ban`, { banned, reason }).then(() => { reload(true); onChanged?.(); });

  const u = data?.user;
  const c = getCountry(u?.country);
  const suspended = u?.account_status === "suspended";

  const sendMessage = async () => {
    try {
      await api.post("/api/admin/messages", { subject: msg.subject, body: msg.body, audience: { type: "user", user_id: userId }, channels: { inbox: true, email: msg.email } });
      toast({ title: "Message envoyé" });
      setMsg(null);
    } catch (e) {
      toast({ title: "Envoi impossible", description: errMsg(e), variant: "destructive" });
    }
  };

  return (
    <Modal title="Fiche membre" onClose={onClose} wide>
      {error ? <Alert>{error}</Alert> : loading || !u ? <Skeleton className="h-64" /> : (
        <>
          <div className="flex items-center gap-4">
            <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl gradient-novatrax text-xl font-bold text-white">{(u.first_name?.[0] || u.email[0]).toUpperCase()}</span>
            <div className="min-w-0">
              <p className="font-heading text-lg font-bold truncate">{fullName(u)}</p>
              <p className="text-sm text-muted-foreground truncate">@{u.username} · {u.email}</p>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {suspended ? <Badge className="bg-destructive/10 text-destructive">Suspendu</Badge> : <Badge className="bg-emerald-500/10 text-emerald-700">Actif</Badge>}
                {u.role === "admin" && <Badge className="bg-primary/10 text-primary">Admin</Badge>}
                {!u.email_verified && <Badge className="bg-amber-500/10 text-amber-700">E-mail non vérifié</Badge>}
                {u.marketplace_banned && <Badge className="bg-destructive/10 text-destructive">Vendeur suspendu</Badge>}
              </div>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            {suspended
              ? <Button size="sm" variant="success" icon={LuCircleCheck} onClick={() => setConfirm({ title: "Débloquer le compte", action: () => act("unblock") })}>Débloquer</Button>
              : u.id !== me.id && <Button size="sm" variant="danger" icon={LuBan} onClick={() => setConfirm({ title: "Bloquer le compte", text: "Le membre sera déconnecté et ne pourra plus utiliser la plateforme. Ses données sont conservées.", reason: true, variant: "danger", action: (r) => act("block", r) })}>Bloquer</Button>}
            {!u.email_verified && <Button size="sm" variant="outline" icon={LuMailCheck} onClick={() => setConfirm({ title: "Vérifier l'e-mail manuellement", reason: true, reasonRequired: false, action: (r) => act("verify_email", r) })}>Vérifier l'e-mail</Button>}
            {u.role === "admin"
              ? u.id !== me.id && <Button size="sm" variant="outline" icon={LuShieldOff} onClick={() => setConfirm({ title: "Retirer les droits administrateur", action: () => act("remove_admin") })}>Retirer admin</Button>
              : <Button size="sm" variant="outline" icon={LuShieldCheck} onClick={() => setConfirm({ title: "Nommer administrateur", text: "Ce membre aura accès à tout l'espace d'administration.", action: () => act("make_admin") })}>Nommer admin</Button>}
            {u.marketplace_banned
              ? <Button size="sm" variant="success" icon={LuStore} onClick={() => setConfirm({ title: "Rétablir l'accès vendeur", action: () => ban(false) })}>Rétablir vendeur</Button>
              : <Button size="sm" variant="outline" icon={LuStore} onClick={() => setConfirm({ title: "Suspendre l'accès vendeur", text: "Ses annonces publiées seront masquées.", reason: true, variant: "danger", action: (r) => ban(true, r) })}>Suspendre vendeur</Button>}
            <Button size="sm" variant="outline" icon={LuLogOut} onClick={() => setConfirm({ title: "Déconnecter le membre", text: "Toutes les sessions du membre seront fermées.", action: () => act("logout") })}>Forcer la déconnexion</Button>
            <Button size="sm" variant="outline" icon={LuSend} onClick={() => setMsg({ subject: "", body: "", email: false })}>Envoyer un message</Button>
          </div>

          <div className="mt-5 flex gap-1 overflow-x-auto no-scrollbar rounded-xl bg-secondary p-1">
            {TABS.map(([id, l]) => (
              <button key={id} onClick={() => setTab(id)} className={`whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-semibold ${tab === id ? "bg-card shadow-card" : "text-muted-foreground"}`}>{l}</button>
            ))}
          </div>

          <div className="mt-4">
            {tab === "info" && (
              <div>
                <Row label="Téléphone">{u.phone}</Row>
                <Row label="Pays">{c ? `${c.flag} ${c.name}` : null}</Row>
                <Row label="Inscription">{formatDateTime(u.created_date)}</Row>
                <Row label="Dernière connexion">{formatDateTime(u.last_login_at)}</Row>
                <Row label="Code d'invitation">{u.referral_code}</Row>
                <Row label="Invité par">{data.sponsor ? `${fullName(data.sponsor)} (${data.sponsor.email})` : null}</Row>
                <Row label="Partage des coordonnées">{u.share_contacts ? "Accepté" : "Refusé"}</Row>
                <Row label="E-mails d'annonces">{u.unsubscribed ? "Désabonné" : "Abonné"}</Row>
                {suspended && <Row label="Motif du blocage">{u.blocked_reason} — {u.blocked_by}, {formatDate(u.blocked_at)}</Row>}
                {u.marketplace_banned && <Row label="Motif suspension vendeur">{u.marketplace_banned_reason}</Row>}
              </div>
            )}
            {tab === "team" && (
              <div>
                <p className="text-sm text-muted-foreground">{data.referrals_total} membre(s) invité(s)</p>
                <ul className="mt-2 divide-y divide-border">
                  {data.referrals.map((r) => (
                    <li key={r.id} className="flex justify-between gap-3 py-2 text-sm">
                      <span className="truncate"><span className="font-semibold">{fullName(r)}</span> <span className="text-muted-foreground">{r.email}</span></span>
                      <span className="shrink-0 text-muted-foreground">{formatDate(r.created_date)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {tab === "market" && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold">Annonces ({data.products.length})</h3>
                  <ul className="mt-2 divide-y divide-border">
                    {data.products.map((p) => (
                      <li key={p.id} className="flex justify-between gap-3 py-2 text-sm">
                        <span className="truncate">{p.name} · {formatFcfa(p.price_fcfa)}</span>
                        <Badge className={PRODUCT_STATUS[p.status]?.[1]}>{PRODUCT_STATUS[p.status]?.[0]}</Badge>
                      </li>
                    ))}
                    {!data.products.length && <li className="py-2 text-sm text-muted-foreground">Aucune annonce.</li>}
                  </ul>
                </div>
                <div>
                  <h3 className="text-sm font-semibold">Commandes ({data.orders.length})</h3>
                  <ul className="mt-2 divide-y divide-border">
                    {data.orders.map((o) => (
                      <li key={o.id} className="flex justify-between gap-3 py-2 text-sm">
                        <span className="truncate">{o.order_ref} · {o.product_name} · {o.buyer_id === u.id ? "achat" : "vente"}</span>
                        <Badge className={ORDER_STATUS[o.status]?.[1]}>{ORDER_STATUS[o.status]?.[0]}</Badge>
                      </li>
                    ))}
                    {!data.orders.length && <li className="py-2 text-sm text-muted-foreground">Aucune commande.</li>}
                  </ul>
                </div>
              </div>
            )}
            {tab === "history" && (
              <ul className="divide-y divide-border">
                {data.history.map((h) => (
                  <li key={h.id} className="py-2 text-sm">
                    <p className="font-semibold">{h.action}</p>
                    <p className="text-xs text-muted-foreground">{h.admin_email} · {formatDateTime(h.created_date)}{h.reason ? " · " + h.reason : ""}</p>
                  </li>
                ))}
                {!data.history.length && <li className="py-2 text-sm text-muted-foreground">Aucune action enregistrée.</li>}
              </ul>
            )}
          </div>
        </>
      )}
      {confirm && (
        <ConfirmModal
          title={confirm.title} text={confirm.text} variant={confirm.variant || "primary"}
          reason={confirm.reason} reasonRequired={confirm.reasonRequired !== false}
          onConfirm={confirm.action} onClose={() => setConfirm(null)}
        />
      )}
      {msg && (
        <Modal title="Message au membre" onClose={() => setMsg(null)} footer={<><Button variant="outline" onClick={() => setMsg(null)}>Annuler</Button><Button icon={LuSend} onClick={sendMessage}>Envoyer</Button></>}>
          <div className="space-y-4">
            <Field label="Objet"><input className="field" value={msg.subject} onChange={(e) => setMsg({ ...msg, subject: e.target.value })} /></Field>
            <Field label="Message"><textarea className="field min-h-32" value={msg.body} onChange={(e) => setMsg({ ...msg, body: e.target.value })} /></Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="h-4 w-4 accent-violet" checked={msg.email} onChange={(e) => setMsg({ ...msg, email: e.target.checked })} /> Envoyer aussi par e-mail</label>
          </div>
        </Modal>
      )}
    </Modal>
  );
}
