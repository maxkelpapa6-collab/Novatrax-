// Éléments partagés de la Marketplace : statuts, carte produit, formulaire d'annonce.
import { useState } from "react";
import { LuShoppingBag, LuTriangleAlert } from "react-icons/lu";
import { Link } from "../lib/router";
import { api } from "../lib/api";
import { formatFcfa, errMsg } from "../lib/format";
import { Badge, Modal, Button, Field, ImageInput, Alert, useLoad } from "./ui";

export const ORDER_STATUS = {
  awaiting_payment: ["En attente de paiement", "bg-amber-500/10 text-amber-700"],
  processing: ["Paiement confirmé — en cours", "bg-primary/10 text-primary"],
  completed: ["Terminée", "bg-emerald-500/10 text-emerald-700"],
  cancelled: ["Annulée", "bg-muted text-muted-foreground"],
  refunded: ["Remboursée", "bg-violet/10 text-violet"],
  disputed: ["En litige", "bg-destructive/10 text-destructive"],
};

export const PRODUCT_STATUS = {
  pending: ["En validation", "bg-amber-500/10 text-amber-700"],
  published: ["Publiée", "bg-emerald-500/10 text-emerald-700"],
  rejected: ["Refusée", "bg-destructive/10 text-destructive"],
  blocked: ["Bloquée", "bg-destructive/10 text-destructive"],
  hidden: ["Masquée", "bg-muted text-muted-foreground"],
};

export const OrderBadge = ({ status }) => <Badge className={ORDER_STATUS[status]?.[1]}>{ORDER_STATUS[status]?.[0] || status}</Badge>;
export const ProductBadge = ({ status }) => <Badge className={PRODUCT_STATUS[status]?.[1]}>{PRODUCT_STATUS[status]?.[0] || status}</Badge>;

export function ProductCard({ product: p, to }) {
  return (
    <Link to={to} className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card hover:shadow-card-hover transition-all">
      <div className="aspect-square overflow-hidden bg-muted">
        {p.image_url ? (
          <img src={p.image_url} alt={p.name} loading="lazy" className="h-full w-full object-cover transition-transform group-hover:scale-105" />
        ) : (
          <div className="flex h-full items-center justify-center"><LuShoppingBag className="h-10 w-10 text-muted-foreground" /></div>
        )}
      </div>
      <div className="flex flex-1 flex-col p-3">
        {p.category && <p className="text-[11px] font-semibold uppercase tracking-wide text-violet">{p.category}</p>}
        <h3 className="mt-0.5 line-clamp-2 text-sm font-semibold">{p.name}</h3>
        <p className="mt-auto pt-2 font-heading text-base font-bold">{formatFcfa(p.price_fcfa)}</p>
        {p.seller_name && <p className="truncate text-xs text-muted-foreground">{p.seller_name}</p>}
      </div>
    </Link>
  );
}

export function ProductForm({ product, defaultPhone, onClose, onSaved }) {
  const cats = useLoad(() => api.get("/api/marketplace/categories").then((r) => r.items));
  const cfg = useLoad(() => api.get("/api/marketplace/config"));
  const [f, setF] = useState({
    name: product?.name || "", description: product?.description || "", image_url: product?.image_url || "",
    price_fcfa: product?.price_fcfa || "", category: product?.category || "", seller_phone: product?.seller_phone || defaultPhone || "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [blocked, setBlocked] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const rate = cfg.data?.commission_rate ?? 0;
  const price = Math.round(Number(f.price_fcfa)) || 0;

  const save = async () => {
    setBusy(true);
    setError("");
    try {
      const body = { ...f, price_fcfa: price };
      const r = product ? await api.patch(`/api/marketplace/my-products/${product.id}`, body) : await api.post("/api/marketplace/my-products", body);
      if (r.blocked) setBlocked(r);
      else onSaved(r);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  if (blocked) {
    return (
      <Modal title="Annonce bloquée automatiquement" onClose={() => onSaved(blocked)} footer={<Button onClick={() => onSaved(blocked)}>Compris</Button>}>
        <div className="flex gap-3">
          <LuTriangleAlert className="h-6 w-6 shrink-0 text-destructive" />
          <div className="text-sm">
            <p>{blocked.reason}</p>
            {blocked.suspended && <p className="mt-3 font-semibold text-destructive">Suite à des infractions répétées, votre accès vendeur est suspendu. Contactez le support pour un réexamen.</p>}
          </div>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title={product ? "Modifier l'annonce" : "Nouvelle annonce"} onClose={onClose}
      footer={<><Button variant="outline" onClick={onClose}>Annuler</Button><Button loading={busy} onClick={save}>{product ? "Renvoyer en validation" : "Soumettre l'annonce"}</Button></>}>
      <div className="space-y-4">
        <ImageInput label="Photo du produit *" value={f.image_url} onChange={(v) => setF({ ...f, image_url: v })} />
        <Field label="Nom du produit *"><input className="field" value={f.name} onChange={set("name")} maxLength={100} /></Field>
        <Field label="Description" hint={`${f.description.length}/${cfg.data?.max_description || 500} caractères — aucun lien externe autorisé.`}>
          <textarea className="field min-h-24" value={f.description} onChange={set("description")} maxLength={cfg.data?.max_description || 500} />
        </Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Prix (FCFA) *"><input className="field" inputMode="numeric" value={f.price_fcfa} onChange={(e) => setF({ ...f, price_fcfa: e.target.value.replace(/\D/g, "") })} /></Field>
          <Field label="Catégorie *">
            <select className="field" value={f.category} onChange={set("category")}>
              <option value="">Choisir…</option>
              {cats.data?.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
          </Field>
        </div>
        <Field label="Téléphone de contact *" hint="Seul canal de contact autorisé : il est affiché aux acheteurs."><input className="field" value={f.seller_phone} onChange={set("seller_phone")} /></Field>
        {price > 0 && rate > 0 && (
          <p className="rounded-xl bg-secondary px-4 py-3 text-sm text-muted-foreground">
            Commission NOVATRAX ({Math.round(rate * 100)} %) : {formatFcfa(Math.round(price * rate))} · Net vendeur : <span className="font-semibold text-foreground">{formatFcfa(price - Math.round(price * rate))}</span>
          </p>
        )}
        <p className="text-xs text-muted-foreground">Votre annonce sera publiée après validation par l'administration. Les produits interdits, contrefaits ou illégaux sont refusés.</p>
        {error && <Alert>{error}</Alert>}
      </div>
    </Modal>
  );
}

// Ligne de commande avec coordonnées de l'autre partie et actions disponibles.
export function OrderItem({ order: o, role, onAction }) {
  const other = role === "buyer"
    ? { label: "Vendeur", name: o.seller_name, phone: o.seller_phone }
    : { label: "Acheteur", name: o.buyer_name, phone: o.buyer_phone };
  const wa = other.phone?.replace(/\D/g, "");
  const actions = [];
  if (role === "seller" && o.status === "awaiting_payment") actions.push(["confirm_payment", "Paiement reçu", "success"]);
  if (role === "buyer" && o.status === "processing") actions.push(["confirm_receipt", "J'ai reçu le produit", "success"]);
  if (o.status === "awaiting_payment") actions.push(["cancel", "Annuler", "outline"]);
  if (role === "buyer" && ["awaiting_payment", "processing"].includes(o.status)) actions.push(["dispute", "Signaler un problème", "danger"]);
  return (
    <li className="p-4 sm:p-5">
      <div className="flex gap-3">
        <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-muted">{o.product_image && <img src={o.product_image} alt="" className="h-full w-full object-cover" />}</div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-semibold truncate">{o.product_name}</p>
            <OrderBadge status={o.status} />
          </div>
          <p className="text-sm text-muted-foreground">{o.order_ref} · {new Date(o.created_date).toLocaleDateString("fr-FR")} · <span className="font-semibold text-foreground">{formatFcfa(o.product_price_fcfa)}</span></p>
          {role === "seller" && o.commission_fcfa > 0 && <p className="text-xs text-muted-foreground">Commission {formatFcfa(o.commission_fcfa)} · net {formatFcfa(o.net_fcfa)}</p>}
          <p className="mt-1 text-sm">
            {other.label} : <span className="font-medium">{other.name}</span>
            {other.phone && <> · <a href={`tel:${other.phone}`} className="text-primary hover:underline">{other.phone}</a></>}
            {wa && <> · <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer" className="text-emerald-700 hover:underline">WhatsApp</a></>}
          </p>
          {o.buyer_note && <p className="mt-1 text-sm text-muted-foreground">Message : « {o.buyer_note} »</p>}
          {o.dispute_reason && <p className="mt-1 text-sm text-destructive">Litige : {o.dispute_reason}</p>}
          {o.resolution_note && <p className="mt-1 text-sm text-muted-foreground">Note : {o.resolution_note}</p>}
          {actions.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {actions.map(([a, l, v]) => <Button key={a} size="sm" variant={v} onClick={() => onAction(o, a)}>{l}</Button>)}
            </div>
          )}
        </div>
      </div>
    </li>
  );
}
