import { useEffect } from "react";
import { RouterProvider, useLocation, matchPath, Navigate } from "./lib/router";
import { AuthProvider, useAuth } from "./lib/auth";
import { ToastProvider } from "./lib/toast";
import AppLayout from "./components/AppLayout";
import { Spinner } from "./components/ui";
import Login from "./pages/Login";
import Register from "./pages/Register";
import VerifyEmail from "./pages/VerifyEmail";
import ForgotPassword from "./pages/ForgotPassword";
import { Terms, Privacy } from "./pages/Legal";
import Home from "./pages/Home";
import MyNetwork from "./pages/MyNetwork";
import Profile from "./pages/Profile";
import Formation from "./pages/Formation";
import ApkPro from "./pages/ApkPro";
import Marketplace from "./pages/Marketplace";
import ProductDetail from "./pages/ProductDetail";
import MyShop from "./pages/MyShop";
import MyPurchases from "./pages/MyPurchases";
import Contact from "./pages/Contact";
import Inbox from "./pages/Inbox";
import Admin from "./pages/Admin";
import NotFound from "./pages/NotFound";

const PUBLIC = [
  ["/login", Login],
  ["/register", Register],
  ["/verifier", VerifyEmail],
  ["/forgot-password", ForgotPassword],
  ["/terms", Terms],
  ["/privacy", Privacy],
];

const PRIVATE = [
  ["/", Home],
  ["/reseau", MyNetwork],
  ["/profile", Profile],
  ["/formation", Formation],
  ["/apk-pro", ApkPro],
  ["/marketplace", Marketplace],
  ["/marketplace/produit/:id", ProductDetail],
  ["/ma-boutique", MyShop],
  ["/mes-achats", MyPurchases],
  ["/contact", Contact],
  ["/boite-reception", Inbox],
  ["/admin", Admin],
];

function Routes() {
  const { pathname } = useLocation();
  const { user, loading } = useAuth();

  useEffect(() => {
    document.title = "NOVATRAX";
  }, [pathname]);

  for (const [p, C] of PUBLIC) {
    if (matchPath(p, pathname)) {
      if (user && ["/login", "/register", "/verifier"].includes(p) && !loading) return <Navigate to="/" />;
      return <C />;
    }
  }

  for (const [p, C] of PRIVATE) {
    const params = matchPath(p, pathname);
    if (params) {
      if (loading) {
        return (
          <div className="fixed inset-0 flex items-center justify-center">
            <Spinner className="h-8 w-8 text-primary" />
          </div>
        );
      }
      if (!user) return <Navigate to={"/login?returnTo=" + encodeURIComponent(pathname + window.location.search)} />;
      return (
        <AppLayout>
          <C params={params} />
        </AppLayout>
      );
    }
  }
  return <NotFound />;
}

export default function App() {
  return (
    <RouterProvider>
      <ToastProvider>
        <AuthProvider>
          <Routes />
        </AuthProvider>
      </ToastProvider>
    </RouterProvider>
  );
}
