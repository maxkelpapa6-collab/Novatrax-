import { useState } from "react";
import { LuStore, LuPlus, LuPencil, LuTrash2, LuEye, LuEyeOff, LuTriangleAlert, LuShoppingBag } from "react-icons/lu";
import { Link } from "../lib/router";
import { api, qs } from "../lib/api";
import { useAuth } from "../lib/auth";
import { formatFcfa, errMsg } from "../lib/format";
import { useToast } from "../lib/toast";
import { Page, PageHeader, Card, Button, Skeleton, Alert, ConfirmModal, useLoad } from "../components/ui";
import { ProductForm, ProductBadge, OrderItem } from "../components/marketplace";

const CONFIRM = {
  confirm_payment: { title: "Confirmer la réception du paiement", text: "Confirmez uniquement si vous avez bien reçu le paiement de l'acheteur. Préparez ensuite la livraison.", label: "Paiement reçu" },
  cancel: { title: "Annuler la commande", text: "L'acheteur sera prévenu de l'annulation.", label: "Annuler la commande", variant: "danger", reason: true, reasonRequired: false },
};

export default function MyShop() {
  const { user } = useAuth();
  const toast = useToast();
  const [tab, setTab] = useState("products");
  const [form, setForm] = useState(undefined);
  const [confirm, setConfirm] = useState(null);
  const summary = useLoad(() => api.get("/api/marketplace/seller-summary"));
  const products = useLoad(() => api.get("/api/marketplace/my-products").then((r) => r.items));
  const sales = useLoad(() => api.get("/api/marketplace/orders" + qs({ role: "seller" })).then((r) => r.items));
  const s = summary.data;

  const refresh = () => { summary.reload(true); products.reload(true); sales.reload(true); };

  const visibility = async (p, v) => {
    try {
      await api.patch(`/api/marketplace/my-products/${p.id}`, { visibility: v });
      products.reload(true);
    } catch (e) {
      toast({ title: "Action impossible", description: errMsg(e), variant: "destructive" });
    }
  };

  const tiles = [
    ["Ventes terminées", s?.completed ?? "…"],
    ["Chiffre d'affaires", s ? formatFcfa(s.gross) : "…"],
    ["Commandes en cours", s?.pending_orders ?? "…"],
    ...(s?.commission_rate > 0 ? [["Net vendeur (après commission)", formatFcfa(s.net)]] : [["Annonces", products.data?.length ?? "…"]]),
  ];

  return (
    <Page>
      <PageHeader chip="Mon espace vendeur" chipIcon={LuStore} chipTone="violet" title="Ma boutique"
        subtitle="Publiez vos annonces, suivez vos ventes et confirmez les paiements reçus."
        actions={!s?.banned && <Button icon={LuPlus} onClick={() => setForm(null)}>Nouvelle annonce</Button>} />
      {s?.banned && (
        <Alert className="mt-5"><LuTriangleAlert className="inline h-4 w-4 mr-1" /> Votre accès vendeur est suspendu{s.banned_reason ? ` : ${s.banned_reason}` : "."} Contactez le support pour un réexamen.</Alert>
      )}
      <div className="mt-6 grid gap-3 grid-cols-2 lg:grid-cols-4">
        {tiles.map(([l, v]) => <Card key={l} className="p-4"><p className="font-heading text-xl font-bold">{v}</p><p className="text-sm text-muted-foreground">{l}</p></Card>)}
      </div>
      <div className="mt-6 inline-flex gap-1 rounded-2xl border border-border bg-card p-1.5 shadow-card">
        {[["products", "Mes annonces"], ["sales", "Mes ventes"]].map(([id, l]) => (
          <button key={id} onClick={() => setTab(id)} className={`rounded-xl px-4 py-2 text-sm font-semibold ${tab === id ? "gradient-novatrax text-white" : "text-muted-foreground hover:bg-muted"}`}>
            {l}{id === "sales" && s?.pending_orders ? ` (${s.pending_orders})` : ""}
          </button>
        ))}
      </div>

      {tab === "products" && (
        products.loading ? <Skeleton className="mt-4 h-40" /> : !products.data?.length ? (
          <Card className="mt-4 p-10 text-center">
            <LuShoppingBag className="mx-auto h-10 w-10 text-muted-foreground" />
            <p className="mt-3 font-semibold">Vous n'avez publié aucune annonce.</p>
            <p className="mt-1 text-sm text-muted-foreground">Vendez vos produits aux membres NOVATRAX : chaque annonce est vérifiée avant publication.</p>
          </Card>
        ) : (
          <Card className="mt-4 overflow-hidden">
            <ul className="divide-y divide-border">
              {products.data.map((p) => (
                <li key={p.id} className="flex flex-col sm:flex-row sm:items-center gap-3 p-4">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-muted">{p.image_url && <img src={p.image_url} alt="" className="h-full w-full object-cover" />}</div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        {p.status === "published" ? <Link to={`/marketplace/produit/${p.id}`} className="font-semibold truncate hover:underline">{p.name}</Link> : <p className="font-semibold truncate">{p.name}</p>}
                        <ProductBadge status={p.status} />
                      </div>
                      <p className="text-sm text-muted-foreground">{formatFcfa(p.price_fcfa)} · {p.category}</p>
                      {(p.rejection_reason || p.blocked_reason) && <p className="text-xs text-destructive">{p.rejection_reason || p.blocked_reason}</p>}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {p.status === "published" && <Button size="sm" variant="outline" icon={LuEyeOff} onClick={() => visibility(p, "hidden")}>Masquer</Button>}
                    {p.status === "hidden" && !s?.banned && <Button size="sm" variant="outline" icon={LuEye} onClick={() => visibility(p, "visible")}>Réafficher</Button>}
                    {!s?.banned && <Button size="sm" variant="outline" icon={LuPencil} onClick={() => setForm(p)}>Modifier</Button>}
                    <Button size="sm" variant="danger" icon={LuTrash2} onClick={() => setConfirm({ title: "Supprimer l'annonce", text: `Supprimer « ${p.name} » ?`, label: "Supprimer", variant: "danger", run: () => api.del(`/api/marketplace/my-products/${p.id}`) })}>Supprimer</Button>
                  </div>
                </li>
              ))}
            </ul>
          </Card>
        )
      )}

      {tab === "sales" && (
        sales.loading ? <Skeleton className="mt-4 h-40" /> : !sales.data?.length ? (
          <Card className="mt-4 p-10 text-center text-sm text-muted-foreground">Aucune vente pour le moment.</Card>
        ) : (
          <Card className="mt-4 overflow-hidden">
            <ul className="divide-y divide-border">
              {sales.data.map((o) => (
                <OrderItem key={o.id} order={o} role="seller" onAction={(order, action) => setConfirm({ ...CONFIRM[action], run: (reason) => api.post(`/api/marketplace/orders/${order.id}/action`, { action, reason }) })} />
              ))}
            </ul>
          </Card>
        )
      )}

      {form !== undefined && (
        <ProductForm product={form} defaultPhone={user?.phone} onClose={() => setForm(undefined)}
          onSaved={(r) => {
            setForm(undefined);
            if (!r?.blocked) toast({ title: "Annonce envoyée", description: "Elle sera publiée après validation par l'administration." });
            refresh();
          }} />
      )}
      {confirm && (
        <ConfirmModal title={confirm.title} text={confirm.text} confirmLabel={confirm.label} variant={confirm.variant}
          reason={confirm.reason} reasonRequired={confirm.reasonRequired}
          onConfirm={async (r) => { await confirm.run(r); refresh(); }} onClose={() => setConfirm(null)} />
      )}
    </Page>
  );
}
