import { useCallback, useEffect, useRef, useState } from "react";
import { LuSearch, LuDownload, LuPhone, LuMessageCircle, LuCalendarDays, LuMail, LuLock, LuFileSpreadsheet, LuContact } from "react-icons/lu";
import { Link } from "../lib/router";
import { api, qs, downloadProtected } from "../lib/api";
import { useAuth } from "../lib/auth";
import { getCountry, COUNTRIES, formatDate, errMsg, fullName } from "../lib/format";
import { useToast } from "../lib/toast";
import { Page, Card, Button, Skeleton, Alert, Badge, useLoad } from "../components/ui";
import UserSheet from "../components/UserSheet";

const RANGES = [
  { value: "all", label: "Tous" },
  { value: "today", label: "Aujourd'hui" },
  { value: "yesterday", label: "Hier" },
  { value: "week", label: "Cette semaine" },
  { value: "month", label: "Ce mois" },
  { value: "custom", label: "Période" },
];

function RangePicker({ range, setRange, from, setFrom, to, setTo }) {
  return (
    <>
      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        {RANGES.map((r) => (
          <button key={r.value} onClick={() => setRange(r.value)}
            className={`whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors ${range === r.value ? "gradient-novatrax text-white shadow-card" : "border border-border bg-card hover:bg-muted"}`}>
            {r.label}
          </button>
        ))}
      </div>
      {range === "custom" && (
        <div className="mt-3 grid grid-cols-2 gap-3 max-w-md">
          <label className="text-xs font-medium text-muted-foreground">Inscrits depuis<input type="date" className="field mt-1" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
          <label className="text-xs font-medium text-muted-foreground">Jusqu'au<input type="date" className="field mt-1" value={to} onChange={(e) => setTo(e.target.value)} /></label>
        </div>
      )}
    </>
  );
}

function SupportCard() {
  const { data } = useLoad(() => api.get("/api/public/settings"));
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 pb-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
      <Card className="p-5 flex items-start gap-3">
        <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl gradient-novatrax text-white"><LuMail className="h-5 w-5" /></span>
        <div className="min-w-0">
          <p className="font-semibold">Support par e-mail</p>
          <a href={`mailto:${data?.support_email || ""}`} className="text-sm text-primary hover:underline break-all">{data?.support_email || "…"}</a>
        </div>
      </Card>
      {data?.whatsapp_channel && (
        <Card className="p-5 flex items-start gap-3">
          <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-600"><LuMessageCircle className="h-5 w-5" /></span>
          <div>
            <p className="font-semibold">Chaîne WhatsApp officielle</p>
            <a href={data.whatsapp_channel} target="_blank" rel="noopener noreferrer" className="text-sm text-emerald-700 hover:underline">Rejoindre la chaîne WhatsApp de NOVATRAX</a>
            <p className="mt-1 text-xs text-muted-foreground">Annonces officielles et assistance de l'équipe.</p>
          </div>
        </Card>
      )}
      <Card className="p-5 flex items-start gap-3 sm:col-span-2">
        <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"><LuLock className="h-5 w-5" /></span>
        <div>
          <p className="font-semibold text-sm">Vos données sont protégées</p>
          <p className="text-sm text-muted-foreground">Seuls les membres ayant accepté le partage de leurs coordonnées apparaissent dans l'annuaire, et seuls les membres qui partagent les leurs peuvent le consulter.</p>
        </div>
      </Card>
    </div>
  );
}

function MemberDirectory() {
  const { user } = useAuth();
  const toast = useToast();
  const [range, setRange] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [search, setSearch] = useState("");
  const [state, setState] = useState({ loading: true, items: [], count: 0, truncated: false, error: "" });
  const [downloading, setDownloading] = useState(false);
  const summary = useLoad(() => api.get("/api/contacts/summary"));
  const deb = useRef(null);
  const params = useCallback(() => ({ range, date_from: range === "custom" ? from : "", date_to: range === "custom" ? to : "" }), [range, from, to]);

  useEffect(() => {
    if (!user.share_contacts) return setState((s) => ({ ...s, loading: false }));
    clearTimeout(deb.current);
    deb.current = setTimeout(async () => {
      setState((s) => ({ ...s, loading: true, error: "" }));
      try {
        const r = await api.get("/api/contacts/directory" + qs({ ...params(), search: search.trim() }));
        setState({ loading: false, items: r.items, count: r.count, truncated: r.truncated, error: "" });
      } catch (e) {
        setState((s) => ({ ...s, loading: false, error: errMsg(e) }));
      }
    }, 300);
    return () => clearTimeout(deb.current);
  }, [params, search, user.share_contacts]);

  const download = async () => {
    setDownloading(true);
    try {
      await downloadProtected("/api/contacts/download" + qs({ ...params(), search: search.trim() }), "NOVATRAX_CONTACTS.vcf");
    } catch (e) {
      toast({ title: "Téléchargement impossible", description: errMsg(e), variant: "destructive" });
    } finally {
      setDownloading(false);
    }
  };

  const counts = summary.data?.counts;
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 py-6 sm:py-8">
      <h1 className="font-heading text-2xl sm:text-3xl font-bold uppercase tracking-tight">Contacts NOVATRAX</h1>
      <p className="mt-1 text-sm text-muted-foreground">Répertoire des membres ayant accepté le partage de leurs coordonnées.</p>

      {!user.share_contacts ? (
        <Card className="mt-6 p-6 text-center">
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-violet/10 text-violet"><LuContact className="h-6 w-6" /></span>
          <h2 className="mt-3 font-heading text-lg font-bold">Annuaire réservé aux membres qui partagent leurs coordonnées</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {counts ? `${counts.total} membre(s) partagent déjà leurs coordonnées. ` : ""}Activez le partage depuis votre profil pour consulter et télécharger l'annuaire.
          </p>
          <Link to="/profile" className="mt-4 inline-flex items-center rounded-xl gradient-novatrax px-5 py-2.5 text-sm font-semibold text-white">Activer le partage dans Mon profil</Link>
        </Card>
      ) : (
        <>
          <div className="relative mt-5">
            <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher un nom ou un numéro…" className="field pl-9 h-11 shadow-card" />
          </div>
          <div className="mt-4"><RangePicker {...{ range, setRange, from, setFrom, to, setTo }} /></div>
          <Card className="mt-4 p-4 grid grid-cols-3 gap-2 text-sm">
            <p className="text-muted-foreground">Disponibles<br /><span className="font-heading text-lg font-bold text-foreground">{counts?.total ?? "…"}</span></p>
            <p className="text-muted-foreground">Aujourd'hui<br /><span className="font-heading text-lg font-bold text-foreground">{counts?.today ?? "…"}</span></p>
            <p className="text-muted-foreground">Sélectionnés<br /><span className="font-heading text-lg font-bold text-foreground">{state.count}</span></p>
          </Card>
          {state.error && <Alert className="mt-4">{state.error}</Alert>}
          <Card className="mt-4 overflow-hidden">
            {state.loading ? (
              <div className="p-4 space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-14" />)}</div>
            ) : !state.items.length ? (
              <p className="p-8 text-center text-sm text-muted-foreground">Aucun contact ne correspond à cette sélection.</p>
            ) : (
              <ul className="divide-y divide-border">
                {state.items.map((m) => {
                  const c = getCountry(m.country);
                  return (
                    <li key={m.id} className="flex items-center gap-3 p-4">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl gradient-novatrax text-sm font-bold text-white">{m.name[0]?.toUpperCase()}</span>
                      <div className="flex-1 min-w-0">
                        <p className="truncate font-semibold">{m.name}</p>
                        <p className="truncate text-sm text-muted-foreground">{m.phone} {c ? `· ${c.flag}` : ""}</p>
                        <p className="mt-0.5 inline-flex items-center gap-1 text-xs text-muted-foreground"><LuCalendarDays className="h-3 w-3" /> Inscrit le {formatDate(m.created_date)}</p>
                      </div>
                      <a href={`https://wa.me/${m.phone.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20"><LuMessageCircle className="h-4 w-4" /></a>
                      <a href={`tel:${m.phone}`} aria-label="Appeler" className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary hover:bg-primary/20"><LuPhone className="h-4 w-4" /></a>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>
          {state.truncated && <p className="mt-3 text-center text-xs text-muted-foreground">Affichage limité à 50 contacts — le fichier contiendra les {state.count} contacts sélectionnés.</p>}
          <Button className="mt-4 w-full uppercase tracking-wide" size="lg" icon={LuDownload} loading={downloading} disabled={!state.count} onClick={download}>
            Télécharger {state.count} contact(s)
          </Button>
          <p className="mt-2 text-center text-xs text-muted-foreground">Fichier NOVATRAX_CONTACTS.vcf — importable sur iPhone, Android, Google Contacts et Apple Contacts.</p>
        </>
      )}
    </div>
  );
}

function AdminContacts() {
  const toast = useToast();
  const [range, setRange] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [search, setSearch] = useState("");
  const [country, setCountry] = useState("");
  const [status, setStatus] = useState("");
  const [share, setShare] = useState("");
  const [sheet, setSheet] = useState(null);
  const [debounced, setDebounced] = useState("");
  useEffect(() => { const t = setTimeout(() => setDebounced(search.trim()), 300); return () => clearTimeout(t); }, [search]);
  const p = { range, date_from: range === "custom" ? from : "", date_to: range === "custom" ? to : "" };
  const { data, loading } = useLoad(() => api.get("/api/admin/contacts" + qs({ ...p, search: debounced, country, status, share })), [range, from, to, debounced, country, status, share]);

  const exp = async (format) => {
    try {
      await downloadProtected("/api/admin/contacts/export" + qs({ ...p, format }), "NOVATRAX_CONTACTS." + format);
    } catch (e) {
      toast({ title: "Export impossible", description: errMsg(e), variant: "destructive" });
    }
  };

  return (
    <Page>
      <h1 className="font-heading text-2xl sm:text-3xl font-bold">Contacts des membres</h1>
      <p className="mt-1 text-sm text-muted-foreground">Consultez les membres inscrits, filtrez et exportez les contacts partageables (CSV / VCF). Chaque export est journalisé.</p>
      <div className="mt-5 grid gap-3 grid-cols-2 lg:grid-cols-4">
        {[["Utilisateurs inscrits", data?.counts?.total], ["Nouveaux aujourd'hui", data?.counts?.today], ["Cette semaine", data?.counts?.week], ["Contacts partageables", data?.shareable]].map(([l, v]) => (
          <Card key={l} className="p-4"><p className="font-heading text-2xl font-bold">{v ?? "…"}</p><p className="text-sm text-muted-foreground">{l}</p></Card>
        ))}
      </div>
      <div className="mt-5 space-y-3">
        <div className="relative max-w-lg">
          <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher par nom, téléphone ou e-mail…" className="field pl-9" />
        </div>
        <RangePicker {...{ range, setRange, from, setFrom, to, setTo }} />
        <div className="flex flex-wrap gap-2">
          <select className="field w-auto" value={country} onChange={(e) => setCountry(e.target.value)}>
            <option value="">Tous les pays</option>
            {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.flag} {c.name}</option>)}
          </select>
          <select className="field w-auto" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Tous les statuts</option><option value="active">Actif</option><option value="suspended">Suspendu</option>
          </select>
          <select className="field w-auto" value={share} onChange={(e) => setShare(e.target.value)}>
            <option value="">Tous les partages</option><option value="yes">Partage accepté</option><option value="no">Partage refusé</option>
          </select>
          <div className="flex gap-2 sm:ml-auto">
            <Button variant="outline" icon={LuFileSpreadsheet} onClick={() => exp("csv")}>Export CSV</Button>
            <Button icon={LuDownload} onClick={() => exp("vcf")}>Export VCF</Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">Les exports contiennent uniquement les membres actifs ayant accepté le partage, selon la période choisie.</p>
      </div>
      <Card className="mt-4 overflow-x-auto">
        {loading ? (
          <div className="p-4 space-y-2">{[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-12" />)}</div>
        ) : (
          <table className="w-full text-sm min-w-[720px]">
            <thead className="bg-secondary text-left text-xs uppercase text-muted-foreground">
              <tr>{["Membre", "Téléphone", "Pays", "Inscription", "Partage", "Statut", ""].map((h) => <th key={h} className="px-4 py-3 font-semibold">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-border">
              {data?.items?.map((u) => {
                const c = getCountry(u.country);
                return (
                  <tr key={u.id} className="hover:bg-muted/30">
                    <td className="px-4 py-3"><p className="font-semibold">{fullName(u)}</p><p className="text-xs text-muted-foreground">{u.email}</p></td>
                    <td className="px-4 py-3 whitespace-nowrap">{u.phone || "—"}</td>
                    <td className="px-4 py-3 whitespace-nowrap">{c ? `${c.flag} ${c.name}` : "—"}</td>
                    <td className="px-4 py-3 whitespace-nowrap">{formatDate(u.created_date)}</td>
                    <td className="px-4 py-3">{u.share_contacts ? <Badge className="bg-emerald-500/10 text-emerald-700">Accepté</Badge> : <Badge className="bg-muted text-muted-foreground">Refusé</Badge>}</td>
                    <td className="px-4 py-3">{u.account_status === "suspended" ? <Badge className="bg-destructive/10 text-destructive">Suspendu</Badge> : <Badge className="bg-emerald-500/10 text-emerald-700">Actif</Badge>}</td>
                    <td className="px-4 py-3 text-right"><Button size="sm" variant="outline" onClick={() => setSheet(u.id)}>Fiche</Button></td>
                  </tr>
                );
              })}
              {!data?.items?.length && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">Aucun membre ne correspond à ces filtres.</td></tr>}
            </tbody>
          </table>
        )}
      </Card>
      {sheet && <UserSheet userId={sheet} onClose={() => setSheet(null)} />}
    </Page>
  );
}

export default function Contact() {
  const { isAdmin } = useAuth();
  if (isAdmin) return <AdminContacts />;
  return (
    <>
      <MemberDirectory />
      <SupportCard />
    </>
  );
}

