import { useEffect, useState } from "react";
import {
  LuUsers, LuInbox, LuPackage, LuStore, LuSmartphone, LuGraduationCap, LuArrowRight, LuCopy, LuCheck, LuShare2, LuGift,
} from "react-icons/lu";
import { Link, useLocation, useNavigate } from "../lib/router";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { getCountry, formatDate } from "../lib/format";
import { Page, Card, Skeleton, ErrorBox, useLoad } from "../components/ui";

const PASTELS = ["bg-orange-100", "bg-blue-100", "bg-emerald-100", "bg-violet-100"];

function WelcomeCard({ user }) {
  return (
    <div className="relative overflow-hidden rounded-3xl gradient-novatrax p-6 sm:p-8 text-white shadow-card">
      <div className="absolute -top-16 -right-10 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
      <div className="absolute -bottom-20 -left-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
      <div className="relative">
        <p className="text-sm font-medium text-white/85">Bonjour {user?.first_name || user?.username || "Utilisateur"} 👋</p>
        <h1 className="mt-1 font-heading text-2xl sm:text-3xl font-bold">Bienvenue sur NOVATRAX !</h1>
        <p className="mt-2 text-white/85 text-sm max-w-lg">Accédez à vos formations, vos applications Pro, la Marketplace et vos informations personnelles.</p>
      </div>
    </div>
  );
}

function Stats({ stats, loading }) {
  const tiles = [
    { label: "Membres invités", value: stats?.referrals, icon: LuUsers, to: "/reseau", color: "from-blue-500 to-blue-600" },
    { label: "Messages non lus", value: stats?.unread, icon: LuInbox, to: "/boite-reception", color: "from-violet-500 to-violet-600" },
    { label: "Achats en cours", value: stats?.purchases, icon: LuPackage, to: "/mes-achats", color: "from-blue-600 to-violet-600" },
    { label: "Annonces en ligne", value: stats?.listings, icon: LuStore, to: "/ma-boutique", color: "from-violet-600 to-blue-500" },
  ];
  return (
    <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
      {tiles.map((t) => (
        <Link key={t.label} to={t.to} className="rounded-2xl border border-border bg-card p-4 sm:p-5 shadow-card hover:shadow-card-hover transition-all">
          <span className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${t.color} text-white`}>
            <t.icon className="h-5 w-5" />
          </span>
          <p className="mt-3 font-heading text-2xl font-bold">{loading ? "…" : t.value ?? 0}</p>
          <p className="text-sm text-muted-foreground">{t.label}</p>
        </Link>
      ))}
    </div>
  );
}

function Showcase({ items }) {
  const navigate = useNavigate();
  if (!items?.length) return null;
  return (
    <div className="mt-6">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-lg font-bold">Applications &amp; formations</h2>
        <Link to="/apk-pro" className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
          Tout voir <LuArrowRight className="h-4 w-4" />
        </Link>
      </div>
      <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {items.map((item, i) => {
          const Icon = item.kind === "app" ? LuSmartphone : LuGraduationCap;
          return (
            <button key={item.kind + item.id} onClick={() => navigate(item.kind === "app" ? "/apk-pro" : "/formation")} className="flex flex-col rounded-[20px] bg-card shadow-card hover:shadow-card-hover transition-all overflow-hidden text-left">
              <div className={`flex h-16 items-center justify-center ${PASTELS[i % 4]}`}>
                <Icon className="h-10 w-10 text-primary/25" />
              </div>
              <div className="relative z-10 -mt-10 flex justify-center">
                <div className="h-20 w-20 overflow-hidden rounded-2xl border-4 border-card shadow-card">
                  {item.image ? (
                    <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                  ) : (
                    <div className={`flex h-full w-full items-center justify-center ${PASTELS[i % 4]}`}>
                      <Icon className="h-8 w-8 text-primary/50" />
                    </div>
                  )}
                </div>
              </div>
              <div className="px-3 pt-2 pb-4 text-center">
                <p className="truncate text-sm font-bold">{item.name}</p>
                <span className="mt-1.5 inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold text-primary">
                  <Icon className="h-3 w-3" /> {item.kind === "app" ? "APK Pro" : "Formation"}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function ReferralCard({ code }) {
  const [copied, setCopied] = useState(false);
  const link = code ? `${window.location.origin}/register?ref=${code}` : "";
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(link);
    } catch {
      const t = document.createElement("textarea");
      t.value = link;
      document.body.appendChild(t);
      t.select();
      document.execCommand("copy");
      t.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  const share = async () => {
    const text = "Rejoins-moi sur NOVATRAX : formations, applications Pro et Marketplace.";
    if (navigator.share) {
      try { await navigator.share({ title: "NOVATRAX", text, url: link }); return; } catch { /* annulé */ }
    }
    window.open(`https://wa.me/?text=${encodeURIComponent(text + " " + link)}`, "_blank", "noopener");
  };
  return (
    <Card className="p-5 sm:p-6" >
      <div id="parrainage" className="scroll-mt-24 flex items-start gap-3">
        <span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-violet/10 text-violet">
          <LuGift className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <h2 className="font-heading text-lg font-bold">Mon lien d'invitation</h2>
          <p className="text-sm text-muted-foreground">Invitez vos proches à découvrir NOVATRAX. Les membres inscrits avec votre lien apparaissent dans « Mon réseau ».</p>
        </div>
      </div>
      <div className="mt-4 flex flex-col sm:flex-row gap-2">
        <div className="flex-1 min-w-0 rounded-xl border border-border bg-secondary px-3.5 py-2.5 text-sm font-medium truncate" title={link}>{link || "…"}</div>
        <div className="flex gap-2">
          <button onClick={copy} disabled={!code} className="inline-flex flex-1 sm:flex-none items-center justify-center gap-2 rounded-xl gradient-novatrax px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50">
            {copied ? <LuCheck className="h-4 w-4" /> : <LuCopy className="h-4 w-4" />} {copied ? "Copié !" : "Copier"}
          </button>
          <button onClick={share} disabled={!code} className="inline-flex flex-1 sm:flex-none items-center justify-center gap-2 rounded-xl border border-border px-4 py-2.5 text-sm font-semibold hover:bg-muted disabled:opacity-50">
            <LuShare2 className="h-4 w-4" /> Partager
          </button>
        </div>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">Votre code : <span className="font-mono font-semibold text-foreground">{code || "…"}</span></p>
    </Card>
  );
}

function RecentNetwork({ network, loading }) {
  return (
    <Card className="p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="font-heading text-lg font-bold">Mon réseau</h2>
          <p className="text-sm text-muted-foreground">{loading ? "…" : `${network?.direct || 0} membre(s) inscrit(s) avec votre lien`}</p>
        </div>
        <Link to="/reseau" className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
          Voir tout <LuArrowRight className="h-4 w-4" />
        </Link>
      </div>
      {loading ? (
        <Skeleton className="mt-4 h-24" />
      ) : !network?.recent?.length ? (
        <p className="mt-4 rounded-xl border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">Aucun membre invité pour le moment.</p>
      ) : (
        <ul className="mt-3 divide-y divide-border">
          {network.recent.map((m) => {
            const c = getCountry(m.country);
            return (
              <li key={m.id} className="flex items-center justify-between gap-3 py-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl gradient-novatrax text-sm font-bold text-white">
                    {(m.first_name?.[0] || m.username?.[0] || "M").toUpperCase()}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{m.first_name || m.username}</p>
                    <p className="truncate text-xs text-muted-foreground">{c ? `${c.flag} ${c.name}` : "—"}</p>
                  </div>
                </div>
                <span className="shrink-0 text-xs text-muted-foreground">{formatDate(m.created_date)}</span>
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}

export default function Home() {
  const { user } = useAuth();
  const { hash } = useLocation();
  const { data, loading, error, reload } = useLoad(() => api.get("/api/member/home"));

  useEffect(() => {
    if (hash === "#parrainage" && !loading) document.getElementById("parrainage")?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [hash, loading]);

  return (
    <Page>
      <WelcomeCard user={user} />
      {error ? (
        <ErrorBox message={error} onRetry={reload} />
      ) : (
        <>
          <div className="mt-6"><Stats stats={data?.stats} loading={loading} /></div>
          <Showcase items={data?.showcase} />
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <ReferralCard code={data?.referral_code || user?.referral_code} />
            <RecentNetwork network={data?.network} loading={loading} />
          </div>
        </>
      )}
    </Page>
  );
}
