import { useEffect, useState } from "react";
import { LuChevronDown } from "react-icons/lu";
import { Link, useNavigate } from "../lib/router";
import { api } from "../lib/api";
import { COUNTRIES, getCountry, errMsg, pendingRef } from "../lib/format";
import { Alert, Button } from "../components/ui";
import AuthShell, { PasswordInput, safeReturnTo } from "../components/AuthShell";

export default function Register() {
  const navigate = useNavigate();
  // Lien d'invitation : /register?ref=CODE — le code est conservé pendant tout le parcours.
  const urlRef = (new URLSearchParams(window.location.search).get("ref") || "").trim();
  const [form, setForm] = useState({
    email: "", username: "", first_name: "", last_name: "", country: "", phone: "",
    sponsor: urlRef || pendingRef.get(), password: "", confirm: "", accept_terms: false, share_contacts: false,
  });
  const [sponsorName, setSponsorName] = useState(null);
  const [sponsorInvalid, setSponsorInvalid] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (urlRef) pendingRef.set(urlRef);
    const code = urlRef || pendingRef.get();
    if (!code) return;
    api.post("/api/auth/check", { ref_code: code })
      .then((r) => {
        if (r.sponsor?.username) setSponsorName(r.sponsor.username);
        else setSponsorInvalid(true);
      })
      .catch(() => {});
  }, []);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));
  const country = getCountry(form.country);

  const validate = () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) return "Veuillez saisir une adresse e-mail valide.";
    if (!/^[a-zA-Z0-9_.]{3,20}$/.test(form.username.trim())) return "Nom d'utilisateur : 3 à 20 caractères (lettres, chiffres, _ ou .).";
    if (!/^[A-Za-zÀ-ÿ' -]{2,40}$/.test(form.first_name.trim())) return "Veuillez saisir votre prénom.";
    if (!form.country) return "Veuillez sélectionner votre pays.";
    if (!/^\d{6,12}$/.test(form.phone.replace(/[\s-]/g, ""))) return "Le numéro de téléphone n'est pas valide (chiffres uniquement, sans l'indicatif).";
    if (form.password.length < 8) return "Le mot de passe doit contenir au moins 8 caractères.";
    if (!/[a-zA-Z]/.test(form.password) || !/\d/.test(form.password)) return "Le mot de passe doit contenir des lettres et des chiffres.";
    if (form.password !== form.confirm) return "Les mots de passe ne correspondent pas.";
    if (!form.accept_terms) return "Vous devez accepter les conditions générales et la politique de confidentialité.";
    return null;
  };

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    const v = validate();
    if (v) return setError(v);
    setLoading(true);
    try {
      const r = await api.post("/api/auth/register", {
        email: form.email.trim(), username: form.username.trim(), first_name: form.first_name.trim(), last_name: form.last_name.trim(),
        country: form.country, phone: form.phone.replace(/[\s-]/g, ""), ref_code: form.sponsor.trim().replace(/^@/, ""),
        password: form.password, accept_terms: form.accept_terms, share_contacts: form.share_contacts,
      });
      const rt = safeReturnTo();
      navigate(`/verifier?email=${encodeURIComponent(r.email)}${r.dev_code ? "&dev=" + r.dev_code : ""}${rt !== "/" ? "&returnTo=" + encodeURIComponent(rt) : ""}`);
    } catch (err) {
      setError(errMsg(err, "Inscription échouée. Veuillez réessayer."));
    } finally {
      setLoading(false);
    }
  };

  const input = "field h-12";
  return (
    <AuthShell subtitle="Saisissez vos informations personnelles pour créer un compte">
      {error && <Alert className="mb-5">{error}</Alert>}
      <form onSubmit={submit} className="space-y-5">
        <label className="block space-y-1.5">
          <span className="text-sm font-medium">Adresse e-mail</span>
          <input type="email" autoComplete="email" placeholder="Adresse e-mail" value={form.email} onChange={set("email")} className={input} required />
        </label>
        <label className="block space-y-1.5">
          <span className="text-sm font-medium">Nom d'utilisateur</span>
          <input type="text" autoComplete="username" placeholder="Saisissez votre nom d'utilisateur" value={form.username} onChange={set("username")} className={input} required />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="block space-y-1.5">
            <span className="text-sm font-medium">Prénom</span>
            <input type="text" autoComplete="given-name" placeholder="Votre prénom" value={form.first_name} onChange={set("first_name")} className={input} required />
          </label>
          <label className="block space-y-1.5">
            <span className="text-sm font-medium">Nom</span>
            <input type="text" autoComplete="family-name" placeholder="Votre nom" value={form.last_name} onChange={set("last_name")} className={input} />
          </label>
        </div>
        <div className="space-y-1.5">
          <span className="text-sm font-medium">Contact</span>
          <div className="relative">
            <select value={form.country} onChange={set("country")} className={`${input} appearance-none pr-10 font-medium`} required aria-label="Pays">
              <option value="">Sélectionnez votre pays</option>
              {COUNTRIES.map((c) => (
                <option key={c.code} value={c.code}>{c.flag} {c.name} ({c.dialCode})</option>
              ))}
            </select>
            <LuChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          </div>
          <div className="relative">
            {country && <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-medium text-muted-foreground">{country.dialCode}</span>}
            <input type="tel" inputMode="numeric" placeholder="Numéro de téléphone" value={form.phone} onChange={set("phone")} className={`${input} ${country ? "pl-16" : ""}`} required aria-label="Numéro de téléphone" />
          </div>
        </div>
        <label className="block space-y-1.5">
          <span className="text-sm font-medium">Invité(e) par</span>
          <input
            type="text"
            placeholder="Code ou nom d'utilisateur du parrain (optionnel)"
            value={sponsorName ? `@${sponsorName}` : form.sponsor}
            onChange={(e) => { setSponsorInvalid(false); set("sponsor")(e); }}
            readOnly={!!sponsorName}
            className={input}
          />
          {sponsorName && <span className="block text-xs text-muted-foreground">Parrain identifié à partir du lien partagé — cette information est verrouillée.</span>}
          {sponsorInvalid && <span className="block text-xs text-destructive">Ce code n'a pas été reconnu. Corrigez-le ou laissez le champ vide.</span>}
        </label>
        <label className="block space-y-1.5">
          <span className="text-sm font-medium">Mot de passe</span>
          <PasswordInput value={form.password} onChange={set("password")} autoComplete="new-password" />
          <span className="block text-xs text-muted-foreground">8 caractères minimum, avec des lettres et des chiffres.</span>
        </label>
        <label className="block space-y-1.5">
          <span className="text-sm font-medium">Confirmez le mot de passe</span>
          <PasswordInput value={form.confirm} onChange={set("confirm")} autoComplete="new-password" />
        </label>
        <label className="flex items-start gap-3 pt-1 cursor-pointer">
          <input type="checkbox" checked={form.accept_terms} onChange={set("accept_terms")} className="mt-0.5 h-4 w-4 accent-violet" />
          <span className="text-sm text-muted-foreground">
            J'accepte les <Link to="/terms" className="font-medium text-foreground hover:underline">conditions générales</Link> et{" "}
            <Link to="/privacy" className="text-violet font-medium hover:underline">la politique de confidentialité</Link>.
          </span>
        </label>
        <label className="flex items-start gap-3 cursor-pointer">
          <input type="checkbox" checked={form.share_contacts} onChange={set("share_contacts")} className="mt-0.5 h-4 w-4 accent-violet" />
          <span className="text-sm text-muted-foreground">
            J'accepte que mon nom et mon numéro de téléphone soient visibles et partageables avec les membres de NOVATRAX qui partagent aussi les leurs (facultatif, modifiable à tout moment).
          </span>
        </label>
        <Button type="submit" variant="violet" size="lg" className="w-full" loading={loading}>
          {loading ? "Création du compte…" : "Créer un compte"}
        </Button>
      </form>
      <p className="mt-8 text-center text-sm text-muted-foreground">
        Vous avez déjà un compte ?{" "}
        <Link to="/login" className="text-violet font-semibold hover:underline">Se connecter</Link>
      </p>
    </AuthShell>
  );
}
