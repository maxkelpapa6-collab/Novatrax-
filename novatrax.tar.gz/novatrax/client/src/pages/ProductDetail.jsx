import { useState } from "react";
import { LuChevronLeft, LuPhone, LuMessageCircle, LuShoppingCart, LuStore, LuShieldCheck } from "react-icons/lu";
import { Link, useNavigate } from "../lib/router";
import { api } from "../lib/api";
import { formatFcfa, formatDate, errMsg } from "../lib/format";
import { useToast } from "../lib/toast";
import { Page, Card, Button, Skeleton, Modal, Field, Alert, useLoad } from "../components/ui";
import { ProductBadge } from "../components/marketplace";

export default function ProductDetail({ params }) {
  const navigate = useNavigate();
  const toast = useToast();
  const { data: p, loading, error } = useLoad(() => api.get(`/api/marketplace/products/${params.id}`), [params.id]);
  const [ordering, setOrdering] = useState(false);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const order = async () => {
    setBusy(true);
    setErr("");
    try {
      await api.post("/api/marketplace/orders", { product_id: p.id, note });
      toast({ title: "Commande enregistrée", description: "Le vendeur a été prévenu. Suivez votre commande dans « Mes achats »." });
      navigate("/mes-achats");
    } catch (e) {
      setErr(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const wa = p?.seller_phone?.replace(/\D/g, "");

  return (
    <Page>
      <Link to="/marketplace" className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground">
        <LuChevronLeft className="h-4 w-4" /> Marketplace
      </Link>
      {loading ? (
        <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2"><Skeleton className="aspect-square" /><Skeleton className="h-72" /></div>
      ) : error || !p ? (
        <Card className="mt-6 p-10 text-center">
          <h1 className="font-heading text-xl font-bold">Produit introuvable</h1>
          <p className="mt-1 text-sm text-muted-foreground">Ce produit n'est plus disponible sur la Marketplace.</p>
        </Card>
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="overflow-hidden rounded-3xl border border-border bg-muted aspect-square">
            {p.image_url && <img src={p.image_url} alt={p.name} className="h-full w-full object-cover" />}
          </div>
          <div>
            {p.category && <p className="text-xs font-semibold uppercase tracking-wide text-violet">{p.category}</p>}
            <h1 className="mt-1 font-heading text-2xl sm:text-3xl font-bold">{p.name}</h1>
            <p className="mt-3 font-heading text-3xl font-extrabold text-gradient-novatrax">{formatFcfa(p.price_fcfa)}</p>
            {p.status !== "published" && <div className="mt-3"><ProductBadge status={p.status} /></div>}
            {p.description && <p className="mt-4 whitespace-pre-line text-sm text-muted-foreground">{p.description}</p>}
            <Card className="mt-5 p-4">
              <p className="text-xs text-muted-foreground">Vendeur</p>
              <p className="mt-0.5 flex items-center gap-2 font-semibold"><LuStore className="h-4 w-4 text-primary" /> {p.seller_name || "Membre NOVATRAX"}</p>
              <p className="mt-1 text-xs text-muted-foreground">Annonce publiée le {formatDate(p.created_date)}</p>
              {p.seller_phone && (
                <div className="mt-3 flex flex-wrap gap-2">
                  <a href={`tel:${p.seller_phone}`} className="inline-flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-sm font-semibold hover:bg-muted"><LuPhone className="h-4 w-4" /> {p.seller_phone}</a>
                  {wa && <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-emerald-500/10 px-3 py-2 text-sm font-semibold text-emerald-700 hover:bg-emerald-500/20"><LuMessageCircle className="h-4 w-4" /> WhatsApp</a>}
                </div>
              )}
            </Card>
            {p.is_mine ? (
              <Alert variant="info" className="mt-5">C'est votre annonce. Gérez-la depuis <Link to="/ma-boutique" className="font-semibold underline">Ma boutique</Link>.</Alert>
            ) : p.status === "published" && (
              <Button size="lg" className="mt-5 w-full" icon={LuShoppingCart} onClick={() => setOrdering(true)}>Commander</Button>
            )}
            <p className="mt-3 flex items-start gap-2 text-xs text-muted-foreground">
              <LuShieldCheck className="h-4 w-4 shrink-0" /> Annonce validée par l'administration. Ne payez qu'après avoir convenu des modalités avec le vendeur ; en cas de problème, ouvrez un litige depuis « Mes achats ».
            </p>
          </div>
        </div>
      )}
      {ordering && (
        <Modal title="Confirmer la commande" onClose={() => setOrdering(false)}
          footer={<><Button variant="outline" onClick={() => setOrdering(false)}>Annuler</Button><Button loading={busy} onClick={order}>Confirmer la commande</Button></>}>
          <p className="text-sm">
            <span className="font-semibold">{p.name}</span> — {formatFcfa(p.price_fcfa)}
          </p>
          <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
            <li>Le vendeur est prévenu de votre commande et reçoit votre numéro.</li>
            <li>Vous convenez ensemble du paiement et de la livraison.</li>
            <li>Le vendeur confirme la réception du paiement, puis vous confirmez la réception du produit.</li>
          </ol>
          <Field label="Message au vendeur (facultatif)" className="mt-4">
            <textarea className="field min-h-20" maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Quartier de livraison, disponibilités…" />
          </Field>
          {err && <Alert className="mt-4">{err}</Alert>}
        </Modal>
      )}
    </Page>
  );
}
