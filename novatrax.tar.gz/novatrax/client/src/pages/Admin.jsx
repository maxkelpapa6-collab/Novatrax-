import { useState } from "react";
import {
  LuLayoutDashboard, LuUsers, LuGraduationCap, LuSmartphone, LuScrollText, LuShieldCheck, LuArrowRight, LuFileSpreadsheet,
  LuMail, LuStore, LuSearch, LuTriangleAlert, LuClock, LuUserX,
} from "react-icons/lu";
import { Link } from "../lib/router";
import { api, qs } from "../lib/api";
import { useAuth } from "../lib/auth";
import { getCountry, formatDate, formatDateTime, fullName } from "../lib/format";
import { Page, Card, Button, Badge, Skeleton, Alert, useLoad } from "../components/ui";
import UserSheet from "../components/UserSheet";
import MessagesAdmin from "../components/admin/MessagesAdmin";
import MarketplaceAdmin from "../components/admin/MarketplaceAdmin";

const TABS = [
  { id: "overview", label: "Vue d'ensemble", icon: LuLayoutDashboard },
  { id: "users", label: "Utilisateurs", icon: LuUsers },
  { id: "messages", label: "Messages", icon: LuMail },
  { id: "marketplace", label: "Marketplace", icon: LuStore },
  { id: "audit", label: "Journal d'audit", icon: LuScrollText },
];

function Overview({ go }) {
  const { data: s, loading } = useLoad(() => api.get("/api/admin/stats"));
  const v = (x) => (loading ? "…" : x ?? "—");
  const cards = [
    { label: "Membres inscrits", value: v(s?.members), icon: LuUsers, color: "from-blue-500 to-blue-600", onClick: () => go("users") },
    { label: "Inscrits aujourd'hui", value: v(s?.today), icon: LuClock, color: "from-violet-500 to-violet-600", onClick: () => go("users") },
    { label: "Annonces à valider", value: v(s?.products_pending), icon: LuStore, color: "from-blue-600 to-violet-600", onClick: () => go("marketplace") },
    { label: "Litiges ouverts", value: v(s?.disputes), icon: LuTriangleAlert, color: "from-violet-600 to-blue-500", onClick: () => go("marketplace") },
    { label: "Formations", value: v(s?.formations), icon: LuGraduationCap, color: "from-blue-500 to-violet-500" },
    { label: "Applications Pro", value: v(s?.apps), icon: LuSmartphone, color: "from-violet-500 to-blue-600" },
    { label: "Comptes suspendus", value: v(s?.suspended), icon: LuUserX, color: "from-blue-600 to-blue-500", onClick: () => go("users") },
    { label: "Actions journalisées", value: v(s?.audits), icon: LuScrollText, color: "from-violet-600 to-violet-500", onClick: () => go("audit") },
  ];
  return (
    <div>
      {s && !s.mail_configured && (
        <Alert variant="warning" className="mb-4">Aucun service d'envoi d'e-mails n'est configuré : les codes de vérification et e-mails sont affichés dans la console du serveur. Renseignez MAIL_PROVIDER et MAIL_API_KEY dans le fichier .env avant la mise en ligne.</Alert>
      )}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <button key={c.label} onClick={c.onClick} disabled={!c.onClick} className="rounded-2xl border border-border bg-card p-5 shadow-card text-left enabled:hover:shadow-card-hover transition-all disabled:cursor-default">
            <span className={`inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${c.color} text-white`}><c.icon className="h-5 w-5" /></span>
            <p className="mt-4 text-2xl font-heading font-bold">{c.value}</p>
            <p className="text-sm text-muted-foreground">{c.label}</p>
          </button>
        ))}
      </div>
      <h2 className="mt-8 font-heading text-lg font-bold">Gestion des contenus</h2>
      <div className="mt-3 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {[
          ["/formation", "Formations", "Ajouter, modifier, publier ou supprimer", LuGraduationCap, "bg-violet/10 text-violet"],
          ["/apk-pro", "Applications Pro", "Gérer le catalogue des APK", LuSmartphone, "bg-primary/10 text-primary"],
          ["/contact", "Contacts & exports", "Consulter les membres, filtrer et exporter en CSV / VCF", LuFileSpreadsheet, "bg-blue-500/10 text-blue-600"],
          ["/marketplace", "Vitrine Marketplace", "Voir la Marketplace comme un membre", LuStore, "bg-emerald-500/10 text-emerald-600"],
        ].map(([to, t, d, I, cls]) => (
          <Link key={to} to={to} className="group rounded-2xl border border-border bg-card p-5 shadow-card hover:shadow-card-hover transition-all flex items-center gap-4">
            <span className={`inline-flex h-12 w-12 items-center justify-center rounded-2xl ${cls}`}><I className="h-6 w-6" /></span>
            <div className="flex-1"><p className="font-semibold">{t}</p><p className="text-sm text-muted-foreground">{d}</p></div>
            <LuArrowRight className="h-5 w-5 text-muted-foreground group-hover:translate-x-1 transition-transform" />
          </Link>
        ))}
      </div>
    </div>
  );
}

function UsersAdmin() {
  const [search, setSearch] = useState("");
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [verified, setVerified] = useState("yes");
  const [offset, setOffset] = useState(0);
  const [sheet, setSheet] = useState(null);
  const { data, loading, reload } = useLoad(() => api.get("/api/admin/users" + qs({ search: q, status, verified, offset })), [q, status, verified, offset]);
  return (
    <div>
      <form onSubmit={(e) => { e.preventDefault(); setOffset(0); setQ(search.trim()); }} className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-56">
          <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Nom, e-mail, nom d'utilisateur, téléphone, code…" className="field pl-9" />
        </div>
        <select className="field w-auto" value={status} onChange={(e) => { setOffset(0); setStatus(e.target.value); }}>
          <option value="">Tous les statuts</option><option value="active">Actifs</option><option value="suspended">Suspendus</option>
        </select>
        <select className="field w-auto" value={verified} onChange={(e) => { setOffset(0); setVerified(e.target.value); }}>
          <option value="yes">E-mail vérifié</option><option value="no">Inscriptions non vérifiées</option>
        </select>
        <Button type="submit" icon={LuSearch}>Rechercher</Button>
      </form>
      <p className="mt-3 text-sm text-muted-foreground">{loading ? "…" : `${data?.total ?? 0} utilisateur(s)`}</p>
      {loading ? (
        <div className="mt-3 space-y-2">{[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : (
        <Card className="mt-3 overflow-hidden">
          <div className="divide-y divide-border">
            {data?.items?.map((u) => {
              const c = getCountry(u.country);
              const suspended = u.account_status === "suspended";
              return (
                <button key={u.id} onClick={() => setSheet(u.id)} className="flex w-full flex-col sm:flex-row sm:items-center gap-3 p-4 text-left hover:bg-muted/30">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl gradient-novatrax text-white text-sm font-bold">{(u.first_name?.[0] || u.email[0]).toUpperCase()}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold truncate">{fullName(u)}</p>
                      {u.role === "admin" && <Badge className="bg-primary/10 text-primary text-[10px] uppercase">Admin</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{u.email} {c ? `· ${c.flag} ${c.name}` : ""} · {formatDate(u.created_date)}</p>
                  </div>
                  <Badge className={suspended ? "bg-destructive/10 text-destructive" : "bg-emerald-500/10 text-emerald-700"}>{suspended ? "Suspendu" : "Actif"}</Badge>
                </button>
              );
            })}
            {!data?.items?.length && <p className="p-8 text-center text-muted-foreground">Aucun utilisateur trouvé.</p>}
          </div>
        </Card>
      )}
      <div className="mt-4 flex justify-between">
        <Button variant="outline" disabled={!offset} onClick={() => setOffset(Math.max(0, offset - 50))}>← Précédents</Button>
        <Button variant="outline" disabled={!data?.has_more} onClick={() => setOffset(offset + 50)}>Suivants →</Button>
      </div>
      {sheet && <UserSheet userId={sheet} onClose={() => setSheet(null)} onChanged={() => reload(true)} />}
    </div>
  );
}

function AuditLog() {
  const [offset, setOffset] = useState(0);
  const { data, loading } = useLoad(() => api.get("/api/admin/audit" + qs({ offset })), [offset]);
  return (
    <Card className="overflow-hidden">
      <div className="px-5 py-4 border-b border-border flex items-center gap-2">
        <LuScrollText className="h-5 w-5 text-primary" />
        <h2 className="font-heading text-lg font-bold">Journal des actions sensibles</h2>
      </div>
      {loading ? (
        <div className="p-5 space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-14" />)}</div>
      ) : !data?.items?.length ? (
        <p className="p-8 text-center text-muted-foreground">Aucune action journalisée pour le moment.</p>
      ) : (
        <div className="divide-y divide-border">
          {data.items.map((l) => (
            <div key={l.id} className="p-4 flex items-start gap-3">
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${l.result === "error" ? "bg-destructive" : "bg-primary"}`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">{ACTION_LABELS[l.action] || l.action}</p>
                <p className="text-xs text-muted-foreground">{l.admin_email}</p>
                {(l.details || l.reason) && <p className="text-xs text-muted-foreground/90 mt-0.5 break-words">{[l.details, l.reason && "Motif : " + l.reason].filter(Boolean).join(" · ")}</p>}
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{formatDateTime(l.created_date)}</span>
            </div>
          ))}
        </div>
      )}
      <div className="flex justify-between border-t border-border p-3">
        <Button size="sm" variant="outline" disabled={!offset} onClick={() => setOffset(Math.max(0, offset - 50))}>← Plus récents</Button>
        <Button size="sm" variant="outline" disabled={!data?.has_more} onClick={() => setOffset(offset + 50)}>Plus anciens →</Button>
      </div>
    </Card>
  );
}

const ACTION_LABELS = {
  admin_init: "Initialisation d'un administrateur",
  admin_user_sheet_view: "Consultation de fiche utilisateur",
  user_block: "Blocage d'un compte",
  user_unblock: "Déblocage d'un compte",
  user_email_manual_verify: "Vérification manuelle d'e-mail",
  user_role_admin: "Nomination administrateur",
  user_role_user: "Retrait des droits administrateur",
  user_force_logout: "Déconnexion forcée",
  contact_export_csv: "Export CSV des contacts",
  contact_export_vcf: "Export VCF des contacts",
  formation_create: "Création de formation",
  formation_update: "Modification de formation",
  formation_delete: "Suppression de formation",
  application_create: "Création d'application",
  application_update: "Modification d'application",
  application_delete: "Suppression d'application",
  application_publish: "Activation d'application",
  application_unpublish: "Désactivation d'application",
  application_apk_upload: "Téléversement d'un fichier APK",
  application_apk_delete: "Retrait d'un fichier APK",
  email_test_send: "Envoi d'un e-mail de test",
  email_campaign_send: "Envoi d'un message aux membres",
  marketplace_product_submit: "Annonce Marketplace soumise à validation",
  marketplace_product_update: "Annonce Marketplace modifiée",
  marketplace_product_delete: "Annonce Marketplace supprimée",
  marketplace_product_blocked: "Annonce Marketplace bloquée automatiquement",
  marketplace_seller_auto_suspended: "Vendeur suspendu automatiquement (infractions répétées)",
  marketplace_order_created: "Commande Marketplace créée",
  marketplace_order_completed: "Vente Marketplace terminée",
  marketplace_order_disputed: "Litige Marketplace ouvert",
  marketplace_admin_product: "Modération d'annonce Marketplace",
  marketplace_admin_category: "Gestion des catégories Marketplace",
  marketplace_admin_rule: "Gestion des règles Marketplace",
  marketplace_admin_order: "Décision administrative sur une commande",
  marketplace_admin_seller_ban: "Suspension vendeur Marketplace",
  marketplace_admin_seller_unban: "Rétablissement vendeur Marketplace",
};

export default function Admin() {
  const { isAdmin } = useAuth();
  const [tab, setTab] = useState("overview");
  if (!isAdmin) {
    return (
      <Page narrow>
        <div className="py-10 text-center">
          <LuShieldCheck className="mx-auto h-12 w-12 text-muted-foreground" />
          <h1 className="mt-4 font-heading text-2xl font-bold">Accès réservé aux administrateurs</h1>
          <p className="mt-2 text-muted-foreground">Vous n'avez pas les permissions nécessaires pour accéder à cet espace.</p>
          <Link to="/" className="mt-6 inline-flex rounded-xl gradient-novatrax px-5 py-2.5 text-sm font-semibold text-white">Retour au tableau de bord</Link>
        </div>
      </Page>
    );
  }
  return (
    <Page>
      <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary"><LuShieldCheck className="h-3.5 w-3.5" /> Espace administrateur</span>
      <h1 className="mt-3 font-heading text-3xl sm:text-4xl font-bold">Administration</h1>
      <p className="mt-2 text-muted-foreground">Gérez la plateforme NOVATRAX : utilisateurs, contenus, Marketplace et sécurité.</p>
      <div className="mt-6 flex gap-1 overflow-x-auto no-scrollbar rounded-2xl border border-border bg-card p-1.5 shadow-card">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold whitespace-nowrap transition-colors ${tab === t.id ? "gradient-novatrax text-white shadow-sm" : "text-muted-foreground hover:bg-muted"}`}>
            <t.icon className="h-4 w-4" /> {t.label}
          </button>
        ))}
      </div>
      <div className="mt-6">
        {tab === "overview" && <Overview go={setTab} />}
        {tab === "users" && <UsersAdmin />}
        {tab === "messages" && <MessagesAdmin />}
        {tab === "marketplace" && <MarketplaceAdmin />}
        {tab === "audit" && <AuditLog />}
      </div>
    </Page>
  );
}
