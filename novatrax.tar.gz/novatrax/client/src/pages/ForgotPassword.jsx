import { useState } from "react";
import { Link, useNavigate } from "../lib/router";
import { api } from "../lib/api";
import { errMsg } from "../lib/format";
import { useToast } from "../lib/toast";
import { Alert, Button } from "../components/ui";
import AuthShell, { OtpInput, PasswordInput } from "../components/AuthShell";

export default function ForgotPassword() {
  const navigate = useNavigate();
  const toast = useToast();
  const [step, setStep] = useState("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [devCode, setDevCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const request = async (e) => {
    e.preventDefault();
    setError("");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return setError("Veuillez saisir une adresse e-mail valide.");
    setLoading(true);
    try {
      const r = await api.post("/api/auth/forgot", { email: email.trim() });
      setDevCode(r.dev_code || "");
      setStep("reset");
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setLoading(false);
    }
  };

  const reset = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirm) return setError("Les mots de passe ne correspondent pas.");
    setLoading(true);
    try {
      await api.post("/api/auth/reset", { email: email.trim(), code, password });
      toast({ title: "Mot de passe modifié", description: "Vous pouvez vous connecter avec votre nouveau mot de passe." });
      navigate("/login", { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setLoading(false);
    }
  };

  if (step === "reset") {
    return (
      <AuthShell title="Nouveau mot de passe" subtitle={<>Si un compte existe pour <span className="font-semibold text-foreground">{email}</span>, un code à 6 chiffres vient d'y être envoyé.</>}>
        {devCode && <Alert variant="info" className="mb-5">Mode développement : votre code est <strong>{devCode}</strong>.</Alert>}
        {error && <Alert className="mb-5">{error}</Alert>}
        <form onSubmit={reset} className="space-y-5">
          <label className="block space-y-1.5">
            <span className="text-sm font-medium">Code reçu par e-mail</span>
            <OtpInput value={code} onChange={setCode} />
          </label>
          <label className="block space-y-1.5">
            <span className="text-sm font-medium">Nouveau mot de passe</span>
            <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
          </label>
          <label className="block space-y-1.5">
            <span className="text-sm font-medium">Confirmez le mot de passe</span>
            <PasswordInput value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
          </label>
          <Button type="submit" variant="violet" size="lg" className="w-full" loading={loading} disabled={code.length < 6}>
            Réinitialiser le mot de passe
          </Button>
        </form>
        <p className="mt-6 text-center text-sm text-muted-foreground">
          <button onClick={() => setStep("email")} className="hover:underline">Changer d'adresse e-mail</button>
        </p>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Mot de passe oublié" subtitle="Saisissez l'adresse e-mail de votre compte : nous vous enverrons un code de réinitialisation.">
      {error && <Alert className="mb-5">{error}</Alert>}
      <form onSubmit={request} className="space-y-5">
        <input type="email" autoComplete="email" autoFocus placeholder="Adresse e-mail" value={email} onChange={(e) => setEmail(e.target.value)} className="field h-12" required />
        <Button type="submit" variant="violet" size="lg" className="w-full" loading={loading}>Envoyer le code</Button>
      </form>
      <p className="mt-8 text-center text-sm text-muted-foreground">
        <Link to="/login" className="text-violet font-semibold hover:underline">← Retour à la connexion</Link>
      </p>
    </AuthShell>
  );
}
