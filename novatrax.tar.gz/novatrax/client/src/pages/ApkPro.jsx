import { useRef, useState } from "react";
import {
  LuSmartphone, LuPlus, LuPencil, LuTrash2, LuPower, LuDownload, LuShoppingCart, LuFileDown, LuLink2, LuUpload, LuInfo,
} from "react-icons/lu";
import { api, tokenStore } from "../lib/api";
import { useAuth } from "../lib/auth";
import { errMsg, formatBytes, formatDate } from "../lib/format";
import { useToast } from "../lib/toast";
import { Page, PageHeader, Button, Modal, Field, ImageInput, Alert, EmptyState, Skeleton, ErrorBox, ConfirmModal, useLoad, Spinner } from "../components/ui";

const PASTELS = ["bg-orange-100", "bg-blue-100", "bg-emerald-100", "bg-violet-100"];
const isNew = (d) => d && Date.now() - new Date(d).getTime() < 30 * 86400000;

// Téléversement d'un APK avec suivi de progression.
function uploadApk(appId, file, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `/api/applications/${appId}/apk`);
    xhr.setRequestHeader("Authorization", "Bearer " + tokenStore.get());
    xhr.setRequestHeader("Content-Type", "application/octet-stream");
    xhr.setRequestHeader("X-Filename", encodeURIComponent(file.name));
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => {
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch { /* rien */ }
      xhr.status < 300 ? resolve(data) : reject(new Error(data.error || "Téléversement échoué."));
    };
    xhr.onerror = () => reject(new Error("Connexion interrompue."));
    xhr.send(file);
  });
}

function ApkFilePanel({ app, onChanged }) {
  const ref = useRef(null);
  const toast = useToast();
  const [progress, setProgress] = useState(null);
  const [confirmDel, setConfirmDel] = useState(false);
  const pick = async (file) => {
    if (!file) return;
    setProgress(0);
    try {
      await uploadApk(app.id, file, setProgress);
      toast({ title: "Fichier APK enregistré", description: file.name });
      onChanged();
    } catch (e) {
      toast({ title: "Téléversement impossible", description: e.message, variant: "destructive" });
    } finally {
      setProgress(null);
      if (ref.current) ref.current.value = "";
    }
  };
  return (
    <div className="mt-3 rounded-xl border border-dashed border-border p-3 text-xs">
      {app.has_apk_file ? (
        <p className="font-medium break-all">{app.apk_file_name} <span className="text-muted-foreground">· {formatBytes(app.apk_file_size)} · {formatDate(app.apk_file_date)}</span></p>
      ) : (
        <p className="text-muted-foreground">Aucun fichier APK téléversé.</p>
      )}
      {progress !== null ? (
        <div className="mt-2">
          <div className="h-2 rounded-full bg-muted overflow-hidden"><div className="h-full gradient-novatrax transition-all" style={{ width: progress + "%" }} /></div>
          <p className="mt-1 text-muted-foreground">Téléversement… {progress} %</p>
        </div>
      ) : (
        <div className="mt-2 flex flex-wrap gap-2">
          <Button size="sm" variant="outline" icon={LuUpload} onClick={() => ref.current?.click()}>{app.has_apk_file ? "Remplacer l'APK" : "Téléverser un APK"}</Button>
          {app.has_apk_file && <Button size="sm" variant="danger" icon={LuTrash2} onClick={() => setConfirmDel(true)}>Retirer</Button>}
        </div>
      )}
      <input ref={ref} type="file" accept=".apk,.xapk,.apks,application/vnd.android.package-archive" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
      {confirmDel && (
        <ConfirmModal title="Retirer le fichier APK" text="Le fichier sera supprimé et l'application dépubliée." confirmLabel="Retirer" variant="danger"
          onConfirm={async () => { await api.del(`/api/applications/${app.id}/apk`); onChanged(); }} onClose={() => setConfirmDel(false)} />
      )}
    </div>
  );
}

function AppCard({ app, variant, isAdmin, onEdit, onDelete, onToggle, onChanged, onDetails }) {
  const toast = useToast();
  const [downloading, setDownloading] = useState(false);
  const download = async () => {
    setDownloading(true);
    try {
      const r = await api.post(`/api/applications/${app.id}/download`);
      const a = document.createElement("a");
      a.href = r.url;
      a.download = app.apk_file_name || app.name + ".apk";
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (e) {
      toast({ title: "Téléchargement impossible", description: errMsg(e), variant: "destructive" });
    } finally {
      setDownloading(false);
    }
  };
  const type = app.download_type;
  return (
    <article className="relative flex flex-col rounded-[20px] bg-card shadow-card hover:shadow-card-hover transition-all overflow-hidden">
      {isNew(app.created_date) && app.published && <span className="absolute top-2 left-2 z-20 rounded-md bg-emerald-600 px-2 py-0.5 text-[10px] font-bold uppercase text-white">Nouveau</span>}
      {isAdmin && !app.published && <span className="absolute top-2 left-2 z-20 rounded-md bg-amber-500 px-2 py-0.5 text-[10px] font-bold uppercase text-white">Inactive</span>}
      {isAdmin && (
        <span className={`absolute top-2 right-2 z-20 inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-bold uppercase text-white ${type === "apk_file" ? "bg-violet" : "bg-primary"}`}>
          {type === "apk_file" ? <LuFileDown className="h-3 w-3" /> : <LuLink2 className="h-3 w-3" />} {type === "apk_file" ? "APK" : "Lien"}
        </span>
      )}
      <button onClick={() => onDetails(app)} className="text-left">
        <div className={`flex h-20 items-center justify-center ${PASTELS[variant % 4]}`}><LuSmartphone className="h-10 w-10 text-primary/25" /></div>
        <div className="relative z-10 -mt-12 flex justify-center">
          <div className="h-24 w-24 overflow-hidden rounded-2xl border-4 border-card shadow-card">
            {app.logo_image ? <img src={app.logo_image} alt={app.name} className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center bg-muted"><LuSmartphone className="h-8 w-8 text-primary/50" /></div>}
          </div>
        </div>
        <div className="px-3 pt-2 text-center">
          <h3 className="truncate text-sm font-bold">{app.name}</h3>
          <p className="truncate text-xs text-muted-foreground">{app.price || "Application"}{app.version ? ` · v${app.version}` : ""}</p>
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground/90">{app.description}</p>
        </div>
        <div className="px-3 pt-2 text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold text-primary"><LuSmartphone className="h-3 w-3" /> APK Pro</span>
        </div>
      </button>
      {!isAdmin && (
        <div className="mt-auto flex flex-wrap gap-2 px-3 pb-4 pt-3">
          {type === "apk_file" && app.has_apk_file && (
            <button onClick={download} disabled={downloading} className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl gradient-novatrax px-3 py-2 text-xs font-semibold text-white disabled:opacity-60">
              {downloading ? <Spinner className="h-3.5 w-3.5" /> : <LuDownload className="h-3.5 w-3.5" />} {downloading ? "Préparation…" : "Télécharger"}
            </button>
          )}
          {type === "external_link" && app.download_url && (
            <a href={app.download_url} target="_blank" rel="noopener noreferrer" className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl gradient-novatrax px-3 py-2 text-xs font-semibold text-white">
              <LuDownload className="h-3.5 w-3.5" /> Télécharger
            </a>
          )}
          {app.purchase_url && (
            <a href={app.purchase_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-border px-3 py-2 text-xs font-semibold hover:bg-muted">
              <LuShoppingCart className="h-3.5 w-3.5" /> Acheter
            </a>
          )}
        </div>
      )}
      {isAdmin && (
        <div className="mt-auto px-3 pb-4">
          {type === "apk_file" && <ApkFilePanel app={app} onChanged={onChanged} />}
          <div className="mt-3 flex flex-wrap gap-2 border-t border-border pt-3">
            <Button size="sm" variant="outline" icon={LuPencil} onClick={() => onEdit(app)}>Modifier</Button>
            <Button size="sm" variant={app.published ? "outline" : "success"} icon={LuPower} onClick={() => onToggle(app)}>{app.published ? "Désactiver" : "Activer"}</Button>
            <Button size="sm" variant="danger" icon={LuTrash2} onClick={() => onDelete(app)}>Supprimer</Button>
          </div>
        </div>
      )}
    </article>
  );
}

function AppDetails({ app, onClose }) {
  return (
    <Modal title={app.name} onClose={onClose}>
      <div className="flex items-center gap-4">
        <div className="h-16 w-16 overflow-hidden rounded-2xl bg-muted shrink-0">{app.logo_image && <img src={app.logo_image} alt="" className="h-full w-full object-cover" />}</div>
        <div className="text-sm">
          <p className="font-semibold">{app.price || "Application"}</p>
          {app.version && <p className="text-muted-foreground">Version {app.version}</p>}
          {app.apk_file_size ? <p className="text-muted-foreground">{formatBytes(app.apk_file_size)}</p> : null}
        </div>
      </div>
      {app.presentation_image && <img src={app.presentation_image} alt="" className="mt-4 w-full rounded-2xl object-cover max-h-72" />}
      {app.description && <p className="mt-4 text-sm text-muted-foreground whitespace-pre-line">{app.description}</p>}
      {app.features && (
        <>
          <h3 className="mt-5 font-heading font-semibold">Fonctionnalités</h3>
          <p className="mt-1 text-sm whitespace-pre-line">{app.features}</p>
        </>
      )}
    </Modal>
  );
}

function AppForm({ application, onClose, onSaved }) {
  const [f, setF] = useState({
    name: "", description: "", logo_image: "", presentation_image: "", version: "", features: "", price: "",
    download_type: "external_link", download_url: "", purchase_url: "", ...(application || {}),
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    setBusy(true);
    setError("");
    try {
      const body = {
        name: f.name, description: f.description, logo_image: f.logo_image, presentation_image: f.presentation_image, version: f.version,
        features: f.features, price: f.price, download_type: f.download_type, download_url: f.download_url, purchase_url: f.purchase_url,
      };
      if (application) await api.patch(`/api/applications/${application.id}`, body);
      else await api.post("/api/applications", body);
      onSaved();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={application ? "Modifier l'application" : "Nouvelle application"} onClose={onClose} wide
      footer={<><Button variant="outline" onClick={onClose}>Annuler</Button><Button loading={busy} onClick={save}>Enregistrer</Button></>}>
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Field label="Nom *" className="sm:col-span-2"><input className="field" value={f.name} onChange={set("name")} /></Field>
          <Field label="Version"><input className="field" value={f.version || ""} onChange={set("version")} placeholder="1.0.0" /></Field>
        </div>
        <Field label="Description"><textarea className="field min-h-20" value={f.description || ""} onChange={set("description")} /></Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <ImageInput label="Logo" value={f.logo_image} onChange={(v) => setF({ ...f, logo_image: v })} />
          <ImageInput label="Capture de présentation" value={f.presentation_image} onChange={(v) => setF({ ...f, presentation_image: v })} />
        </div>
        <Field label="Fonctionnalités principales"><textarea className="field min-h-20" value={f.features || ""} onChange={set("features")} /></Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Prix affiché" hint="Ex. « Gratuit » ou « 15 000 FCFA »."><input className="field" value={f.price || ""} onChange={set("price")} /></Field>
          <Field label="Lien d'achat (facultatif)"><input className="field" value={f.purchase_url || ""} onChange={set("purchase_url")} placeholder="https://…" /></Field>
        </div>
        <Field label="Mode de téléchargement">
          <div className="grid grid-cols-2 gap-2">
            {[["external_link", "Lien externe", LuLink2], ["apk_file", "Fichier APK", LuFileDown]].map(([v, l, I]) => (
              <button key={v} type="button" onClick={() => setF({ ...f, download_type: v })}
                className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-semibold ${f.download_type === v ? "border-primary bg-primary/5 text-primary" : "border-border hover:bg-muted"}`}>
                <I className="h-4 w-4" /> {l}
              </button>
            ))}
          </div>
        </Field>
        {f.download_type === "external_link" ? (
          <Field label="Lien de téléchargement"><input className="field" value={f.download_url || ""} onChange={set("download_url")} placeholder="https://…" /></Field>
        ) : (
          <Alert variant="info"><LuInfo className="inline h-4 w-4 mr-1" /> Enregistrez l'application, puis téléversez le fichier APK depuis sa carte. Le fichier est stocké en privé : seuls les membres connectés peuvent le télécharger.</Alert>
        )}
        {error && <Alert>{error}</Alert>}
      </div>
    </Modal>
  );
}

export default function ApkPro() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const { data, loading, error, reload } = useLoad(() => api.get("/api/applications").then((r) => r.items));
  const [editing, setEditing] = useState(undefined);
  const [deleting, setDeleting] = useState(null);
  const [details, setDetails] = useState(null);

  const toggle = async (a) => {
    try {
      await api.patch(`/api/applications/${a.id}`, { published: !a.published });
      reload(true);
    } catch (e) {
      toast({ title: "Activation impossible", description: errMsg(e), variant: "destructive" });
    }
  };

  return (
    <Page>
      <PageHeader chip="Applications" chipIcon={LuSmartphone} title="Les APK Pro"
        subtitle="Un catalogue d'applications et d'outils numériques sélectionnés pour booster votre productivité."
        actions={isAdmin && <Button icon={LuPlus} onClick={() => setEditing(null)}>Ajouter une application</Button>} />
      {error ? (
        <ErrorBox message={error} onRetry={reload} />
      ) : loading ? (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">{[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-64" />)}</div>
      ) : !data?.length ? (
        <EmptyState icon={LuSmartphone} title={isAdmin ? "Aucune application pour le moment" : "Catalogue bientôt disponible"}
          text={isAdmin ? "Ajoutez votre première application APK Pro avec un lien externe ou un fichier APK." : "Les applications Pro seront ajoutées prochainement. Revenez visiter cette rubrique pour découvrir nos outils."} />
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
          {data.map((a, i) => (
            <AppCard key={a.id} app={a} variant={i} isAdmin={isAdmin} onEdit={setEditing} onDelete={setDeleting} onToggle={toggle} onChanged={() => reload(true)} onDetails={setDetails} />
          ))}
        </div>
      )}
      {editing !== undefined && <AppForm application={editing} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); reload(true); }} />}
      {details && <AppDetails app={details} onClose={() => setDetails(null)} />}
      {deleting && (
        <ConfirmModal title="Supprimer l'application" text={`Supprimer « ${deleting.name} » ? Cette action est définitive.`} confirmLabel="Supprimer" variant="danger"
          onConfirm={async () => { await api.del(`/api/applications/${deleting.id}`); reload(true); }} onClose={() => setDeleting(null)} />
      )}
    </Page>
  );
}
