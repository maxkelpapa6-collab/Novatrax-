import { useCallback, useEffect, useState } from "react";
import { LuInbox, LuRefreshCw, LuCheckCheck, LuChevronDown } from "react-icons/lu";
import { api, qs } from "../lib/api";
import { formatDateTime, errMsg } from "../lib/format";
import { Page, Card, Skeleton, Button, ErrorBox } from "../components/ui";

const TYPE = {
  admin_message: ["Message de l'équipe", "bg-primary/10 text-primary"],
  system: ["Notification", "bg-muted text-muted-foreground"],
};
const ping = () => window.dispatchEvent(new Event("novatrax:inbox"));

export default function Inbox() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [hasMore, setHasMore] = useState(false);
  const [more, setMore] = useState(false);
  const [open, setOpen] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const r = await api.get("/api/inbox" + qs({ limit: 20 }));
      setItems(r.items);
      setHasMore(r.has_more);
    } catch (e) {
      setError(errMsg(e, "Impossible de charger vos messages."));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { load(); }, [load]);

  const loadMore = async () => {
    setMore(true);
    try {
      const r = await api.get("/api/inbox" + qs({ limit: 20, offset: items.length }));
      setItems((l) => [...l, ...r.items]);
      setHasMore(r.has_more);
    } finally {
      setMore(false);
    }
  };

  const toggle = async (m) => {
    setOpen(open === m.id ? null : m.id);
    if (!m.read) {
      setItems((l) => l.map((x) => (x.id === m.id ? { ...x, read: true } : x)));
      try { await api.post(`/api/inbox/${m.id}/read`); ping(); } catch { /* rien */ }
    }
  };

  const readAll = async () => {
    await api.post("/api/inbox/read-all");
    setItems((l) => l.map((x) => ({ ...x, read: true })));
    ping();
  };

  const unread = items.filter((m) => !m.read).length;

  return (
    <Page narrow>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold">Boîte de réception</h1>
          <p className="mt-1 text-sm text-muted-foreground">Vos notifications et les messages de l'équipe NOVATRAX.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={load} aria-label="Actualiser"><LuRefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} /></Button>
          <Button variant="outline" icon={LuCheckCheck} onClick={readAll} disabled={!unread}>Tout marquer comme lu</Button>
        </div>
      </div>
      {error ? (
        <ErrorBox message={error} onRetry={load} />
      ) : loading ? (
        <div className="mt-6 space-y-2">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-20" />)}</div>
      ) : !items.length ? (
        <Card className="mt-6 p-10 text-center">
          <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary"><LuInbox className="h-7 w-7" /></span>
          <h2 className="mt-4 font-heading text-lg font-bold">Aucun message pour le moment</h2>
          <p className="mt-1 text-sm text-muted-foreground">Vos notifications et les annonces de l'équipe NOVATRAX apparaîtront ici.</p>
        </Card>
      ) : (
        <Card className="mt-6 overflow-hidden">
          <ul className="divide-y divide-border">
            {items.map((m) => {
              const [label, cls] = TYPE[m.type] || TYPE.system;
              const isOpen = open === m.id;
              return (
                <li key={m.id}>
                  <button onClick={() => toggle(m)} className={`flex w-full items-start gap-3 px-4 sm:px-5 py-4 text-left hover:bg-muted/40 ${!m.read ? "bg-violet/5" : ""}`}>
                    <span className={`mt-2 h-2 w-2 shrink-0 rounded-full ${m.read ? "bg-transparent" : "bg-violet"}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${cls}`}>{label}</span>
                        <span className="text-xs text-muted-foreground">{formatDateTime(m.created_date)}</span>
                      </div>
                      <p className={`mt-1 text-sm ${m.read ? "font-medium" : "font-bold"}`}>{m.title}</p>
                      {!isOpen && <p className="mt-0.5 truncate text-sm text-muted-foreground">{m.body_text}</p>}
                      {isOpen && <p className="mt-2 whitespace-pre-line text-sm text-foreground/90">{m.body_text}</p>}
                    </div>
                    <LuChevronDown className={`mt-1 h-4 w-4 shrink-0 text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                </li>
              );
            })}
          </ul>
        </Card>
      )}
      {hasMore && (
        <div className="mt-4 text-center">
          <Button variant="outline" loading={more} onClick={loadMore}>Charger plus de messages</Button>
        </div>
      )}
    </Page>
  );
}
