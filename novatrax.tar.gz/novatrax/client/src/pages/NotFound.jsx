import { Link } from "../lib/router";
import Logo from "../components/Logo";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center bg-background">
      <Logo size="lg" />
      <p className="mt-10 font-heading text-7xl font-extrabold text-gradient-novatrax">404</p>
      <h1 className="mt-3 font-heading text-2xl font-bold">Page introuvable</h1>
      <p className="mt-2 text-muted-foreground max-w-sm">La page que vous cherchez n'existe pas ou a été déplacée.</p>
      <Link to="/" className="mt-6 inline-flex items-center rounded-xl gradient-novatrax px-5 py-2.5 text-sm font-semibold text-white shadow-card">
        Retour au tableau de bord
      </Link>
    </div>
  );
}
