import { useEffect, useState } from "react";
import { LuUser, LuMail, LuGlobe, LuPhone, LuSave, LuCircleCheck, LuLock, LuLogOut, LuAtSign } from "react-icons/lu";
import { api, tokenStore } from "../lib/api";
import { useAuth } from "../lib/auth";
import { COUNTRIES, getCountry, errMsg, formatDate } from "../lib/format";
import { useToast } from "../lib/toast";
import { useNavigate } from "../lib/router";
import { Page, Card, Field, Button, Alert } from "../components/ui";
import { PasswordInput } from "../components/AuthShell";

function ReadOnly({ label, value, icon: Icon }) {
  return (
    <div className="rounded-xl bg-secondary px-4 py-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-0.5 flex items-center gap-2 text-sm font-semibold break-all">
        <Icon className="h-4 w-4 shrink-0 text-muted-foreground" /> {value}
      </p>
    </div>
  );
}

const localPhone = (phone, country) => {
  const c = getCountry(country);
  return c && phone?.startsWith(c.dialCode) ? phone.slice(c.dialCode.length) : phone || "";
};

export default function Profile() {
  const { user, setUser, logout } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [pw, setPw] = useState({ current_password: "", password: "", confirm: "" });
  const [pwBusy, setPwBusy] = useState(false);
  const [pwError, setPwError] = useState("");

  useEffect(() => {
    if (user && !form) {
      setForm({
        first_name: user.first_name || "", last_name: user.last_name || "", country: user.country || "",
        phone: localPhone(user.phone, user.country), share_contacts: !!user.share_contacts, unsubscribed: !!user.unsubscribed,
      });
    }
  }, [user, form]);

  useEffect(() => {
    if (window.location.hash === "#securite") setTimeout(() => document.getElementById("securite")?.scrollIntoView({ behavior: "smooth" }), 100);
  }, []);

  if (!form) return null;
  const country = getCountry(form.country);

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    setSaved(false);
    try {
      const r = await api.patch("/api/auth/me", { ...form, phone: form.phone.replace(/[\s-]/g, "") });
      setUser(r.user);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      setError(errMsg(err, "Une erreur est survenue lors de l'enregistrement."));
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    setPwError("");
    if (pw.password !== pw.confirm) return setPwError("Les mots de passe ne correspondent pas.");
    setPwBusy(true);
    try {
      const r = await api.post("/api/auth/change-password", { current_password: pw.current_password, password: pw.password });
      tokenStore.set(r.token, tokenStore.remembered());
      setPw({ current_password: "", password: "", confirm: "" });
      toast({ title: "Mot de passe modifié", description: "Vos autres appareils ont été déconnectés." });
    } catch (err) {
      setPwError(errMsg(err));
    } finally {
      setPwBusy(false);
    }
  };

  const logoutAll = async () => {
    try {
      await api.post("/api/auth/logout-all");
    } finally {
      logout();
      navigate("/login");
    }
  };

  return (
    <Page narrow>
      <div className="flex items-center gap-3">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl gradient-novatrax text-white"><LuUser className="h-6 w-6" /></span>
        <div>
          <h1 className="font-heading text-2xl font-bold">Mon profil</h1>
          <p className="text-sm text-muted-foreground">Consultez et modifiez vos informations personnelles.</p>
        </div>
      </div>

      <Card className="mt-6 p-5 sm:p-6">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <ReadOnly label="Adresse e-mail" value={user.email} icon={LuMail} />
          <ReadOnly label="Nom d'utilisateur" value={"@" + user.username} icon={LuAtSign} />
          <ReadOnly label="Rôle" value={user.role === "admin" ? "Administrateur" : "Membre"} icon={LuUser} />
          <ReadOnly label="Membre depuis" value={formatDate(user.created_date)} icon={LuCircleCheck} />
        </div>
        <form onSubmit={save} className="mt-6 space-y-5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Prénom">
              <input className="field" value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} placeholder="Votre prénom" />
            </Field>
            <Field label="Nom">
              <input className="field" value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} placeholder="Votre nom" />
            </Field>
          </div>
          <Field label="Pays">
            <div className="relative">
              <LuGlobe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
              <select className="field pl-9" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })}>
                <option value="">Sélectionnez votre pays</option>
                {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.flag} {c.name} ({c.dialCode})</option>)}
              </select>
            </div>
          </Field>
          <Field label="Numéro de téléphone">
            <div className="flex gap-2">
              <div className="relative w-28 shrink-0">
                <LuPhone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                <input className="field pl-9" readOnly value={country ? country.dialCode : "+…"} aria-label="Indicatif" />
              </div>
              <input className="field" type="tel" inputMode="numeric" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Numéro sans l'indicatif" />
            </div>
          </Field>
          <label className="flex items-start gap-3 cursor-pointer rounded-xl border border-border p-4">
            <input type="checkbox" className="mt-0.5 h-4 w-4 accent-violet" checked={form.share_contacts} onChange={(e) => setForm({ ...form, share_contacts: e.target.checked })} />
            <span className="text-sm text-muted-foreground">
              J'accepte que mon nom et mon numéro de téléphone soient visibles et partageables avec les membres de NOVATRAX qui partagent aussi les leurs. Vous pouvez retirer ce consentement à tout moment — vous disparaîtrez alors des nouveaux fichiers de contacts générés.
            </span>
          </label>
          <label className="flex items-start gap-3 cursor-pointer rounded-xl border border-border p-4">
            <input type="checkbox" className="mt-0.5 h-4 w-4 accent-violet" checked={!form.unsubscribed} onChange={(e) => setForm({ ...form, unsubscribed: !e.target.checked })} />
            <span className="text-sm text-muted-foreground">Recevoir par e-mail les annonces et notifications de NOVATRAX (les e-mails de sécurité restent envoyés).</span>
          </label>
          {error && <Alert>{error}</Alert>}
          <div className="flex items-center gap-4">
            <Button type="submit" loading={saving} icon={LuSave}>{saving ? "Enregistrement…" : "Enregistrer les modifications"}</Button>
            {saved && <p className="text-sm text-emerald-600 inline-flex items-center gap-1.5"><LuCircleCheck className="h-4 w-4" /> Modifications enregistrées.</p>}
          </div>
        </form>
      </Card>

      <Card className="mt-6 p-5 sm:p-6">
        <div id="securite" className="scroll-mt-24 flex items-center gap-2">
          <LuLock className="h-5 w-5 text-primary" />
          <h2 className="font-heading text-lg font-bold">Paramètres &amp; sécurité</h2>
        </div>
        <form onSubmit={changePassword} className="mt-4 space-y-4">
          <Field label="Mot de passe actuel"><PasswordInput value={pw.current_password} onChange={(e) => setPw({ ...pw, current_password: e.target.value })} /></Field>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Nouveau mot de passe"><PasswordInput autoComplete="new-password" value={pw.password} onChange={(e) => setPw({ ...pw, password: e.target.value })} /></Field>
            <Field label="Confirmation"><PasswordInput autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} /></Field>
          </div>
          {pwError && <Alert>{pwError}</Alert>}
          <div className="flex flex-wrap gap-2">
            <Button type="submit" variant="outline" loading={pwBusy} icon={LuLock}>Changer le mot de passe</Button>
            <Button type="button" variant="danger" icon={LuLogOut} onClick={logoutAll}>Déconnecter tous mes appareils</Button>
          </div>
        </form>
      </Card>
    </Page>
  );
}
