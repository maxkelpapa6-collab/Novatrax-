import { useState } from "react";
import { Link, useNavigate } from "../lib/router";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { errMsg, pendingRef } from "../lib/format";
import { useToast } from "../lib/toast";
import { Alert, Button } from "../components/ui";
import AuthShell, { OtpInput, safeReturnTo } from "../components/AuthShell";

export default function VerifyEmail() {
  const params = new URLSearchParams(window.location.search);
  const email = params.get("email") || "";
  const [devCode, setDevCode] = useState(params.get("dev") || "");
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const verify = async (e) => {
    e?.preventDefault();
    setError("");
    setLoading(true);
    try {
      const r = await api.post("/api/auth/verify", { email, code });
      pendingRef.clear();
      signIn(r.token, r.user, true);
      navigate(safeReturnTo(), { replace: true });
    } catch (err) {
      setError(errMsg(err, "Code de vérification invalide ou expiré."));
    } finally {
      setLoading(false);
    }
  };

  const resend = async () => {
    setError("");
    try {
      const r = await api.post("/api/auth/resend", { email });
      if (r.dev_code) setDevCode(r.dev_code);
      toast({ title: "Code renvoyé", description: "Vérifiez votre boîte de réception." });
    } catch (err) {
      setError(errMsg(err, "Impossible de renvoyer le code."));
    }
  };

  if (!email) {
    return (
      <AuthShell title="Vérification de l'e-mail">
        <Alert>Lien de vérification incomplet. <Link to="/login" className="font-semibold underline">Retour à la connexion</Link></Alert>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      title="Vérifiez votre e-mail"
      subtitle={<>Un code à 6 chiffres a été envoyé à <span className="font-semibold text-foreground">{email}</span>. Il expire au bout de 10 minutes.</>}
    >
      {devCode && (
        <Alert variant="info" className="mb-5">
          Mode développement (aucun service e-mail configuré) : votre code est <strong>{devCode}</strong>.
        </Alert>
      )}
      {error && <Alert className="mb-5">{error}</Alert>}
      <form onSubmit={verify} className="space-y-5">
        <OtpInput value={code} onChange={setCode} />
        <Button type="submit" variant="violet" size="lg" className="w-full" loading={loading} disabled={code.length < 6}>
          {loading ? "Vérification…" : "Valider le code"}
        </Button>
      </form>
      <p className="text-center text-sm text-muted-foreground mt-5">
        Vous n'avez pas reçu le code ?{" "}
        <button onClick={resend} className="text-violet font-semibold hover:underline">Renvoyer le code</button>
      </p>
      <p className="text-center text-sm text-muted-foreground mt-3">
        <Link to="/register" className="hover:underline">Modifier mes informations</Link>
      </p>
    </AuthShell>
  );
}
