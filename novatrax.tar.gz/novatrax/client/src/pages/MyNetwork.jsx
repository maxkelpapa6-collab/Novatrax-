import { LuUsers, LuChevronLeft } from "react-icons/lu";
import { Link } from "../lib/router";
import { api } from "../lib/api";
import { getCountry, formatDate } from "../lib/format";
import { Page, Card, Skeleton, ErrorBox, useLoad } from "../components/ui";
import { ReferralCard } from "./Home";

export default function MyNetwork() {
  const { data, loading, error, reload } = useLoad(() => api.get("/api/member/network"));
  return (
    <Page narrow>
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground">
        <LuChevronLeft className="h-4 w-4" /> Tableau de bord
      </Link>
      <div className="mt-4 flex items-center gap-3">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl gradient-novatrax text-white">
          <LuUsers className="h-6 w-6" />
        </span>
        <div>
          <h1 className="font-heading text-2xl font-bold">Mon réseau</h1>
          <p className="text-sm text-muted-foreground">Les membres qui ont rejoint NOVATRAX grâce à votre lien d'invitation.</p>
        </div>
      </div>
      {error ? (
        <ErrorBox message={error} onRetry={reload} />
      ) : (
        <>
          {data?.sponsor && (
            <p className="mt-5 rounded-xl bg-secondary px-4 py-3 text-sm text-muted-foreground">
              Vous avez été invité(e) par <span className="font-semibold text-foreground">{data.sponsor.first_name || "@" + data.sponsor.username}</span>.
            </p>
          )}
          <div className="mt-5"><ReferralCard code={data?.referral_code} /></div>
          <Card className="mt-6 p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-heading text-lg font-bold">Membres invités</h2>
              <span className="rounded-full bg-violet/10 px-3 py-1 text-sm font-bold text-violet">{loading ? "…" : data?.total || 0}</span>
            </div>
            {loading ? (
              <Skeleton className="mt-4 h-40" />
            ) : !data?.members?.length ? (
              <p className="mt-4 rounded-xl border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">Aucun membre invité pour le moment. Partagez votre lien pour faire découvrir NOVATRAX.</p>
            ) : (
              <ul className="mt-3 divide-y divide-border">
                {data.members.map((m) => {
                  const c = getCountry(m.country);
                  return (
                    <li key={m.id} className="flex items-center justify-between gap-3 py-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{m.first_name || m.username || "Membre"}</p>
                        <p className="truncate text-xs text-muted-foreground">@{m.username} {c ? `· ${c.flag} ${c.name}` : ""}</p>
                      </div>
                      <p className="shrink-0 text-xs text-muted-foreground">Inscrit le {formatDate(m.created_date)}</p>
                    </li>
                  );
                })}
              </ul>
            )}
            {data?.total > 200 && <p className="mt-2 text-xs text-muted-foreground">Affichage des 200 membres les plus récents.</p>}
          </Card>
        </>
      )}
    </Page>
  );
}
