import { useState } from "react";
import { LuGraduationCap, LuPlus, LuPencil, LuTrash2, LuBookOpen, LuPlay, LuFileText, LuPower } from "react-icons/lu";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { errMsg } from "../lib/format";
import { useToast } from "../lib/toast";
import { Page, PageHeader, Button, Modal, Field, ImageInput, Alert, EmptyState, Skeleton, ErrorBox, ConfirmModal, useLoad } from "../components/ui";

const PASTELS = ["bg-orange-100", "bg-blue-100", "bg-emerald-100", "bg-violet-100"];
const isNew = (d) => d && Date.now() - new Date(d).getTime() < 30 * 86400000;

function youtubeId(url) {
  const m = String(url || "").match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/);
  return m ? m[1] : null;
}

function FormationCard({ f, variant, isAdmin, onOpen, onEdit, onDelete, onToggle }) {
  return (
    <article className="relative flex flex-col rounded-[20px] bg-card shadow-card hover:shadow-card-hover transition-all overflow-hidden">
      {isNew(f.created_date) && f.published && (
        <span className="absolute top-2 left-2 z-20 rounded-md bg-emerald-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">Nouveau</span>
      )}
      {isAdmin && !f.published && (
        <span className="absolute top-2 left-2 z-20 rounded-md bg-amber-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">Brouillon</span>
      )}
      <button onClick={() => onOpen(f)} className="text-left">
        <div className="relative h-20 overflow-hidden">
          {f.cover_image ? (
            <img src={f.cover_image} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className={`flex h-full w-full items-center justify-center ${PASTELS[variant % 4]}`}>
              <LuGraduationCap className="h-10 w-10 text-primary/25" />
            </div>
          )}
        </div>
        <div className="relative z-10 -mt-12 flex justify-center">
          <div className="h-24 w-24 overflow-hidden rounded-2xl border-4 border-card shadow-card">
            {f.profile_image ? (
              <img src={f.profile_image} alt={f.title} className="h-full w-full object-cover" />
            ) : (
              <div className={`flex h-full w-full items-center justify-center ${PASTELS[variant % 4]}`}>
                <LuGraduationCap className="h-8 w-8 text-primary/50" />
              </div>
            )}
          </div>
        </div>
        <div className="px-3 pt-2 text-center">
          <h3 className="truncate text-sm font-bold">{f.title}</h3>
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground/90">{f.description}</p>
        </div>
        <div className="px-3 pt-2 pb-4 text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold text-primary">
            <LuGraduationCap className="h-3 w-3" /> Formation
          </span>
        </div>
      </button>
      {isAdmin && (
        <div className="mt-auto flex flex-wrap gap-2 border-t border-border px-3 py-3">
          <Button size="sm" variant="outline" icon={LuPencil} onClick={() => onEdit(f)}>Modifier</Button>
          <Button size="sm" variant={f.published ? "outline" : "success"} icon={LuPower} onClick={() => onToggle(f)}>{f.published ? "Dépublier" : "Publier"}</Button>
          <Button size="sm" variant="danger" icon={LuTrash2} onClick={() => onDelete(f)}>Supprimer</Button>
        </div>
      )}
    </article>
  );
}

function FormationView({ f, onClose }) {
  const yt = youtubeId(f.video_url);
  return (
    <Modal title={f.title} onClose={onClose} wide>
      {f.cover_image && <img src={f.cover_image} alt="" className="mb-4 h-40 w-full rounded-2xl object-cover" />}
      {f.description && <p className="text-sm text-muted-foreground">{f.description}</p>}
      {yt ? (
        <div className="mt-4 aspect-video overflow-hidden rounded-2xl bg-black">
          <iframe className="h-full w-full" src={`https://www.youtube-nocookie.com/embed/${yt}`} title={f.title} allow="accelerometer; encrypted-media; picture-in-picture; fullscreen" allowFullScreen />
        </div>
      ) : null}
      {f.content && <div className="mt-5 whitespace-pre-line text-sm leading-relaxed">{f.content}</div>}
      <div className="mt-5 flex flex-wrap gap-2">
        {f.video_url && !yt && (
          <a href={f.video_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl gradient-novatrax px-4 py-2.5 text-sm font-semibold text-white">
            <LuPlay className="h-4 w-4" /> Regarder la vidéo
          </a>
        )}
        {f.document_url && (
          <a href={f.document_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-xl border border-border px-4 py-2.5 text-sm font-semibold hover:bg-muted">
            <LuFileText className="h-4 w-4" /> Ouvrir le support de cours
          </a>
        )}
      </div>
      {!f.content && !f.video_url && !f.document_url && <p className="mt-4 text-sm text-muted-foreground">Le contenu de cette formation sera bientôt disponible.</p>}
    </Modal>
  );
}

function FormationForm({ formation, onClose, onSaved }) {
  const [f, setF] = useState({
    title: "", description: "", profile_image: "", cover_image: "", content: "", video_url: "", document_url: "", published: false,
    ...(formation || {}),
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const save = async () => {
    setBusy(true);
    setError("");
    try {
      const body = { ...f };
      if (formation) await api.patch(`/api/formations/${formation.id}`, body);
      else await api.post("/api/formations", body);
      onSaved();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal
      title={formation ? "Modifier la formation" : "Nouvelle formation"}
      onClose={onClose}
      wide
      footer={<><Button variant="outline" onClick={onClose}>Annuler</Button><Button loading={busy} onClick={save}>Enregistrer</Button></>}
    >
      <div className="space-y-4">
        <Field label="Titre *"><input className="field" value={f.title} onChange={set("title")} /></Field>
        <Field label="Description courte"><textarea className="field min-h-20" value={f.description || ""} onChange={set("description")} /></Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <ImageInput label="Photo de profil" value={f.profile_image} onChange={(v) => setF({ ...f, profile_image: v })} />
          <ImageInput label="Image de couverture" value={f.cover_image} onChange={(v) => setF({ ...f, cover_image: v })} />
        </div>
        <Field label="Contenu de la formation" hint="Texte libre, les sauts de ligne sont conservés."><textarea className="field min-h-40" value={f.content || ""} onChange={set("content")} /></Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="Lien vidéo" hint="YouTube (intégré automatiquement) ou autre lien."><input className="field" value={f.video_url || ""} onChange={set("video_url")} placeholder="https://…" /></Field>
          <Field label="Lien du support (PDF, Drive…)"><input className="field" value={f.document_url || ""} onChange={set("document_url")} placeholder="https://…" /></Field>
        </div>
        <label className="flex items-center gap-3 cursor-pointer">
          <input type="checkbox" className="h-4 w-4 accent-violet" checked={!!f.published} onChange={set("published")} />
          <span className="text-sm font-medium">Publier (visible par les membres)</span>
        </label>
        {error && <Alert>{error}</Alert>}
      </div>
    </Modal>
  );
}

export default function Formation() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const { data, loading, error, reload } = useLoad(() => api.get("/api/formations").then((r) => r.items));
  const [editing, setEditing] = useState(undefined);
  const [viewing, setViewing] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const toggle = async (f) => {
    try {
      await api.patch(`/api/formations/${f.id}`, { ...f, published: !f.published });
      reload(true);
    } catch (e) {
      toast({ title: "Modification impossible", description: errMsg(e), variant: "destructive" });
    }
  };

  return (
    <Page>
      <PageHeader
        chip="Formation" chipIcon={LuGraduationCap} chipTone="violet"
        title="Nos formations"
        subtitle="Des parcours pratiques pour développer vos compétences numériques et professionnelles."
        actions={isAdmin && <Button icon={LuPlus} onClick={() => setEditing(null)}>Ajouter une formation</Button>}
      />
      {error ? (
        <ErrorBox message={error} onRetry={reload} />
      ) : loading ? (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">{[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-64" />)}</div>
      ) : !data?.length ? (
        <EmptyState icon={LuBookOpen} title={isAdmin ? "Aucune formation pour le moment" : "Formations bientôt disponibles"} text={isAdmin ? "Ajoutez votre première formation." : "Notre catalogue de formations est en cours de préparation. Revenez bientôt pour découvrir nos premiers parcours."} />
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
          {data.map((f, i) => (
            <FormationCard key={f.id} f={f} variant={i} isAdmin={isAdmin} onOpen={setViewing} onEdit={setEditing} onDelete={setDeleting} onToggle={toggle} />
          ))}
        </div>
      )}
      {editing !== undefined && <FormationForm formation={editing} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); reload(true); }} />}
      {viewing && <FormationView f={viewing} onClose={() => setViewing(null)} />}
      {deleting && (
        <ConfirmModal
          title="Supprimer la formation"
          text={`Supprimer définitivement « ${deleting.title} » ?`}
          confirmLabel="Supprimer" variant="danger"
          onConfirm={async () => { await api.del(`/api/formations/${deleting.id}`); reload(true); }}
          onClose={() => setDeleting(null)}
        />
      )}
    </Page>
  );
}
