import { useState } from "react";
import { LuPackage, LuShoppingBag } from "react-icons/lu";
import { Link } from "../lib/router";
import { api, qs } from "../lib/api";
import { Page, PageHeader, Card, Skeleton, ConfirmModal, ErrorBox, useLoad } from "../components/ui";
import { OrderItem } from "../components/marketplace";

const CONFIRM = {
  confirm_receipt: { title: "Confirmer la réception", text: "Confirmez uniquement si vous avez bien reçu le produit et qu'il est conforme. La vente sera clôturée.", label: "Confirmer la réception" },
  cancel: { title: "Annuler la commande", text: "Le vendeur sera prévenu de l'annulation.", label: "Annuler la commande", variant: "danger", reason: true, reasonRequired: false },
  dispute: { title: "Signaler un problème", text: "L'administration NOVATRAX examinera votre demande et contactera les deux parties.", label: "Ouvrir un litige", variant: "danger", reason: true, reasonRequired: true, reasonLabel: "Décrivez le problème rencontré (livraison non reçue, produit non conforme…)" },
};

export default function MyPurchases() {
  const { data, loading, error, reload } = useLoad(() => api.get("/api/marketplace/orders" + qs({ role: "buyer" })).then((r) => r.items));
  const [confirm, setConfirm] = useState(null);
  return (
    <Page narrow>
      <PageHeader chip="Marketplace" chipIcon={LuPackage} chipTone="violet" title="Mes achats" subtitle="Suivi de mes commandes sur la Marketplace NOVATRAX." />
      {error ? <ErrorBox message={error} onRetry={reload} /> : loading ? <Skeleton className="mt-6 h-40" /> : !data?.length ? (
        <Card className="mt-6 p-10 text-center">
          <LuShoppingBag className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 font-semibold">Aucun achat pour le moment.</p>
          <p className="mt-1 text-sm text-muted-foreground">Explorez la <Link to="/marketplace" className="text-primary font-semibold hover:underline">Marketplace</Link> et trouvez votre premier produit.</p>
        </Card>
      ) : (
        <Card className="mt-6 overflow-hidden">
          <ul className="divide-y divide-border">
            {data.map((o) => (
              <OrderItem key={o.id} order={o} role="buyer" onAction={(order, action) => setConfirm({ ...CONFIRM[action], run: (reason) => api.post(`/api/marketplace/orders/${order.id}/action`, { action, reason }) })} />
            ))}
          </ul>
        </Card>
      )}
      {confirm && (
        <ConfirmModal title={confirm.title} text={confirm.text} confirmLabel={confirm.label} variant={confirm.variant}
          reason={confirm.reason} reasonRequired={confirm.reasonRequired} reasonLabel={confirm.reasonLabel}
          onConfirm={async (r) => { await confirm.run(r); reload(true); }} onClose={() => setConfirm(null)} />
      )}
    </Page>
  );
}
