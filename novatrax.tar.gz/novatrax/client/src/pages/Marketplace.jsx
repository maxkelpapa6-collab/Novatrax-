import { useCallback, useEffect, useState } from "react";
import { LuSearch, LuStore, LuShoppingBag, LuChevronDown, LuPackage } from "react-icons/lu";
import { Link } from "../lib/router";
import { api, qs } from "../lib/api";
import { Page, PageHeader, Skeleton, Card, Button, useLoad } from "../components/ui";
import { ProductCard } from "../components/marketplace";

export default function Marketplace() {
  const cats = useLoad(() => api.get("/api/marketplace/categories").then((r) => r.items));
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [category, setCategory] = useState("");
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [sort, setSort] = useState("recent");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [more, setMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 350);
    return () => clearTimeout(t);
  }, [search]);

  const query = useCallback((offset = 0) => api.get("/api/marketplace/products" + qs({ search: debounced, category, min, max, sort, offset })), [debounced, category, min, max, sort]);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    query().then((r) => {
      if (!alive) return;
      setItems(r.items);
      setHasMore(r.has_more);
    }).catch(() => alive && setItems([])).finally(() => alive && setLoading(false));
    return () => { alive = false; };
  }, [query]);

  const loadMore = async () => {
    setMore(true);
    try {
      const r = await query(items.length);
      setItems((l) => [...l, ...r.items]);
      setHasMore(r.has_more);
    } finally {
      setMore(false);
    }
  };

  const pill = (active) => `whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors ${active ? "gradient-novatrax text-white" : "border border-border text-muted-foreground hover:bg-muted"}`;

  return (
    <Page>
      <PageHeader
        chip="Marketplace NOVATRAX" chipIcon={LuShoppingBag} chipTone="violet"
        title="Achetez et vendez entre membres"
        subtitle="Des annonces vérifiées par l'administration. Commandez, convenez du paiement avec le vendeur et suivez votre commande jusqu'à la livraison."
        actions={
          <>
            <Link to="/ma-boutique" className="inline-flex items-center gap-2 rounded-xl gradient-novatrax px-4 py-2.5 text-sm font-semibold text-white shadow-card"><LuStore className="h-4 w-4" /> Ma boutique</Link>
            <Link to="/mes-achats" className="inline-flex items-center gap-2 rounded-xl border border-border px-4 py-2.5 text-sm font-semibold hover:bg-muted"><LuPackage className="h-4 w-4" /> Mes achats</Link>
          </>
        }
      />
      <div className="mt-6 space-y-3">
        <div className="relative">
          <LuSearch className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Rechercher un produit par nom…" className="field pl-10 h-11" />
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          <button onClick={() => setCategory("")} className={pill(!category)}>Toutes</button>
          {cats.data?.map((c) => (
            <button key={c.id} onClick={() => setCategory(category === c.name ? "" : c.name)} className={pill(category === c.name)}>{c.name}</button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input value={min} onChange={(e) => setMin(e.target.value.replace(/\D/g, ""))} inputMode="numeric" placeholder="Prix min (FCFA)" className="field w-36" />
          <span className="text-muted-foreground text-sm">—</span>
          <input value={max} onChange={(e) => setMax(e.target.value.replace(/\D/g, ""))} inputMode="numeric" placeholder="Prix max (FCFA)" className="field w-36" />
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="field w-auto">
            <option value="recent">Plus récents</option>
            <option value="price_asc">Prix croissant</option>
            <option value="price_desc">Prix décroissant</option>
          </select>
        </div>
      </div>
      {loading ? (
        <div className="mt-8 grid gap-4 grid-cols-2 lg:grid-cols-4">{[1, 2, 3, 4, 5, 6, 7, 8].map((i) => <Skeleton key={i} className="aspect-[3/4]" />)}</div>
      ) : !items.length ? (
        <Card className="mt-10 p-10 text-center">
          <LuShoppingBag className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 font-semibold">Aucun produit ne correspond à votre recherche.</p>
          <p className="mt-1 text-sm text-muted-foreground">Explorez d'autres catégories ou revenez bientôt : de nouvelles annonces arrivent.</p>
        </Card>
      ) : (
        <div className="mt-6 grid gap-4 grid-cols-2 lg:grid-cols-4">
          {items.map((p) => <ProductCard key={p.id} product={p} to={`/marketplace/produit/${p.id}`} />)}
        </div>
      )}
      {hasMore && (
        <div className="mt-6 text-center">
          <Button variant="outline" icon={LuChevronDown} loading={more} onClick={loadMore}>Charger plus de produits</Button>
        </div>
      )}
    </Page>
  );
}
