import { LuShieldCheck } from "react-icons/lu";
import { Link } from "../lib/router";
import Logo from "../components/Logo";

function LegalPage({ title, updated, sections, footer }) {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-background/85 backdrop-blur-md sticky top-0 z-30">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 h-16 flex items-center justify-between">
          <Logo />
          <Link to="/" className="text-sm font-medium text-muted-foreground hover:text-foreground">← Retour à l'accueil</Link>
        </div>
      </header>
      <article className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
        <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
          <LuShieldCheck className="h-3.5 w-3.5" /> Légal
        </span>
        <h1 className="mt-4 font-heading text-3xl sm:text-4xl font-bold">{title}</h1>
        <p className="mt-2 text-sm text-muted-foreground">Dernière mise à jour : {updated}</p>
        <div className="mt-8 space-y-6 text-sm leading-relaxed text-muted-foreground">
          {sections.map(([h, p]) => (
            <section key={h}>
              <h2 className="text-foreground font-heading text-lg font-semibold">{h}</h2>
              <p className="mt-1.5">{p}</p>
            </section>
          ))}
        </div>
        <div className="mt-10">{footer}</div>
      </article>
    </div>
  );
}

export function Terms() {
  return (
    <LegalPage
      title="Conditions d'utilisation"
      updated="20 octobre 2026"
      sections={[
        ["1. Objet", "Les présentes conditions définissent les modalités d'accès et d'utilisation de la plateforme NOVATRAX. L'inscription implique l'acceptation pleine et entière des présentes conditions."],
        ["2. Inscription et compte", "L'utilisateur s'engage à fournir des informations exactes lors de son inscription (nom, prénom, pays, numéro de téléphone, adresse e-mail). L'adresse e-mail doit être vérifiée via le code de confirmation envoyé par NOVATRAX. L'utilisateur est responsable de la confidentialité de ses identifiants."],
        ["3. Données enregistrées", "Lors de l'inscription, NOVATRAX enregistre les coordonnées de l'utilisateur (nom, prénom, pays, numéro de téléphone, adresse e-mail, date d'inscription, statut de vérification). Ces données sont traitées conformément à notre politique de confidentialité et peuvent être consultées par les administrateurs autorisés de la plateforme."],
        ["4. Invitations", "Chaque membre dispose d'un lien d'invitation permettant à ses proches de rejoindre la plateforme. L'invitation de nouveaux membres ne donne lieu à aucune rémunération et ne constitue en aucun cas une source de revenus."],
        ["5. Marketplace", "Les membres peuvent publier des annonces après validation par l'administration. Les liens externes, les produits illégaux, contrefaits ou interdits sont prohibés ; les annonces non conformes sont bloquées et les infractions répétées entraînent la suspension de l'accès vendeur. Le paiement et la livraison sont convenus directement entre l'acheteur et le vendeur, qui en sont seuls responsables ; NOVATRAX assure le suivi des commandes et l'examen des litiges."],
        ["6. Utilisation de la plateforme", "L'utilisateur s'engage à utiliser la plateforme de manière licite et respectueuse. Toute utilisation frauduleuse, abusive ou contraire aux lois en vigueur est strictement interdite et peut entraîner la suspension du compte."],
        ["7. Suspension", "NOVATRAX se réserve le droit de suspendre un compte en cas de manquement aux présentes conditions. Les données et l'historique du compte sont conservés."],
        ["8. Responsabilité", "NOVATRAX met tout en œuvre pour assurer la disponibilité et la sécurité de la plateforme mais ne saurait être tenue responsable des interruptions ou dysfonctionnements indépendants de sa volonté."],
      ]}
      footer={<Link to="/privacy" className="text-sm font-semibold text-primary hover:underline">Voir la politique de confidentialité →</Link>}
    />
  );
}

export function Privacy() {
  return (
    <LegalPage
      title="Politique de confidentialité"
      updated="20 octobre 2026"
      sections={[
        ["1. Données collectées", "NOVATRAX collecte les informations fournies à l'inscription (adresse e-mail, nom d'utilisateur, prénom, nom, pays, numéro de téléphone), la date d'inscription, le statut de vérification, ainsi que les contenus que vous publiez (annonces Marketplace, commandes)."],
        ["2. Finalité du traitement", "Ces données servent à créer et sécuriser votre compte, vous donner accès aux formations et applications, gérer la Marketplace, vous envoyer les notifications liées à votre compte et assurer le support."],
        ["3. Accès aux données", "Vos données sont accessibles aux administrateurs autorisés de la plateforme. Les actions sensibles de l'administration (consultation de fiches, exports, blocages) sont enregistrées dans un journal d'audit."],
        ["4. Annuaire des membres", "Votre nom et votre numéro de téléphone n'apparaissent dans l'annuaire des membres que si vous avez donné votre accord explicite. Vous pouvez retirer ce consentement à tout moment depuis « Mon profil » : vous n'apparaîtrez plus dans les nouveaux fichiers de contacts générés."],
        ["5. Communications", "NOVATRAX peut vous adresser des messages d'information. Vous pouvez vous désabonner des e-mails d'annonces depuis votre profil ; les messages liés à la sécurité de votre compte restent envoyés."],
        ["6. Conservation et sécurité", "Les mots de passe sont chiffrés et ne sont jamais lisibles. Les données sont conservées pendant la durée d'utilisation de votre compte. Pour toute demande d'accès, de rectification ou de suppression, contactez le support."],
      ]}
      footer={<Link to="/terms" className="text-sm font-semibold text-primary hover:underline">Voir les conditions d'utilisation →</Link>}
    />
  );
}
