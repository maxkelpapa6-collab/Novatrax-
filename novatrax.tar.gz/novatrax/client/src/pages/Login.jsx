import { useState } from "react";
import { Link, useNavigate } from "../lib/router";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { errMsg } from "../lib/format";
import { Alert, Button } from "../components/ui";
import AuthShell, { PasswordInput, safeReturnTo } from "../components/AuthShell";

export default function Login() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(() => {
    try { return localStorage.getItem("novatrax_remember_me") !== "0"; } catch { return true; }
  });
  const [error, setError] = useState("");
  const [unverified, setUnverified] = useState(null);
  const [loading, setLoading] = useState(false);
  const returnTo = safeReturnTo();

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setUnverified(null);
    if (!identifier.trim() || !password) return setError("Veuillez saisir vos identifiants.");
    setLoading(true);
    try {
      const r = await api.post("/api/auth/login", { identifier: identifier.trim(), password });
      try { localStorage.setItem("novatrax_remember_me", remember ? "1" : "0"); } catch { /* rien */ }
      signIn(r.token, r.user, remember);
      navigate(returnTo, { replace: true });
    } catch (err) {
      setError(errMsg(err));
      if (err.data?.needs_verification) setUnverified(err.data.email);
    } finally {
      setLoading(false);
    }
  };

  const goVerify = async () => {
    try {
      const r = await api.post("/api/auth/resend", { email: unverified });
      navigate(`/verifier?email=${encodeURIComponent(unverified)}${r.dev_code ? "&dev=" + r.dev_code : ""}`);
    } catch (e) {
      setError(errMsg(e));
    }
  };

  return (
    <AuthShell title="Se connecter à son compte" subtitle="Saisissez votre adresse e-mail et votre mot de passe pour vous connecter.">
      {error && (
        <Alert className="mb-5">
          {error}
          {unverified && (
            <button onClick={goVerify} className="mt-2 block font-semibold text-violet hover:underline">
              Recevoir un nouveau code de vérification
            </button>
          )}
        </Alert>
      )}
      <form onSubmit={submit} className="space-y-5">
        <label className="block space-y-1.5">
          <span className="text-sm font-medium">Nom d'utilisateur / Adresse e-mail</span>
          <input
            type="text"
            autoComplete="username"
            autoFocus
            placeholder="Saisissez votre nom d'utilisateur ou adresse e-mail"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            className="field h-12 bg-secondary"
            required
          />
        </label>
        <label className="block space-y-1.5">
          <span className="text-sm font-medium">Mot de passe</span>
          <PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <div className="flex items-center justify-between gap-3 pt-1">
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="h-4 w-4 accent-violet" />
            <span className="text-sm text-muted-foreground">Rester connecté</span>
          </label>
          <Link to="/forgot-password" className="text-sm text-violet font-medium hover:underline">Mot de passe oublié ?</Link>
        </div>
        <Button type="submit" variant="violet" size="lg" className="w-full" loading={loading}>
          {loading ? "Connexion…" : "Se connecter"}
        </Button>
      </form>
      <p className="mt-8 text-center text-sm text-muted-foreground">
        Vous n'avez pas de compte ?{" "}
        <Link to={"/register" + (returnTo !== "/" ? "?returnTo=" + encodeURIComponent(returnTo) : "")} className="text-violet font-semibold hover:underline">
          Créer un compte
        </Link>
      </p>
    </AuthShell>
  );
}

