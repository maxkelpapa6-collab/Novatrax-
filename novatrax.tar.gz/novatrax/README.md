# NOVATRAX — version autonome

Reconstruction complète de la plateforme NOVATRAX, **indépendante de Base44** : son propre serveur, sa propre base de données, sa propre authentification. Aucun service tiers n'est obligatoire.

- **Serveur** : Node.js 22 sans aucune dépendance (HTTP natif + SQLite intégré à Node).
- **Interface** : React 19 + Tailwind CSS 4, mêmes couleurs, polices et composants que l'original.
- **Données** : un seul fichier SQLite + un dossier de fichiers téléversés, dans `data/`.

## Démarrage rapide

Prérequis : **Node.js 22.13 ou plus récent** (`node -v`).

```bash
cp .env.example .env         # puis éditez les valeurs
npm start                    # l'interface est déjà compilée dans dist/
```

Ouvrez http://localhost:3000. Le serveur n'a besoin d'aucun `npm install` pour fonctionner.

### Créer le premier administrateur

Deux possibilités :

1. Mettez votre e-mail dans `ADMIN_EMAILS` (fichier `.env`), puis inscrivez-vous normalement : le compte devient administrateur dès la vérification de l'e-mail.
2. Ou en ligne de commande :
   ```bash
   npm run create-admin -- vous@exemple.com VotreMotDePasse1
   ```

### E-mails

Sans configuration, les e-mails (codes de vérification, notifications) sont **affichés dans la console du serveur** et, hors production, le code s'affiche aussi à l'écran pour faciliter les tests. Pour un envoi réel, créez un compte gratuit chez [Brevo](https://www.brevo.com) ou [Resend](https://resend.com) puis :

```
MAIL_PROVIDER=brevo
MAIL_API_KEY=votre-clé
MAIL_FROM=NOVATRAX <no-reply@votre-domaine.com>
```

## Modifier l'interface

```bash
npm install          # installe esbuild, tailwindcss, react, react-icons
npm run dev          # recompile automatiquement à chaque modification (dans un 2e terminal : npm start)
npm run build        # compilation de production dans dist/
npm test             # 19 tests de bout en bout de l'API
```

## Fonctionnalités

| Espace | Contenu |
|---|---|
| **Comptes** | Inscription (e-mail, nom d'utilisateur, prénom, nom, pays, téléphone), vérification par code à 6 chiffres, connexion par e-mail **ou** nom d'utilisateur, « rester connecté », mot de passe oublié, changement de mot de passe, déconnexion de tous les appareils |
| **Tableau de bord** | Carte de bienvenue, compteurs, vitrine applications & formations, lien d'invitation (copie / partage WhatsApp), derniers membres invités |
| **Mon réseau** | Membres inscrits avec votre lien d'invitation (sans aucune rémunération) |
| **Formations** | Catalogue, fiche détaillée (texte, vidéo YouTube intégrée, support PDF) ; gestion complète par l'admin (brouillon / publié) |
| **APK Pro** | Catalogue ; téléchargement par lien externe ou fichier APK stocké en privé (lien signé valable 5 min) ; téléversement avec barre de progression |
| **Marketplace** | Annonces validées par l'admin, recherche et filtres, blocage automatique des liens externes et termes interdits, suspension vendeur après 3 infractions en 30 jours, commandes suivies de bout en bout, litiges |
| **Contacts** | Annuaire des membres consentants (recherche, périodes, export VCF), page support ; côté admin : tous les membres, filtres, exports CSV / VCF journalisés |
| **Boîte de réception** | Notifications et messages de l'équipe, non-lus, tout marquer comme lu |
| **Administration** | Statistiques, utilisateurs (fiche complète, blocage motivé, vérification manuelle, rôles, déconnexion forcée), messages ciblés (tous / pays / période / individuel, boîte de réception et/ou e-mail, e-mail de test), modération Marketplace, catégories et règles, journal d'audit |
| **Légal** | Conditions d'utilisation, politique de confidentialité |

## Ce qui a été retiré par rapport à l'original

- **Moyens de paiement** : l'intégration LeekPay (checkout, webhooks), les dépôts, les retraits et le portefeuille.
- **Frais d'accès et commissions de parrainage** : l'original faisait payer 3 000 FCFA d'accès et en reversait 2 500 aux parrains sur 3 niveaux. Ce mécanisme n'a pas été reconstruit. Les formations et applications sont accessibles à tout membre vérifié, et le parrainage n'est plus qu'un lien d'invitation, sans argent.
- **Dépendances Base44** : SDK, fonctions serveur, connexion Google/OAuth Base44, stockage et images hébergées chez Base44 (le logo a été redessiné en SVG : `client/public/logo.svg`).

### Marketplace sans paiement intégré

Le parcours d'une commande :

1. L'acheteur commande, et le vendeur est prévenu avec son numéro.
2. Les deux conviennent du paiement et de la livraison.
3. Le vendeur clique sur **« Paiement reçu »**, puis l'acheteur sur **« J'ai reçu le produit »**.

En cas de problème, l'acheteur ouvre un litige que l'administration tranche : terminer, annuler, ou marquer comme remboursée avec une note. Le réglage `MARKETPLACE_COMMISSION_RATE` existe, mais il vaut 0 par défaut : il n'aura de sens qu'une fois un paiement intégré.

## Mise en ligne

N'importe quel serveur (VPS, Render, Railway…) capable d'exécuter Node 22 :

```bash
NODE_ENV=production npm start
```

- Placez le site derrière HTTPS (Nginx, Caddy ou l'hébergeur).
- Le dossier `data/` doit être **persistant et sauvegardé** : il contient la base et les fichiers.
- Pour garder le serveur actif : `pm2 start npm --name novatrax -- start` ou un service systemd.

Exemple Caddy :

```
votre-domaine.com {
  reverse_proxy localhost:3000
}
```

## Structure

```
server/            API (aucune dépendance)
  index.js         serveur HTTP, fichiers statiques
  db.js            schéma SQLite
  auth.js          mots de passe (scrypt), sessions signées, codes OTP, audit
  mail.js          Brevo / Resend / console
  routes/          auth, member, contacts, marketplace, admin
  scripts/         create-admin
client/            interface React
  src/pages/       une page par écran
  src/components/  mise en page, composants, admin
shared/            liste des pays (serveur + interface)
dist/              interface compilée (servie par le serveur)
tests/             tests de l'API
data/              créé au premier démarrage (base + téléversements)
```
