// Pays pris en charge par NOVATRAX (partagé entre le serveur et l'interface).
export const COUNTRIES = [
  { code: "CI", name: "Côte d'Ivoire", dialCode: "+225", flag: "🇨🇮" },
  { code: "TG", name: "Togo", dialCode: "+228", flag: "🇹🇬" },
  { code: "BJ", name: "Bénin", dialCode: "+229", flag: "🇧🇯" },
  { code: "BF", name: "Burkina Faso", dialCode: "+226", flag: "🇧🇫" },
  { code: "CM", name: "Cameroun", dialCode: "+237", flag: "🇨🇲" },
  { code: "SN", name: "Sénégal", dialCode: "+221", flag: "🇸🇳" },
  { code: "CG", name: "Congo-Brazzaville", dialCode: "+242", flag: "🇨🇬" },
  { code: "CD", name: "RD Congo", dialCode: "+243", flag: "🇨🇩" },
];

export const getCountry = (code) => COUNTRIES.find((c) => c.code === code) || null;
